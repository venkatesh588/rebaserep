# autovalidateutils

An R package of utility functions for preparing R packages for use with autovalidate

## Validated Use :ballot_box_with_check:	

_Using `autovalidateutils` is not sufficient for validation._

Validation requires either:

- Use of the `autovalidate-r` submission portal, which runs 
  `autovalidateutils` in a controlled way to produce useful 
   validation documentation.
- Using `autovalidate-r/gitlab-ci` pipelines
  (or `autovalidateutils` directly) and accompanying the 
  generated report with additional documentation specific to your
  intended use, managing the storing of your validation documents 
  in an approved document management service.

## Installation

> Due to some bugs in `remotes` ([#625](https://github.com/r-lib/remotes/issues/625), 
> [#604](https://github.com/r-lib/remotes/issues/604)), it is a bit challenging to
> install `autovalidate` using the usual `devtools::install_gitlab`. Until those
> are fixed, the best way to install is from source.

```r
# Basic auth over http is disabled on code.roche.com, pass an access token as your password
tmp <- tempdir()
system(sprintf("git clone https://code.roche.com/autovalidate-r/autovalidateutils %s", tmp))
devtools::install_local(tmp)
```

## Quick Start

For preparing R package metadata for `autovalidate`, there is one key function
which will prep all the necessary file:

```r
library(autovalidateutils)
autovalidate()
```

This will go through a series of steps, printing an execution log to console.
This is a good way to evaluate a package.

## Building package metadata

To run `autovalidate` while storing package metadata, provide an output
directory.

```r
autovalidate(output = "/path/to/output/dir")
```

The contents of this directory, by default, conform to the expected file
structure required to build a validation report using our _[autovalidate R
package report
template](https://code.roche.com/autovalidate-r/package-report-template)_. For
more details on how to manage file export, see `?autovalidateutils_options`.
