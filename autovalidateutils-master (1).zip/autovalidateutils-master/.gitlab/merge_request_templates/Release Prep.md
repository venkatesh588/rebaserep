# Release

## Overview
<!-- brief overview of changes or release target -->



## Release Checklist

- [ ] A release preparation branch should be made with any final changes before
  release, with a release merge request to rejoin with the main branch when
  finalized.
- [ ] Passing `R CMD check`
- [ ] Review vignette building (if not run during `R CMD check`)
- [ ] Package version has been updated in `DESCRIPTION`
- [ ] `NEWS` contains entries for version changes
- [ ] Review deprecation lifecycle management
  - **Point Release** New deprecations should be non-breaking
  - **Minor Release** Deprecations can escalate from messages to warnings or errors
  - **Major Release** Deprecated behaviors should be removed
- [ ] Release commit has been tagged (`v#` where `#` is the new package version number)
- [ ] Upon merge into main branch, a Release is made using the tagged commit.

/label ~release
