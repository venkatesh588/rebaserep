## Set up repos: use a repo snapshot from the time of R release
options(repos = c(
  "MRAN (R v3.6.3)" = "https://mran.microsoft.com/snapshot/2020-03-01"
))

## Set up temporary lib for autovalidateutils install
dir.create(templib <- file.path(tempdir(), "R_LIB_autovalidateutils_deps"))
.libPaths(c(templib, .libPaths()))

minimal_autovalidateutils_install(
  lib = templib,
  repos = c(getOption("repos"), CRAN = "https://cloud.r-project.org")
)

options(repos = c())
