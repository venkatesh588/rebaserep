
local({
  # nolint start: line_length_linter.
  message(
    "Note: ",
    "remotes installation will require pre-configured system git credentials: \n",
    "\n",
    "    git config --global credential.helper store\n",
    '    echo "https://gitlab-ci-token:${GITLAB_PAT}@code.roche.com" >> ~/.git-credentials\n',
    "\n"
  )
  # nolint end: commented_code_linter.

  tmp_renv_lib <- file.path(tempdir(), "avu_libs", "renv")
  tmp_avu_lib <- file.path(tempdir(), "avu_libs", "deps")

  dir.create(tmp_renv_lib, recursive = TRUE)
  dir.create(tmp_avu_lib, recursive = TRUE)

  install.packages("renv", tmp_renv_lib)
  library(renv, lib.loc = tmp_renv_lib)

  lockfile <- file.path(.autovalidateutils_path, "inst", "renv.enabler404.lock")
  renv::restore(
    lockfile = lockfile,
    library = c(tmp_avu_lib, .libPaths()),
    prompt = FALSE
  )

  install.packages(
    .autovalidateutils_path,
    type = "source",
    lib = tmp_avu_lib,
    repos = NULL
  )
  library(autovalidateutils, lib.loc = tmp_avu_lib)

  .libPaths(c(tmp_avu_lib, .libPaths()))
})
