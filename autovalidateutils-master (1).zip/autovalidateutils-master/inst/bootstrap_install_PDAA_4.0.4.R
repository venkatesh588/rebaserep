## Set up repos: use last repo snapshot contemporary with R version
options(repos = "https://mran.microsoft.com/snapshot/2022-06-20")


## Set up temporary lib for autovalidateutils install
dir.create(templib <- file.path(tempdir(), "R_LIB_autovalidateutils_deps"))
.libPaths(c(templib, .libPaths()))

# `rmarkdown`
# system version of package `rmarkdown` throws vignette build errors due to bug
# with system pandoc version (rstudio/rmarkdown#1120)
#
# `remotes`
# system version of package `remotes` will fail to install remote dependencies
# so that they satisfy version constraints. It appears to first install the
# necessary dev version of `covr`, then overwrite that with the version from
# CRAN.
install.packages(
  c("rmarkdown", "remotes"),
  repos = "https://cloud.r-project.org"
)

# `git2r`
# Due to the system libraries installed on PDD, differet version of git2r cannot
# be installed. We have to install it from Archive
install.packages(
  "https://cran.r-project.org/src/contrib/Archive/git2r/git2r_0.28.0.tar.gz",
  repos = NULL
)

# `cli`, `processsx`, `pkgbuild`
install.packages(c("cli", "processx", "pkgbuild"))

minimal_autovalidateutils_install(
  lib = templib,
  repos = c(getOption("repos"), CRAN = "https://cloud.r-project.org")
)

options(repos = c())
