# remotes::gitlab_pat will default to a bundled access token when in CI, which
# seems to regularly hit github api rate limits. We can avoid this by
# temporarily setting this value to an empty string.
Sys.setenv(CI = "")

options(
  # restrict validation dependency installs to only known CRAN repos
  repos = c(
    RocheCRAN = "https://rspm.roche.com/CRAN/latest",
    CRAN = "http://cloud.r-project.org"
  ),

  # improve gitlab ci log output when errors are encountered
  error = function() {
    cat(geterrmessage(), "    \n")
    traceback()
  }
)

minimal_autovalidateutils_install()
