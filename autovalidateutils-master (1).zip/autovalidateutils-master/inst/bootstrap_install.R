# determine package path based on relative location of source inst directory
.autovalidateutils_path <- normalizePath(dirname(dirname(sys.frame(1)$ofile)))



#' Bootstrap the installation of autovalidateutils
#'
#' As many of the systems and images that autovalidateutils will be used on lag
#' behind recent package releases, upgrading all outdated dependencies often
#' affects an enormous package footprint. To minimize the affect that
#' installation has on the host system, we provide this minimal install script
#' to help with installation, prompting a minimal set of package updates.
#'
#' @param system A system name to bootstrap the installation for. If missing, a
#'   listing of available systems is printed.
#' @param autovalidateutils_path The path to the autovalidateutils package
#'   source code directory.
#' @param force If `TRUE`, reinstall `autovalidateutils`, checking again if any
#'   necessary dependencies need to be installed or upgraded.
#'
#' @examples
#' dontrun{
#' source("inst/bootstrap_install.R")
#' bootstrap_install("gitlab_ci")
#' }
#'
bootstrap_install <- function(
    system,
    autovalidateutils_path = .autovalidateutils_path,
    force = FALSE) {
  script_dir <- file.path(autovalidateutils_path, "inst")
  script_prefix <- "bootstrap_install_"

  # if system isn't provided, list available systems
  if (missing(system)) {
    script_prefix_regex <- paste0("^", script_prefix)
    scripts <- list.files(script_dir, pattern = paste0("^", script_prefix))
    scripts <- tools::file_path_sans_ext(gsub(script_prefix_regex, "", scripts))
    scripts <- gsub("[_-]", " ", scripts)

    message(
      "Please provide a valid system name. Available system choices: \n",
      paste(sprintf("  '%s'", scripts), collapse = "\n")
    )

    return(invisible(NULL))
  }

  # check provided system against available scripts
  system <- gsub("[ _-]", ".", system)
  script_pattern <- paste0("bootstrap_install_", system, "\\.R")
  script_path <- list.files(
    script_dir,
    pattern = script_pattern,
    full.names = TRUE,
    ignore.case = TRUE
  )

  script_path <- script_path[1L][[1L]]  # safely extract first if any

  if (is.na(script_path) || !file.exists(script_path)) {
    stop(sprintf(
      "Bootstrap installation script does not exist for system '%s'",
      system
    ))
  }

  # return if already installed
  if (!force && requireNamespace("autovalidateutils", quietly = TRUE)) {
    return(invisible(NULL))
  }

  original_options <- options()
  options(keep.source.pkgs = TRUE)
  on.exit(options(original_options))

  invisible(source(
    script_path,
    max.deparse.length = Inf,
    local = TRUE,
    echo = TRUE
  ))
}



#' Retrieve package dependencies
#'
package_deps <- function(pkgdir) {
  # come up with a list of version-constrained autovalidateutils dependencies
  fields <- c("Depends", "Imports", "Suggests", "LinkingTo")
  deps <- Filter(
    Negate(is.na),
    read.dcf(file.path(pkgdir, "DESCRIPTION"), fields = fields)
  )
  deps <- trimws(unlist(strsplit(deps, ",")))
  is_constrained <- grepl("\\(|\\)", deps)

  versioned_deps <- as.data.frame(
    t(sapply(deps[is_constrained], tools:::.split_op_version))
  )
  unversioned_deps <- data.frame(
    name = deps[!is_constrained],
    op = NA,
    version = NA,
    row.names = deps[!is_constrained]
  )

  rbind(versioned_deps, unversioned_deps)
}



#' Attempt to install autovalidateutils with minimal impact to environment
#'
#' Upgrade only necessary dependencies required to install autovalidateutils,
#' installing remotes only if dependency requirements can not be satisifed in
#' given repos.
#'
#' Indirect dependencies are not handled, and will not be updated if already
#' installed. If system packages do not meet indirect dependency version
#' constraints, installation will fail.
#'
minimal_autovalidateutils_install <- function(
    autovalidateutils_path = .autovalidateutils_path,
    ..., repos = getOption("repos"), force = FALSE) {

  original_options <- options("repos")
  options(repos = repos)
  on.exit(options(original_options))

  # if needed, start by installing remotes
  remotes_missing <- tryCatch(
    packageVersion("remotes") < package_version("2.4.0"),
    error = function(e) TRUE
  )

  if (remotes_missing) {
    install.packages("remotes", repos = "https://cloud.r-project.org")
  }

  # fetch package dependencies from DESCRIPTION
  deps <- package_deps(autovalidateutils_path)

  # find base packages
  inst <- installed.packages()
  avail <- available.packages()
  base <- c(
    "R",
    inst[!is.na(inst[, "Priority"]) & inst[, "Priority"] == "base", "Package"]
  )

  # iterate through version-constrained dependencies, updating packages whose
  # minimum version requirement is not met. Will install from CRAN if the
  # dependency can be satisfied by CRAN, or will defer to Remotes otherwise.

  # first handle any dependencies satisfiable on CRAN
  for (dep_i in seq_len(nrow(deps))) {
    dep <- deps[[dep_i, "name"]]
    op <- deps[[dep_i, "op"]]  # eg ">=" or "<"
    version <- deps[[dep_i, "version"]]

    if (dep %in% base) next
    is_installed <- dep %in% inst[, "Package"]
    is_available <- dep %in% avail[, "Package"]
    avail_version <- package_version(
      avail[avail[, "Package"] == dep, "Version"]
    )

    version_satisfied <- is_installed &&
      (is.na(op) || do.call(op, list(packageVersion(dep), version)))
    version_satisfiable <- is_available &&
      (is.na(op) || do.call(op, list(avail_version, version)))
    if (!version_satisfied && version_satisfiable) install.packages(dep)
  }

  authless_remotes_install_deps(
    autovalidateutils_path,
    upgrade = "never",
    ...,
    force = force
  )

  remotes::install_local(
    autovalidateutils_path,
    dependencies = FALSE,
    upgrade = "never",
    ...,
    force = TRUE
  )
}



#' Install remotes remote packages
#'
#' Installing packages from remotes sources.
#'
#' @note This code is a minimally modified version of the `remotes` package's
#'   `install_deps` function.
#'
#' @param upgrade Passed to remotes::update_packages.
#' @inheritParams remotes::dev_package_deps
#' @inheritParams remotes:::update.package_deps
#'
authless_remotes_install_deps <- function(
    pkgdir,
    dependencies = NA,
    repos = getOption("repos"),
    type = getOption("pkgType"),
    upgrade = "never",
    ...) {

  withr::with_envvar(c("R_REMOTES_STANDALONE" = "true"), {
    packages <- remotes::dev_package_deps(
      pkgdir,
      repos = repos,
      dependencies = TRUE,
      type = type
    )
  })

  # Running with dependencies TRUE and the filtering out cran packages
  # will ensure that we capture all remotes packages and not only
  # hard dependencies. (Otherwise suggests remotes were not cought)
  packages <- packages[!packages$is_cran, ]


  dep_deps <- if (isTRUE(dependencies)) NA else dependencies
  remotes:::update.package_deps(
    packages,
    dependencies = dep_deps,
    type = type,
    repos = repos,
    upgrade = upgrade,
    ...
  )
}
