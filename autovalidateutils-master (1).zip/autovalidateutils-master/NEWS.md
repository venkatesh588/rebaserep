# autovalidateutils 2.3.4

* Add additional ESC ansi signs striping to the reverse dependency check output
  as they could prevent pdf generation.
  
# autovalidateutils 2.3.3

* Add "summary is missing" note to the vulnerabilities summary if the API
  response didn't have one.

# autovalidateutils 2.3.2

* Add check testing whether validation package has been properly installed
  and terminate with a meaningful message if not.

# autovalidateutils 2.3.1

* Refactor unit tests to not use `miniCRAN`.

# autovalidateutils 2.3.0

* Use `options` package to govern various optional behaviors replacing native
  options system.
* Remove `revdepcheck` dependecy and steps based on this package.
* Remove `pkgbuild` from Imports and move `prettyunits` to Suggests

# autovalidateutils 2.2.4

* Add `add_missing_traces` to add more flexability in how traceability matrix is
  generated.
* Add a step to to junit readin which will make a hard copt of the original
  file before any processing is applied.

# autovalidateutils 2.2.3

* Add `reuse_check_source` option to facilitate rare edge case when broader
  spectrum of reliable test is available if we skip .Rbuildignore step.

# autovalidateutils 2.2.2

* Add `rd_transform` option to allow rd objects manipulation before they are
  tunred into markdown files.

# autovalidateutils 2.2.1

* Cross check junit file and traceability matrix to make sure they have the same
  set of tests.

# autovalidateutils 2.2.0

* Add new validation step - Recording package's vulnerabilities

# autovalidateutils 2.1.3

* Normalize `cov_tmp_tests_dir` in the `safe_package_coverage` to remove
  possible Windows file separators (https://github.com/r-lib/covr/pull/593)

# autovalidateutils 2.1.2

* Add `description` to the set of values of the `mapper.yaml` which are driven
  by the `"mapper_defaults"`.

# autovalidateutils 2.1.1

* Remove skipped tests from the junit file before writing down the junit file
  to show statuses reflected by the exacted lines and not artificial skipped
  entries.

# autovalidateutils 2.1.0

* Remove the package under validation from `checked` graph when running
  reverse dependency check for packages not available in the remote repository,
  but with reverse suggested dependecies.
  
* Change lib.loc passed to the `checked` while running reverse dependency check
  to makes sure `autovalidateutils` dependencies are not used while running 
  package validation.

# autovalidateutils 2.0.9

* Use `covr` fork https://github.com/dgkf/covr.git@dev with `dev` branch to
  allow quick bugfixes application and prevent the code from sudden changes.

# autovalidateutils 2.0.8

* Expose the option `"mapper_defaults"` to toggle whether placeholder values
  should be inserted into a `mapper.yml` file (!280 @kelkhofd)

# autovalidateutils 2.0.7

* Exposes the option `"junit_reporter"` to customize the reporter used for
  generating `junit.xml` files (!249 @kelkhofd)

# autovalidateutils 2.0.6

* Run garbage collector after each step finishes to make sure big objects
  (like covr files) are removed from the memory when they are no longer required.
  
# autovalidateutils 2.0.5

* Further improvements to functionalities used to compare changes in libraries 
  between environments.
  
# autovalidateutils 2.0.4

* Update utility functions for environment comparison to reflect changes in
  libraries.
  
# autovalidateutils 2.0.3

* Improve quality of the cohort sanity check preventing possible false-negative
  errors for base packages.
  
# autovalidateutils 2.0.2

* Reintroduce `write_revdep_check` step. As before, all reverse dependency
  check steps continue to be disabled by default, but this means that specifying
  non-default sets of steps may want to revise their strategy to avoid
  redundant reverse dependency checks (e.g. specifying `"-write_revdep_check"`
  to enable reverse dependency checks with `checked` while continuing to
  disable `revdepcheck` checks). (!251 @kelkhofd)

# autovalidateutils 2.0.1

* Implement repository sanity check, which will prevent validation if core
  dependencies of any reverse dependency are not available in the repository.

# autovalidateutils 2.0.0

* Refactor reverse dependency check functionality to use `checked` package.

# autovalidateutils 1.9.9

* Use covr segfault patch

* Make `avu_r_cmd_check` use source of the package allowing re-build with our options

* Remove covtracer from Remotes in DESCRIPTION
  
# autovalidateutils 1.9.8

* Revert changes implemented in `1.9.6` and `1.9.5`

* Make `write_traceability_matrix` use source generated in `avu_r_cmd_check`
  if it exists.
  
# autovalidateutils 1.9.7

* Add `update_r_recommended` helper and use it to force update of all recommended
  packages before installing other dependecies.

# autovalidateutils 1.9.6

* Add `autovalidate.source` to support metadata management.

* `avu_r_cmd_check` function will now used tarball instead of the raw source.
  
# autovalidateutils 1.9.5

* When running autovalidate from source or git build the package first and
  proceed with validation from such tarball. This assures .Rbuildignore
  is properly applied and excludes certain files. 

# autovalidateutils 1.9.4

* Revert `vars_to_unset` change (v. 1.7.4). It was too complicated (or even impossible)
  to propagate downstream considering our separate processes architecture.

# autovalidateutils 1.9.3

* Enforce ASCII//TRANSLIT encoding for the NEWS file to make sure no file file
  with special characters not supported by pandoc is generated.

# autovalidateutils 1.9.2

* Isolate `Preparing junit file and matching with traceability matrix` step
  in the `write_traceability_matrix`.
 
# autovalidateutils 1.9.1

* Escape `001` - `010` octal characters in test names when adding 
  `additional covr traces` in the `write_traceability_matrix`

# autovalidateutils 1.9.0

* Partially refactor `avu_install` by extracting helper functions and adding an
  option to customize installation order (@maksymis)
  
* Add `avu_isolated_process` function allowing to run arbitrary `callr` processes
  which are preconfigured to validation work.

# autovalidateutils 1.8.0

* Separate processes installing packages in the `avu_install` internal will
  now always use `remotes` loaded when autovalidateutils was initially loaded
  instead of whatever `remotes` was first on the search path.

* Add `additional_repositories` parameter support to the `avu_install` function.

# autovalidateutils 1.7.10

* Add `r_cmd_check_clean_tests` option. If TRUE it will remove all the directories
  in the <pkg>.Rcheck/<pkg>/tests to reduce the size of the output.

# autovalidateutils 1.7.9

* Enhance `testthat_is_on_cran` and `testthat_is_on_cran` internals to prevent
  failures when running with legacy versions of testthat (3.5.2 validation) (@maksymis)

# autovalidateutils 1.7.8

* Bugfix callr legacy support (@maksymis)
  
# autovalidateutils 1.7.7

* Limit the size of the output generated by the autovalidateutils' R CMD check
  step by removing redundant directories. (@maksymis #263)

# autovalidateutils 1.7.6

* Make sure R environment related sys variables are properly unset in separate 
  processes in lower versions of the callr package (below 3.7.0).

# autovalidateutils 1.7.5

* `autovalidate.http` renames the source of the package to generic package.<ext>
  file to make sure unaccepted signs are not picked up from the URL.
  
* `avu_r_cmd_check` now always runs `rcmdcheck` against the extracted source.

# autovalidateutils 1.7.4

* Add `vars_to_unset` parameter to `autovalidate`, as well as global option 
  `autovalidateutils.vars_to_unset`, used as its default value. Environment
  variables passed as part of this vector will be unset for the run time of the
  autovalidate and re-assigned their original value on exit.

# autovalidateutils 1.7.3

* Make `autovalidate.package` strip any non-utf8 signs from the DESCRIPTION
  file before processing it to prevent failures in the `remotes::install_local`
  (@maksymis)
  
# autovalidateutils 1.7.2

* Make `avu_prepare_news_file` enforce UTF-8 encoding to avoid issues with
  report rendering. (@maksymis)

# autovalidateutils 1.7.1

* Save `stderr` and `stdout` generated by the covr subprocess to the log files.

# autovalidateutils 1.7.0

* Make sure that requirements are generated from documentation objects 
  even if coverage calculations failed. (@maksymis)

* Use `stringsAsFactors = FALSE` in `prepare_coverage_df` to ensure compatibility
  with legacy R versions. (@maksymis)
  
* Add `skip_if` parameter to the `avu_cli_task` allowing to directly skip certain
  tasks during validation.

# autovalidateutils 1.6.11

* Add lib.loc to the `installation_libpath` in `avu_install` and rename the
  variable to install_libpaths_w_remotes
  
* Add `avu_upgrade_value` option to add more control over what dependencies are
  installed if deafult value of `upgrade_deps` option is used. Also change the
  deafult to NULL

# autovalidateutils 1.6.10

* Add `covtraver_debug` option and `run_covtracer` helper that depending on the
  value of the option runs covtracer either in a separate process or in the main
  one.

# autovalidateutils 1.6.9

* Extend list of fields in the R CMD check output that we strip ANSI signs
  from by `c("errors", "warnings", "notes")`.

* Replace ref for `covr` remote source from `main` to `dgkf-min-dup-tests`.

# autovalidateutils 1.6.8

* Replace `crayon::strip_style` with `cli::ansi_strip` as it covers broader
  spectrum of ANSI stop signs when clearing up the output.

# autovalidateutils 1.6.7

* Create `avu_remove_duplicates` which is an autovalidate version of the 
  `tools:::.remove_stale_dups` internal which filters available.packages output.
  It will choose the latest avialable pacakge within first repo on the list.

# autovalidateutils 1.6.6

* Add `env = c("R_PROFILE" = "")` and `system_profile = FALSE` to the revdepcheck
  separate process.
  
* Refactor logging  strategy for revdepcheck separate process

# autovalidateutils 1.6.5

* Refactor mechanism of discovering NEWS files. Include `inst/NEWS.Rd` support
  which is one of the official ways of providing NEWS files endorsed in R 
  (`?utils:::news`).

# autovalidateutils 1.6.4

* Hotfix directory structure making sure it is present before installing
  dependencies
  
# autovalidateutils 1.6.3

* Run separate processes with system profile disabled (`system_profile = FALSE`)
  and with `env = c("R_PROFILE" = "")` set to prevent R internals picking up
  these. Instead, copy options from the main process to the subprocess to make
  sure vital options from the Rprofile are used by the subprocess anyway.

# autovalidateutils 1.6.2

* Install the package under validation in a separate process to make sure that
  autovalidateutils dependencies will not conflict with packages' dependencies.

* Add `env = c("R_PROFILE" = "")` to subprocesses that install the package 
  under validation to make sure `.Rprofile` will not be picked up potentially
  affecting libPaths.

# autovalidateutils 1.6.1

* Add `junit_validate()` that checks whether JUnit file could be parsed as 
  valid xml file. If the file is invalid, function tries to repair. If the xml
  file could not be repaired, function returns an error as without it 
  traceability matrix is impossible. 

# autovalidateutils 1.6.0

* If the package is unavailable in `getOption("repos")` but it has suggests
  reverse dependencies, setup a temporary miniCRAN repo to allow revdepcheck
  to run.
  
* Add callbacks to autovalidate. They are quoted code that might be generated
  by each step and are evaluated at the very end of `autovalidate` run.

# autovalidateutils 1.5.6

* Strip coloring in these parts of the rcmdcheck output that are included in the 
  report. ESC sign (also known as \e or \033) used to indicate start of the 
  colored string cannot be rendered by markdown and crashes it. By default 
  rcmdcheck should strip it for us but in some cases it could go through hence 
  we need to remove it as a safety fuse.

# autovalidateutils 1.5.5

* Install validated package before installing suggested packages (DEP_LIB_OPTIONAL)
  to avoid multiple installations and version conflicts.

# autovalidateutils 1.5.4

* Enhance coverage logging when running testthat. Add new 
  `testthat::LocationReporter` deeper insight into exceptions calls, particularly
  useful when debugging C++ tests, as well as save results of 
  the `testthat::SummaryReporter` to the file.

# autovalidateutils 1.5.3

* Add `revdep_clean_sources` and `revdep_clean_library` options. When set to 
  true, sources of reverse dependencies and package being tested alongside tests 
  snapshots are removed to reduce `revdep` output size. (@maksymis #241)
  
# autovalidateutils 1.5.2

* Removes `default_steps()` function, replaced with `steps()` and a new option,
  `autovalidateutils.steps`. The default steps will remain unchanged, but this
  will make it easier to customize running steps and expose the configuration to
  CI runners. (@kelkhofd #244)

# autovalidateutils 1.5.1

* Add `user_profile = FALSE` parameter to `callr::r()` and `callr::r_bg()` to
  make sure that user (project) .Rprofile won't be read while running
  these processes.

# autovalidateutils 1.5.0

* Move testing session sessionInfo generation to coverage custom code section 
  (`package_coverage_*_code`) to more accurately capture packages used during 
  testing.

* Add `Check environment configuration` task and include `on_cran`
  and `on_ci` configuration discovery messages. 

# autovalidateutils 1.4.2

* Allow system profile in the `callr::r` and `callr::r_bg` and explicitly
  specify proper repositories.

# autovalidateutils 1.4.1

* Install validation dependencies in separate process to avoid loaded
  autovalidateutils dependencies interfering with installation process

# autovalidateutils 1.4.0

* Mark `additional covr traces` tests as unkown if R CMD check reported any tests
  failures and testthat infrastructure was not detected. 

# autovalidateutils 1.3.7

* Fix the bug causing non-testthat tests description (calls) to not be quoted if 
  at least one testthat trace was captured during coverage calculation.

# autovalidateutils 1.3.6

* Make `write_r_cmd_check_yml` function no longer read `cran-comments.md` meaning
  the function will always emit warnings if any gaps in `R CMD check` are
  identified.
  
# autovalidateutils 1.3.5

* For non testthat traces in traceability matrix wrap descriptions with enough 
  backticks so internal "`" do not invalidate matrix's renderability.

# autovalidateutils 1.3.4

* Add `.git@*tag` and `.git@*tag=~<regex>` syntax for package sources, allowing
  for specifying that `autovalidateutils` take the latest commit, or latest
  commit that matches some pattern. Patterns may include the `[:version:]`
  shorthand to match any valid R package version number. (#224, #226 @kelkhofd)

# autovalidateutils 1.3.3

* Wrap interactive coverage report creation with `tryCatch`, preventing
  errors in report generation from terminating `autovalidate()`. (#225 @maksymis)

# autovalidateutils 1.3.2

* Execute `revdepcheck::revdep_check` with `available_packages_filters` option
  that changes default filters used by `available.packages`() making sure
  that packages dependencies for reverse dependency check are picked up
  according to repos priority (@maksymis)
  
# autovalidateutils 1.3.1

* Add validation library to packages skipped in `write_packages_lock_json` (@maksymis)

# autovalidateutils 1.3.0

* Prioritize hard dependencies when sampling packages in reverse dependency
  check.  (@maksymis)
* Increase internal revdepcheck timeout and make autovalidateutils' option
  to control the value.  (@maksymis)
* Add packages with "PREPERROR" status to problems.md file. (@maksymis)
* Run interactive coverage report generation in the separate process 
  to make sure packages suggested by autovalidateutils are loaded in appropriate
  version (@maksymis)

# autovalidateutils 1.2.5

* Add log file that documents output and possible errors in the revdep 
  subprocess. (#220 @maksymis)

# autovalidateutils 1.2.4

* Change `avu_libpaths` order (@maksymis).

# autovalidateutils 1.2.3

* Switch back to `r-lib/remotes` remote source for the `remotes` package (@maksymis).

# autovalidateutils 1.2.2

* Add `generalize_sources` option that makes autovalidateutils rename
  source of the package and built binariy to generalized, agnostic, name that can
  be used in production (@maksymis).

# autovalidateutils 1.2.1

* Add `build_binaries` option that makes autovalidateutils build binary
  source of the package when TRUE (@maksymis).

# autovalidateutils 1.2.0

* Run revdepcheck in randomized order (@maksymis).
* Make revdepcheck check more verbose regarding its actions when timeout occurs.

# autovalidateutils 1.1.10

* Add `testing_session` option to specify where coverage sub-process sessionInfo
  should be saved.
* Add sessionInfo saving mechanism to `safe_package_coverage`

# autovalidateutils 1.1.9

* Improve dependencies versions discovery process in `check_dependency_availability`

# autovalidateutils 1.1.8

* Pass `args` which is a named list of essentially parameters to step functions.
* Exclude Enhances and Suggests libraries from `write_packages_lock_json`

# autovalidateutils 1.1.7

* Store packages' log directories in `packages` sub directory in the `log_output` 
  directory. (@maksymis)
* Store migrate `sessioninfo.json` to the `log_output` (@maksymis)
* Add `write_packages_lock_json` and `compare_validation_env` functions for creating and
  comparing installed packages log and assesing whether recreation is possible.
  (#208 @maksymis)
  
# autovalidateutils 1.1.6

* Add sessionInfo json to the validation output. (#205 @maksymis)

# autovalidateutils 1.1.5

* Add `use_remotes` option allowing more flexibility in managing remotes 
  packages sources. (#201 @maksymis)
* Add `lib.loc` option (#204 @maksymis)
* When remote package name returned by `remotes::dev_package_deps` is NA
  but the package is still available, clone it to derive whether it should
  be installed.
  
# autovalidateutils 1.1.4

* Execute `install_validation_dependencies` with `available_packages_filters`
  that changes default filters used by `available.packages`() making sure
  that packages are installed according to repos priority (#202 @maksymis)

# autovalidateutils 1.1.3

* Execute `install_validation_dependencies` with `R_REMOTES_STANDALONE` env 
  variable set to true in order to allow avu pickup git credentials from the 
  store

# autovalidateutils 1.1.2

* Change the way in which unavailable remote sources packages are skipped

# autovalidateutils 1.1.1

* Add `remote_precedence` when running `remotes::dev_package_deps` in the 
  `install_validation_dependencies`.
* Remove covr form Remotes section as CRAN version got updated.

# autovalidateutils 1.1.0

* Refactor of remove some obsolote parts of the code (#193 @maksymis)
* Restructure some of existing unit tests (#193 @maksymis)
* Address todo comments in the code (#193 @maksymis)
* Improve coverage by adding new test (#193 @maksymis)

# autovalidateutils 1.0.6

* Improve the revdepcheck execution by enhancing the messages returned by it
* Enhance tests

# autovalidateutils 1.0.5

* Change condition for checking if a package is available in 
  `install_validation_dependencies`

# autovalidateutils 1.0.4

* Use cran = FALSE option in the revdepcheck

# autovalidateutils 1.0.3

* Bugfix `package_coverage_test_code` not setting up proper file path
  for tools::testInstalledPackage like `covr::package_coverage` does.

# autovalidateutils 1.0.2

* Reintroduce some markdown special character escaping (removed in #181), while
  continuing to escape additional unicode characterrs (!155 @kelkhofd).

* Adding option `"inst_deps"` to select which dependency types are permitted to
  be installed during validation (!127 @kelkhofd)

* Update to bootstrapping scripts to ensure minimum `remotes` version used to
  process dependencies.

* R version info is now logged in the `session.yml` artifact file.

* Isolating covtracer execution to a child process to avoid picking up packages
  loaded by `autovalidateutils` itself (!116 @kelkhofd)

* Now filters reexports from exported objects requiring coverage (!112
  @kelkhofd)

* Added scripts for managing a minimal install into /inst. Scripts were added
  specifically to address installation within CI, but also known production
  systems which may require specific dependency version upgrades.

* Added support for remotes-style `repo@ref` shorthand when providing package to
  `autovalidate` as a git remote url. (!100 @kelkhofd)

* `rcmdcheck::rcmdcheck` function is now run within `withr::with_envvar` to 
  ensure that environmental variables are mocked for check run time. The mocked
  variable is `_R_CHECK_FORCE_SUGGESTS_ = FALSE`. (#117, @maksymis)
  
* Fix for malformed git version control metadata when sourced from a local
  source code directory. (!98 @kelkhofd)
  
* Fix test requirements for traceability matrix being incorrectly enumerated 
  for some edge cases. (#121 @maksymis)

* Add additional condition in `write_traceability_matrix` checks, to first assure
  whether coverage returned by `covr` is actually a finite number that can be 
  compered with `<` and `>=` operators. (#124 @maksymis)
  
* Add `escape_latex_calls` helper function that will help to maintain control
  over the regular expressions used to escape latex calls embedded in markdown
  package's metadata.

* Make sure that the content of cran-comments.md from the source of the R package
  is properly copied to the output metadata (#125 @maksymis)
  
* Remove LaTeX escaping (escape_latex_calls() function) as it was handled down stream
  (#126 @maksymis)
  
* Add explicit unit tests for `documentation_to_markdow` function (#31 @maksymis)
  
* Make sure that the autovalidateutils will not fail for a package that does not 
  have any testable code (#129 @maksymis)

* Refactor `uses_testthat` function to check not only if test folders exists but
  also if it is non-empty. (#7 @maksymis)

* Rename parameter of `safe_package_coverage` function (`uses_testthat` -> `uses_testthat_flag`) 
  to avoid ambiguity with the internal function that shared the same name. (@maksymis)
  
* Change the default value of `uses_testthat_flag` parameter in `safe_package_coverage` function 
  to use internal version of `uses_testthat` function instead of unstated devtools 
  dependency (`devtools::uses_testthat`). (@maksymis)

* Add `use_testthat` option that states whether testthat infrastructure should be
  be allowed to use during building up traceability matrix and calculating coverage.
  Setting to FALSE will force agnostic way of test execution. 

* Copy `rmarkdown:::partition_yaml_front_matter` as an unexported helper `partition_yaml_front_matter`. 
  Use this to strip potential yaml header from the NEWS files (#127 @maksymis)

* Add `clean` option and make autovalidateutils clean up the /tmp/Rtmp* directory 
  on.exit if it is true. (#132 @maksymis)
  
* Add `req_deps` internal option to control dependencies of which type should all be installed
  before validation. (@maksymiuk)

* Fix the bug causing the `check_dependency_availability` function to not take required dependencies
  types into account while determinating what packages are satisfiable. (#134 @maksymis)

* Allow core dependencies to be installed to appropriate temporary libraries 
  if they are available in provided repos (!117 @maksymis)
  
* Add `suggests_repos` option that is a character vector of libraries that will 
  be appended to standard repos during installation of suggested packages (!117 @maksymis)

* Import rd2markdown package and use it to convert documentation objects into 
  markdown. Remove Rd2md functions family and helpers. 
  Add `append_indices_to_documentation` helper (!118 @maksymiuk)

* Fix the bug causing the `avu_install` to not properly append `suggests_repos`
  to to the suggests and enhances dependencies installation process. (#146 @maksymis)

* Bug-fix R version extraction. Previous implementation did not work on some old
  releases. (#147 @maksymis)

* Add `log_output` option that sets a path where log files coming from
  autovalidate exaction will be saved. (#148 @maksymis)

* If `autovalidate` stops because of missing dependencies, dump information about
  missing dependencies into a log file in `log_output`. (#148 @maksymis)

* Print actual coverage when warning about coverage below the threshold. (#152 @maksymis)

* Refine `check_if_no_code_to_test` internal to check only for content in ./R/

* Add `r_cmd_check_variables` option that can be used to manipulate environmental
  variables set while running the check. 
  
* Reorganize imports and dependencies so that packages that we use in autovalidateutils
  are always loaded when autovalidateutils is loaded. (#153 @maksymis)

* Skip the coverage part if the NAMESPACE file does not have any other lines than "" 
  or starting with "#". (#163 @maksymis)

* Execute `safe_package_coverage` in `try()` (#163 @maksymis)

* Fix the bug causing non-tested function to be accidentally stripped from 
  the traceability matrix (#166 @maksymis)
  
* Store interactive coverage reports (#164 @maksymis)

* Don't write sonarqube file as part of the validation output (#160 @maksymis)

* Run coverage in a separate process (#167 @maksymis)

* Create coverage matrix with percentages for each file and the entire 
  package (#168 @maksymis)

* Use stringi package to escape special ASCI characters (#168 @maksymis)

* Wrap traceability matrix tests descriptions with back ticks if the trace was
  recovered from call, and escape markdown characters if it comes from testthat
  description (#175 @maksymis)
  
* Fix the way unmet dependencies are serialized if package appeares in DESCRIPTION
  file more than once (#176 @maksymis)

* Make revdepcheck run in a separate process. Add timeout option and use it as 
  `timeout` parameter to `callr::r_vanilla` function. (#172 @maksymis)

* Replace `covr_library()` with `package_library()` and `package_to_lib()` 
  helpers (#172 @maksymis) 

* Pass `package_to_lib("covtracer")` to .libPaths of callr subprocesses using
  covtracer package functions. (#177 @maksymis) 

* Make libPaths used within the package's run time use original libPaths at the
  end. Fix minor issues releted to running other packages in separate processes
  (#180 @maksymis) 

* Replace `escape_markdown_special` with `stringi::stri_escape_unicode` in the
  `write_traceability_matrix` function (#181 @maksymis) 
  
* Add `installed` to `unmet_deps.json` file output in 
  `check_dependency_availability()`  (#184 @maksymis) 

* Refine `avu_cli_task` making it display current step at the beginning and at
  the end, rather than only at the end. (#183 @maksymis) 

* Refactor `avu_install`. (#186 @maksymis) 

* Change `use_testthat` option default value to FALSE.

* Bugfix behavior of `install_validation_dependencies` when `upgrade` parameter 
  is set to `TRUE`.

# autovalidateutils 1.0.1

* Vignette building has been separated into a separate validation step, which 
  is allowed to fail. Pre-built package bundle (.tar.gz's) vignettes will not
  be re-built. (!82, @kelkhofd)

* Added controls for library path handling. By default, when installing necessary 
  validation target dependencies, only default system libraries are considered
  for already-satisfied dependencies (.Library, .Library.site). (!71, @kelkhofd)

* Restructured version_control.yml output produced by write_git. No longer
  contains a top-level "git" key. (!81, @kelkhofd)

# autovalidateutils 1.0.0

* Initial release!

* Reduced dependency footprint, namely removing `devtools` dependency which
  comes at quiet a heavy indirect dependency footprint. (!26, @kelkhofd) 

* Addressed bugs in older R versions, now vetted back to v3.5.2. Please report
  bugs if used on older R versions! (!16, !21, !22, @kelkhofd)

* `autovalidate` now uses `avu_install` handles installation of the target
  package into temporary libraries, offering the ability to handle dependencies
  by dependency type (!26, @kelkhofd)

* Adds `autovalidate` generic, allowing `autovalidateutils` to accept a wide
  assortment of input types (!26, @kelkhofd)

# autovalidateutils 0.0.0.9000

* Adding package foundation, with some basic functionality for exporting common
  R package documents in an interchange format. 

