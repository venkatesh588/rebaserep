# Contribution Guidelines

## New Contributors

- Question-and-answer support should be directed to [Roche
  Overflow](https://overflow.roche.com/c/autovalidate/autovalidate-r/214)
- Bug reports and feature requests welcome - please use the respective issue
  templates.
- Feel free to fork the project and experiment with changes
- Reach out to the developers before embarking on major changes so that we can
  anticipate your contributions and help align your design with our development.

## Development Workflow

- We follow a [Github flow](https://guides.github.com/introduction/flow/) for development. 
- The `master` branch is always protected.
- The `master` branch contains the released versions of the `autovalidate` package as *tagged* commits.
- We follow a conventional semantic version numbering: `major.minor.patch` or `0.0.0`.
- This version should be reflected in the `DESCRIPTION` file of the package.
- Each new change to the version number should be accompanied with an annotated
  [git tag](https://git-scm.com/book/en/v2/Git-Basics-Tagging) (use `git tag -a
  <version number> -m "some comment"`).
- Each major behavioral change following an initial release should be
  accompanied by an entry in `NEWS` ("\* new feature (#123, @kelkhofd)")
- Make sure the tag is pushed to the repo with `git push origin --tags`
  (alternatively config your local env so that tags are always pushed).
- For bug fixes and feature additions, first file an issue documenting the bug
  and preferrably create a branch and merge request off of the issue, using
  GitLab's issue naming convention `<issuenum>-description of issue` so that the
  branch is tracked by the issue.
