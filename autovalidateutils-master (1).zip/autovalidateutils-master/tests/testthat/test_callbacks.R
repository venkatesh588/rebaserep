test_that("avu_callback reads corret attribute", {
  object_correct <- structure(TRUE, callback = function() 2 + 2)
  object_incorrect <- structure(TRUE, callb = function() 2 + 2)

  expect_true(is.function(avu_callback(object_correct)))
  expect_true(avu_callback(object_correct)() == 4)
  expect_null(avu_callback(object_incorrect))
})

test_that("add_avu_callback appends callbacks list", {
  object_w_callbacks <- structure(TRUE, callback = list(function() 2 + 2))
  object_wo_callbacks <- TRUE

  object_w_callbacks_appended <-
    add_avu_callback(object_w_callbacks, function() 3 + 3)
  object_w_callbacks_added <-
    add_avu_callback(object_wo_callbacks, function() 3 + 3)

  expect_true(is.list(avu_callback(object_w_callbacks_added)))
  expect_true(is.list(avu_callback(object_w_callbacks_appended)))
  expect_true(avu_callback(object_w_callbacks_appended)[[2]]() == 6)
  expect_true(avu_callback(object_w_callbacks_appended)[[1]]() == 4)
  expect_true(avu_callback(object_w_callbacks_added)[[1]]() == 6)

  expect_error(add_avu_callback(object_w_callbacks, list()))
})

test_that("with_avu_callback adds corret attribute", {
  expect_true(with_avu_callback(TRUE, function() 2 + 2))
  expect_null(avu_callback(with_avu_callback(TRUE, NULL)))
  expect_true(is.list(avu_callback(with_avu_callback(TRUE, list()))))
})
