#' @export
hypotenuse <- function(...) {
  return(sqrt(sum(vapply(list(...), `^`, numeric(1L), 2))))
}
