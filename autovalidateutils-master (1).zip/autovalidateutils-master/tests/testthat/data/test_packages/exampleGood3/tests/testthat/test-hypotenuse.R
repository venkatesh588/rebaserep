test_that("hypotenuse is calculated correctly", {
  expect_equal(hypotenuse(3, 4), 5)
})


test_that("hypotenuse is calculated correctly but skipped", {
  hypotenuse(3, 4)
  skip("This test shall be skipped")
  expect_equal(hypotenuse(3, 4), 5)
})
