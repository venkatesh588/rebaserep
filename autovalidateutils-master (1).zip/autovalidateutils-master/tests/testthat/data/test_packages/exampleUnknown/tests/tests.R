library(exampleOkay)

hypotenuse(1, 2)
