test_that("hypotenuse is calculated correctly (expected to fail)", {
  # The test is expected to fail
  expect_equal(hypotenuse(3, 4), 6)
})

test_that("hypotenuse is calculated correctly", {
  # Expected to fail
  expect_equal(hypotenuse(3, 4), 5)
})

test_that("hypotenuse is calculated correctly (expected to fail)", {
  # Expected to fail
  result <- hypotenuse(3, 4)
  stop("I'm supposed to fail")
  expect_equal(result, 5)
})
