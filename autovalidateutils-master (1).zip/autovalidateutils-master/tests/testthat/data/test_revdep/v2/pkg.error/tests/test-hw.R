library(pkg.error)
stopifnot(hello_world() == "hello world!")
