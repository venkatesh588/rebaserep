#' Hello world
#'
#' @export
hello_world_wrapper <- function() {
  pkg.error::hello_world()
}
