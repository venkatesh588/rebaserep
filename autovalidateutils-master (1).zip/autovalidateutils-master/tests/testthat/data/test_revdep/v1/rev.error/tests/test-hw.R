library(rev.error)
stopifnot(hello_world_wrapper() == "hello world")
