library(pkg.ok)
stopifnot(hello_world() == "hello world")
