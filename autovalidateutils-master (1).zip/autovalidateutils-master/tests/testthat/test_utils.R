test_that("escape_markdown_special helper works", {
  test_string <- c(
    "\\some_tex\\t",
    "`",
    "*",
    "_",
    "{",
    "}",
    "[dasda",
    "[adada]",
    "<",
    ">",
    "~~character~~"
  )
  expect_error(escaped_string <- escape_special(test_string), NA)

  escaped_expected <- c(
    "\\\\some\\_tex\\\\t",
    "\\`",
    "\\*",
    "\\_",
    "\\{",
    "\\}",
    "\\[dasda",
    "\\[adada\\]",
    "\\<",
    "\\>",
    "\\~\\~character\\~\\~"
  )
  expect_identical(escaped_string, escaped_expected)

  expect_identical(escape_special("|"), "\\|")
  expect_identical(escape_special("\\"), "\\\\")
})

test_that("package_to_lib works as expected", {
  inst_covr <- matrix(
    c("1.2.3", "2.3.4"),
    nrow = 2L,
    dimnames = list(c("covr", "covr"), "Version")
  )

  # double check that our test makes a reasonable assertion; should always be
  # true if our autovalidateutils dependencies are satisfied for testing
  expect_true(all(vapply(
    inst_covr,
    function(v) package_version(v) < packageVersion("covr"),
    logical(1L)
  )))

  mockery::stub(package_to_lib, "installed.packages", inst_covr)
  temp_tt_lib <- tempfile("testthat_temp_lib_")
  dir.create(temp_tt_lib)
  expect_silent(lib_status <- package_to_lib("covr", temp_tt_lib))
  expect_true(lib_status)
  expect_true(length(list.files(temp_tt_lib)) > 0L)

  # unmock; passing lib.loc directly
  mockery::stub(package_to_lib, "installed.packages", installed.packages)
  expect_false(package_to_lib("covr", temp_tt_lib))
})

test_that("expand_regex_version_class expands [:version:] to package version", {
  re <- "v[:version:]"
  expect_silent(re_sub <- expand_regex_version_class(re))
  expect_equal(re_sub, paste0("v", .standard_regexps()$valid_package_version))
})

test_that("ref_tag_pattern parses tag regex, expands [:version:]", {
  pkg_v_re <- .standard_regexps()$valid_package_version
  re <- "*tag=~v[:version:]"
  expect_silent(re_sub <- ref_tag_pattern(re))
  expect_equal(re_sub, paste0("^v", pkg_v_re, "$"))
  expect_match("v1.2.3", re_sub)
  expect_no_match("1.2.3", re_sub)
  expect_no_match("v1.2.3rc", re_sub)
  expect_no_match("v1.2.3rc1", re_sub)
})


test_that("code_backticks works as epxected", {
  text_1 <- "Normal text"
  text_2 <- "Text with `singular` backticks"
  text_3 <- "Text with `singular` and ``double`` backticks"
  text_4 <- "```Text with `singular` and ``double`` [backticks]```"

  expect_equal(
    code_backticks(text_1),
    "` Normal text `"
  )
  expect_equal(
    code_backticks(text_2),
    "`` Text with `singular` backticks ``"
  )
  expect_equal(
    code_backticks(text_3),
    "``` Text with `singular` and ``double`` backticks ```"
  )
  expect_equal(
    code_backticks(text_4),
    "```` ```Text with `singular` and ``double`` [backticks]``` ````"
  )
  expect_equal(
    code_backticks(c(text_1, text_2)),
    c("` Normal text `", "`` Text with `singular` backticks ``")
  )
  expect_equal(
    code_backticks(c(text_1, text_2, text_3)),
    c(
      "` Normal text `",
      "`` Text with `singular` backticks ``",
      "``` Text with `singular` and ``double`` backticks ```"
    )
  )
})

test_that("testtht configuration functions work", {
  withr::with_envvar(c("NOT_CRAN" = "true"), {
    expect_false(testthat_is_on_cran())
  })
  withr::with_envvar(c("NOT_CRAN" = ""), {
    expect_true(testthat_is_on_cran())
  })
  withr::with_envvar(c("CI" = "True"), {
    expect_true(testthat_is_on_ci())
  })
  withr::with_envvar(c("CI" = "true"), {
    expect_true(testthat_is_on_ci())
  })
  withr::with_envvar(c("CI" = "false"), {
    expect_false(testthat_is_on_ci())
  })
  withr::with_envvar(c("CI" = ""), {
    expect_false(testthat_is_on_ci())
  })
})

test_that("avu_isolated_process properly configures environment", {
  expect_equal(
    avu_isolated_process(
      callr::r, function(var) Sys.getenv(var, unset = "Gotcha!"),
      list(var = "R_PROFILE"), env = c("R_PROFILE" = "Some file")
    ),
    "Some file"
  )
  expect_equal(
    avu_isolated_process(
      callr::r, function(var) Sys.getenv(var, unset = "Gotcha!"),
      list(var = "R_PROFILE")
    ),
    ""
  )

  withr::with_options(list("new_option_to_pass" = "value1"), {
    expect_equal(
      avu_isolated_process(
        callr::r, function(var) getOption(var),
        list(var = "new_option_to_pass")
      ),
      "value1"
    )
  })

  withr::with_options(list("repos" = "this_should_not_be_copied"), {
    expect_equal(
      avu_isolated_process(
        callr::r, function(var) getOption(var),
        list(var = "repos")
      ),
      ""
    )
  })

  withr::with_options(list("repos" = "this_should_not_be_copied"), {
    expect_equal(
      avu_isolated_process(
        callr::r, function(var) getOption(var),
        list(var = "repos"),
        repos = "new_repo"
      ),
      "new_repo"
    )
  })
})

test_that(
  "avu_path builds paths, optionally starting from last absolute element",
  {
    expect_equal(avu_path("a", "b"), file.path("a", "b"))
    expect_equal(avu_path("a", "/b", "c"), file.path("/b", "c"))
  }
)
