test_that("avu_prepare_news_file converts markdown headers to hash-style", {
  expect_true(file.exists(file.path(good, "NEWS.md")))
  # originally underlined
  expect_true(any(grepl("---", readLines(file.path(good, "NEWS.md")))))
  expect_message(
    # converted to hash-style
    expect_true(any(grepl("# package", avu_prepare_news_file(good)))),
    "Processing NEWS"
  )
})

test_that(
  "avu_prepare_news_file brackets non-markdown in preformatted code block",
  {
    expect_true(file.exists(file.path(okay, "NEWS"))) # originally non-markdown
    expect_message(expect_true(any(grepl(
      "```", avu_prepare_news_file(okay)
    ))), # wrapped in markdown code block
    "Processing NEWS")
  }
)

test_that("avu_prepare_news_file produces a message if no NEWS file is found", {
  expect_true(!file.exists(file.path(bad, "NEWS")))
  suppressMessages(expect_message(avu_prepare_news_file(bad), "No NEWS"))
  expect_silent(avu_prepare_news_file(bad, quiet = TRUE))
  expect_true(is.null(avu_prepare_news_file(bad, quiet = TRUE)))
})

test_that("write_news_md writes out formatted NEWS to markdown file", {
  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)
  expect_silent(suppressMessages(write_news_md(good)))

  expect_true(file.exists(file.path(dir, "news.md")))
  expect_true(length(readLines(file.path(dir, "news.md"))) > 0)
})
