test_that(
  "Newly-created JUnit test results files have top-level testsuites node",
  {
    expect_equal(
      xml2::xml_name(xml2::xml_find_first(junit_create(), "/*")),
      "testsuites"
    )
  }
)

test_that("junit_load_or_create loads existing files", {
  f <- tempfile("junit-test.xml")
  expect_silent(xml2::write_xml(xml2::xml_new_root("TEST"), f))
  expect_equal(
    xml2::xml_name(xml2::xml_find_first(junit_load_or_create(f), "/*")),
    "TEST"
  )
})

test_that("junit_load_or_create creates a file if no file exists at path", {
  f <- tempfile("junit-test.xml")
  expect_equal(
    {
      xml2::xml_name(xml2::xml_find_first(junit_load_or_create(f), "/*"))
    },
    {
      xml2::xml_name(xml2::xml_find_first(junit_create(), "/*"))
    }
  )
})

test_that("junit_test_names finds all available test case names", {
  x <- junit_create()
  xml2::xml_add_child(x, "testcase", name = "case_1")
  xml2::xml_add_child(x, "testcase", name = "case_2")
  xml2::xml_add_child(x, "testcase", name = "case_3")
  expect_equal(junit_test_names(x), c("case_1", "case_2", "case_3"))
})

test_that("junit_add_tests appropriately embeds testing info in JUnit format", {
  x <- junit_create()
  statuses <- rep(
    c("success", "failure", "skipped", "error", "unknown"),
    times = rev(1:5)
  )
  label <- c(failure = "failures", skipped = "skipped", error = "errors")

  # check creation
  expect_silent(x <- junit_add_tests(
    x,
    "testing suite",
    paste("case", seq_along(statuses), sep = "_"),
    statuses = statuses,
    time = seq_along(statuses)
  ))

  # check content structure
  expect_equal(
    xml2::xml_attr(xml2::xml_find_first(x, "/testsuites/testsuite"), "tests"),
    as.character(length(statuses))
  )

  # check for appropriate test counts summary
  for (i in setdiff(unique(statuses), c("success", "unknown"))) {
    expect_equal(
      xml2::xml_attr(
        xml2::xml_find_first(x, "/testsuites/testsuite"),
        label[[i]]
      ),
      as.character(sum(statuses == i))
    )
  }

  # check for execution time getting appropriately embeded (although this will
  # not be collected during non-testthat execution anyways)
  expect_equal(
    xml2::xml_attr(xml2::xml_find_first(x, "/testsuites/testsuite"), "time"),
    as.character(sum(seq_along(statuses)))
  )

  expect_equal(
    xml2::xml_attr(xml2::xml_find_first(x, "/testsuites/testsuite"), "time"),
    as.character(sum(seq_along(statuses)))
  )

  expect_equal(
    xml2::xml_attr(
      xml2::xml_find_first(x, "/testsuites/testsuite/*[1]"),
      "classname"
    ),
    "testing suite"
  )

  # check that failures get extra failure "type" info used by some integrations
  expect_equal(
    xml2::xml_attr(
      xml2::xml_find_first(x, "/testsuites/testsuite/*/failure"),
      "type"
    ),
    "failure"
  )

  expect_equal(
    xml2::xml_name(xml2::xml_find_first(x, "/testsuites/testsuite/*/unknown")),
    "unknown"
  )
})

# nolint start
broken_junit <- c(
  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "<testsuites>",
  "  <testsuite name=\"test\" timestamp=\"2023-09-12T11:45:22Z\" hostname=\"testthat\" tests=\"1\" skipped=\"1\" failures=\"0\" errors=\"0\" time=\"0.245000000000005\">",
  "    <testcase time=\"0.245000000000005\" classname=\"message\" name=\"format_ansi_\">",
  "<skipped message=\"Reason: On CRAN (\033[34mtest-cnd-message.R:201:3\033[39m)\"/>",
  "</testcase>",
  "  </testsuite>",
  "</testsuites>"
)
# nolint end

test_that("junit_read_and_repair repairs invalid xmls", {
  broken_junit_path <- paste0(tempfile(), ".xml")
  broken_junit_old_path <- paste0(
    tools::file_path_sans_ext(broken_junit_path),
    "_original.",
    tools::file_ext(broken_junit_path)
  )
  writeLines(broken_junit, broken_junit_path)

  expect_message(
    res <- junit_read_and_repair(broken_junit_path),
    "JUnit file was invalid and required patching",
  )
  expect_s3_class(res, "xml_document")
  # Check that file was overwritten with a proper one
  expect_silent(junit_read_and_repair(broken_junit_path))
  expect_true(file.exists(broken_junit_old_path))
  expect_error(xml2::read_xml(broken_junit_old_path), "invalid character")

  really_broken_junit_path <- paste0(tempfile(), "_really_broken.xml")
  writeLines(broken_junit[-7], really_broken_junit_path)
  expect_warning(
    res2 <- junit_read_and_repair(really_broken_junit_path),
    "JUnit file is invalid and it could not be repaired"
  )

  expect_identical(res2, junit_create())
})

# nolint start
junit_missing <- c(
  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
  "<testsuites>",
  "  <testsuite name=\"get_rd\" timestamp=\"2024-12-09T12:36:50Z\" hostname=\"maksymis-KDML7L\" tests=\"4\" skipped=\"1\" failures=\"0\" errors=\"0\" time=\"0.116\">",
  "    <testcase time=\"0.0159999999999998\" classname=\"get_rd\" name=\"Can_find_relevant_R_documentation_files_given_a_topic_and_package_name\"/>",
  "    <testcase time=\"0.0430000000000001\" classname=\"get_rd\" name=\"Can_find_relevant_R_documentation_files_given_a_topic_and_package_name\">",
  "      <skipped message=\"Reason: Some reason ('test-get_rd.R:3:3')\"/>",
  "    </testcase>",
  "    <testcase time=\"0.038\" classname=\"get_rd\" name=\"While_searching_for_relevant_R_documentation_Errors_return_silently\"/>",
  "    <testcase time=\"0.0189999999999999\" classname=\"get_rd\" name=\"Can_find_relevant_R_documentation_files_given_a_.Rd_filepath\"/>",
  "  </testsuite>",
  "  <testsuite name=\"additional covr traces\" timestamp=\"\" hostname=\"\" tests=\"1\" skipped=\"0\" failures=\"0\" errors=\"0\" time=\"0\">",
  "    <testcase time=\"0\" classname=\"additional covr traces\" name=\"documentation_to_markdown_rd_filepaths_\"/>",
  "  </testsuite>",
  "</testsuites>"
)
# nolint end

test_that("junit_remove_skipped_nodes removes skipped nodes", {
  junit_with_skips_path <- paste0(tempfile(), ".xml")
  writeLines(junit_missing, junit_with_skips_path)

  expect_message(
    res <- junit_read_and_repair(junit_with_skips_path),
    NA
  )
  expect_s3_class(res, "xml_document")
  expect_length(xml2::xml_find_all(res, ".//skipped"), 1)
  expect_equal(xml2::xml_attr(xml2::xml_children(res)[1], "skipped"), "1")
  expect_equal(xml2::xml_attr(xml2::xml_children(res)[1], "tests"), "4")

  res <- junit_remove_skipped_nodes(res)
  expect_s3_class(res, "xml_document")
  expect_length(xml2::xml_find_all(res, ".//skipped"), 0)
  expect_equal(xml2::xml_attr(xml2::xml_children(res)[1], "skipped"), "0")
  expect_equal(xml2::xml_attr(xml2::xml_children(res)[1], "tests"), "3")
})
