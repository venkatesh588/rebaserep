test_that(
  "autovalidate runs and reports validation steps and restores libPath",
  {
    # don't install, just return original path as package
    libs_in <- .libPaths()
    mockery::stub(
      autovalidate.package,
      "avu_install",
      function(x, ...) as.package(x)
    )

    suppressMessages(expect_message(
      autovalidate.package(
        as.package(good),
        steps = list(example_step = function(x, ...) "\"test\"")
      ),
      "example_step"
    ))
    expect_equal(libs_in, .libPaths())
  }
)

test_that("autovalidate runs and clears the artifacts if clean is true", {
  mockery::stub(
    autovalidate.package,
    "avu_install",
    function(x, ...) as.package(x)
  )
  autovalidate(
    as.package(good),
    steps = avu_steps()[3],
    clean = TRUE
  )

  expect_true(all(!startsWith(
    basename(list.dirs(tempdir(), recursive = FALSE)), "autovalidateutils_"
  )))
})

test_that(
  "autovalidate run against a character value
  triggers file-based class dispatch",
  {
    # return upon recursion
    mockery::stub(autovalidate.character, "autovalidate", function(x, ...) x)

    # fake available.packages so we don't need to choose a CRAN mirror during
    # testing and can lock an expected version
    mockery::stub(autovalidate.character, "available.packages", function(...) {
      mat <- cbind(
        Repository = rep_len("https://fakecran.org/src/contrib", 2L),
        Package = c("survival", "utils"),
        Version = c("1.2.3", "4.5.6")
      )
      rownames(mat) <- mat[, "Package"]
      mat
    })

    expect_silent(
      pkg <- autovalidate.character("https://fakeurl.com/package.tar.gz")
    )
    expect_s3_class(pkg, c("https", "tar.gz", "gz", "character"))

    expect_silent(
      pkg <- autovalidate.character("https://fakeurl.com/package.git")
    )
    expect_s3_class(pkg, c("https", "git", "character"))

    expect_silent(
      pkg <- autovalidate.character("https://fakeurl.com/package.git@ref")
    )
    expect_s3_class(pkg, c("https", "git", "character"))
  }
)

test_that(
  "autovalidate run against a character value with
  no file extensions searches available packages",
  {
    # return upon recursion
    mockery::stub(autovalidate.character, "autovalidate", function(x, ...) x)

    # fake available.packages so we don't need to choose a CRAN mirror during
    # testing and can lock an expected version
    mockery::stub(autovalidate.character, "available.packages", function(...) {
      mat <- cbind(
        Repository = rep_len("https://fakecran.org/src/contrib", 2L),
        Package = c("survival", "utils"),
        Version = c("1.2.3", "4.5.6")
      )
      rownames(mat) <- mat[, "Package"]
      mat
    })

    expect_silent(pkg <- autovalidate.character("survival"))
    expect_true(grepl("survival_1\\.2\\.3\\.tar\\.gz$", pkg))

    expect_error(autovalidate.character("not-a-real-package"))
  }
)

test_that(
  "autovalidate run against a source code directory produces a package",
  {
    # return upon recursion
    mockery::stub(
      autovalidate.character,
      "autovalidate",
      function(x, ..., metadata = list()) {
        x$metadata <- metadata
        x
      }
    )

    expect_silent(pkg <- autovalidate.character(good))
    expect_true(!is.null(pkg$metadata$src_url))
    expect_s3_class(pkg, "package")
    expect_true(normalize_path(pkg$path) == normalize_path(good))
  }
)

test_that("autovalidate run against an http(s) url downloads contents", {
  # return upon recursion -- just give us back the pkg object with metadata
  mockery::stub(
    autovalidate.http, "autovalidate",
    function(x, ..., metadata = list()) list(destfile = x, metadata = metadata)
  )

  # don't actually download anything
  mockery::stub(autovalidate.http, "download.file", NULL)

  url <- "https://fake.cran.com/org/package.tar.gz"
  expect_silent(out <- autovalidate.http(url))
  expect_true(basename(out$destfile) == "package.tar.gz")
  expect_true("src_url" %in% names(out$metadata))
  expect_true(out$metadata$src_url == url)
})

test_that(
  "autovalidate run against an http(s) git remote
  returns result of git method",
  {
    # return upon recursion
    # just give us back a signal that http returns early
    mockery::stub(autovalidate.http, "NextMethod", "next_method")
    url <- "https://fake.cran.com/org/package.git"
    x <- structure(url, class = c("http", "git"))
    expect_silent(out <- autovalidate.http(x))
    expect_equal(out, "next_method")
  }
)

test_that("autovalidate run against a git url produces source code directory", {
  # return upon recursion -- just give us back the pkg object with metadata
  mockery::stub(
    autovalidate.git,
    "autovalidate",
    function(x, ..., metadata = list()) {
      list(destdir = x, metadata = metadata)
    }
  )

  # don't actually clone, just initialize a new local repo
  mockery::stub(
    autovalidate.git,
    "git2r::clone",
    function(x, ..., local_path) {
      # create a new repo at "clone" destination
      git2r::init(local_path, branch = "main")
      dir.create(file.path(local_path, "subdirPkg"))
      git2r::config(git2r::repository(local_path),
        user.name = "autovalidateutils ci",
        user.email = "autovalidateutils@ci.com"
      )
      git2r::remote_add(
        local_path,
        "origin",
        "https://fake.git.com/org/package.git"
      )
      file.create(readme <- file.path(local_path, "README"))

      # tag a commit as a version
      git2r::add(local_path, readme)
      git2r::commit(local_path, message = "v0.0.1 release")
      git2r::tag(local_path, name = "v0.0.1")

      git2r::checkout(local_path, branch = "dev", create = TRUE)

      # tag a commit as a release candidate
      Sys.sleep(1.1) # delay needed so commit timestamps are differentiable
      write("prep rc", readme, append = TRUE)
      git2r::add(local_path, readme)
      git2r::commit(local_path, message = "v0.0.2rc")
      git2r::tag(local_path, name = "v0.0.2rc")

      # latest tagged commit
      Sys.sleep(1.1) # delay needed so commit timestamps are differentiable
      write("edit", readme, append = TRUE)
      git2r::add(local_path, readme)
      git2r::commit(local_path, message = "breaking things")
      git2r::tag(local_path, name = "very_broken_commit")

      Sys.sleep(1.1) # delay needed so commit timestamps are differentiable)
      write("edit again", readme, append = TRUE)
      git2r::add(local_path, readme)
      git2r::commit(local_path, message = "another commit")

      git2r::checkout(local_path, branch = "main")
    }
  )

  expect_message(
    out <- autovalidate.git("https://fake.git.com/org/package.git"),
    "Extracted package source"
  )

  expect_true(dir.exists(out$destdir))
  expect_true(length(list.files(out$destdir)) > 0L)
  expect_true("src_url" %in% names(out$metadata))
  expect_true(out$metadata$src_url == "https://fake.git.com/org/package.git")
  expect_true("checksum" %in% names(out$metadata))
  expect_true("hash" %in% names(out$metadata$checksum))
  expect_true(nchar(out$metadata$checksum$hash) > 0L)
  expect_true("protocol" %in% names(out$metadata$checksum))
  expect_true(out$metadata$checksum$protocol == "SHA1")

  # test use of a subdir parameter
  expect_message(
    out <- autovalidate.git(
      "https://fake.git.com/org/package.git",
      subdir = "subdirPkg"
    ),
    "Extracted package source"
  )
  expect_true(dir.exists(out$destdir))
  expect_true(git_summary(out$metadata$repo_path)$branch == "main")
  expect_true(basename(out$destdir) == "subdirPkg")

  # test use of a trailing @ref
  expect_message(
    out <- autovalidate.git("https://fake.git.com/org/package.git@dev"),
    "Extracted package source"
  )
  expect_true(dir.exists(out$destdir))
  expect_true(git_summary(out$metadata$repo_path)$branch == "dev")

  # test use of a trailing @*tag grabs latest tagged commit
  expect_message(
    out <- autovalidate.git("https://fake.git.com/org/package.git@*tag"),
    "Extracted package source"
  )

  expect_true(dir.exists(out$destdir))
  expect_true(is.null(git_summary(out$metadata$repo_path)$branch))
  expect_equal(
    out$metadata$checksum$hash,
    git2r::tags(out$destdir)$`very_broken_commit`$sha
  )

  # test use of trailing @*tag~=v[:version:] grabs latest version release
  expect_message(
    out <- autovalidate.git(
      "https://fake.git.com/org/package.git@*tag=~v[:version:]"
    ),
    "Extracted package source"
  )

  expect_true(dir.exists(out$destdir))
  expect_true(is.null(git_summary(out$metadata$repo_path)$branch))
  expect_equal(
    out$metadata$checksum$hash,
    git2r::tags(out$destdir)$`v0.0.1`$sha
  )

  # test that an error is thrown if no tags match the pattern
  expect_error(
    out <- autovalidate.git(
      "https://fake.git.com/org/package.git@*tag=~no_match"
    ),
    "No matching tags"
  )
})

test_that(
  "autovalidate run against a tarball produces package object,
  warning not to install from local files.",
  {
    # return upon recursion -- just give us back the pkg object with metadata
    mockery::stub(
      autovalidate.tar.gz,
      "autovalidate",
      function(x, ..., metadata = list()) {
        x$metadata <- metadata
        x
      }
    )

    # this isn't a "built" tarball, just the source code
    withr::with_dir(
      dirname(good),
      tar(
        good_tar <- file.path(tempdir(), "good.tar.gz"), files = basename(good)
      )
    )

    expect_true(file.exists(good_tar))
    expect_warning(
      expect_message(
        pkg <- autovalidate.tar.gz(good_tar),
        "Extracted package source"
      ),
      "No remote source url found"
    )
    expect_s3_class(pkg, "package")
    expect_true("targz" %in% names(pkg$metadata))
    expect_true(pkg$metadata$targz == good_tar)
    expect_true("checksum" %in% names(pkg$metadata))
    expect_true("hash" %in% names(pkg$metadata$checksum))
    expect_true(nchar(pkg$metadata$checksum$hash) > 0L)
    expect_true("protocol" %in% names(pkg$metadata$checksum))
    expect_true(pkg$metadata$checksum$protocol == "md5")
  }
)

test_that(
  "opt('steps') can be used to control executed steps as described",
  {
    old_opts <- options()
    on.exit(options(old_opts), add = TRUE)

    expect_equal(avu_steps(modifications = NULL), all_steps())
    expect_equal(
      unname(avu_steps(modifications = "-write_checked")),
      setdiff(all_steps(), "write_checked")
    )

    options(
      autovalidateutils.steps = c(
        "A" = "write_version_control_yml",
        "B" = "write_session_info"
      )
    )
    expect_equal(
      avu_steps(),
      c("A" = "write_version_control_yml", "B" = "write_session_info")
    )

    options(autovalidateutils.steps = paste0("-", all_steps()[-1]))
    expect_equal(avu_steps(), all_steps()[1])

    old_envvar <- Sys.getenv("AUTOVALIDATEUTILS_STEPS")
    Sys.setenv("AUTOVALIDATEUTILS_STEPS" = "TRUE")
    options(autovalidateutils.steps = NULL)
    on.exit(Sys.setenv("AUTOVALIDATEUTILS_STEPS" = old_envvar), add = TRUE)

    expect_equal(avu_steps(), all_steps())
  }
)
