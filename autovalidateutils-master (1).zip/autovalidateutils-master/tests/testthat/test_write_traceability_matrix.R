test_that(paste0(
  "warn_insufficient_coverage produces warning when test",
  "coverage is below threshold"
), {
  expect_silent(warn_insufficient_coverage(good, cov_good))
  expect_warning(warn_insufficient_coverage(okay, cov_okay), "(?i)coverage")
})

test_that("write_traceability_matrix executes successfully on good packages", {
  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)
  expect_silent(suppressMessages(write_traceability_matrix(good)))
})

test_that(
  "write_traceability_matrix executes successfully
  on good packages with covtracer debug",
  {
    withr::with_envvar(c("AUTOVALIDATEUTILS_COVTRACER_DEBUG" = "TRUE"), {
      dir <- options::opt("output")
      unlink_dir(dir)
      dir.create(dir, recursive = TRUE)
      expect_silent(suppressMessages(write_traceability_matrix(good)))
    })
  }
)


test_that(
  "write_traceability_matrix on good packages produces desired output files",
  {
    dir <- options::opt("output")
    expect_true(file.exists(file.path(dir, options::opt("junit"))))
    expect_true(file.exists(file.path(dir, options::opt("test_exec_log"))))
    expect_true(file.exists(file.path(
      dir, options::opt("cov_logs"), "error_locations.log"
    )))
    expect_true(file.exists(file.path(
      dir, options::opt("cov_logs"), "tests_summary.log"
    )))
    expect_true(all(grepl("^0.\\d+", list.files(
      file.path(dir, options::opt("documentation"))
    ))))
    expect_true(file.exists(file.path(dir, options::opt("mapper"))))
  }
)

test_that(
  "write_traceability_matrix on good packages produces
  correctly related mapper & requirements files",
  {
    dir <- options::opt("output")
    expect_silent(
      mapper <- yaml::read_yaml(file.path(dir, options::opt("mapper")))
    )
    mapper_reqs <- unlist(lapply(mapper, `[[`, "requirements"))
    req_files <- list.files(file.path(dir, options::opt("documentation")))
    req_indices <- gsub("^0.(\\d+).*", "\\1", req_files)
    expect_true(length(mapper_reqs) > 0L)
    expect_true(all(mapper_reqs %in% req_indices))
  }
)

test_that(
  "write_traceability_matrix executes successfully on moderate packages",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)
    expect_silent(suppressMessages(write_traceability_matrix(okay)))
  }
)

test_that(
  "write_traceability_matrix on moderate packages
  produces desired output files",
  {
    dir <- options::opt("output")
    expect_true(file.exists(file.path(dir, options::opt("errors"))))
    expect_true(file.exists(file.path(dir, options::opt("junit"))))
    expect_true(file.exists(file.path(dir, options::opt("test_exec_log"))))
    expect_true(all(grepl("^0.\\d+", list.files(
      file.path(dir, options::opt("documentation"))
    ))))
    expect_true(file.exists(file.path(dir, options::opt("mapper"))))
  }
)

test_that(
  "write_traceability_matrix on moderate packages
  produces correctly related mapper & requirements files",
  {
    dir <- options::opt("output")
    expect_silent(
      mapper <- yaml::read_yaml(file.path(dir, options::opt("mapper")))
    )
    mapper_reqs <- unlist(lapply(mapper, `[[`, "requirements"))
    req_files <- list.files(file.path(dir, options::opt("documentation")))
    req_indices <- gsub("^0.(\\d+).*", "\\1", req_files)
    expect_true(length(mapper_reqs) > 0L)
    expect_true(all(mapper_reqs %in% req_indices))
  }
)

test_that("write_traceability_matrix test exec log", {
  dir <- options::opt("output")
  expect_true(length(readLines(file.path(dir, options::opt("errors")))) > 0L)
  expect_true(any(grepl(
    "Running \\\\'tests.R\\\\'",
    readLines(file.path(dir, options::opt("test_exec_log")))
  )))
})

test_that(
  "write_traceability_matrix constructs a junit file when testthat isn't used",
  {
    dir <- options::opt("output")
    expect_silent(
      junit <- xml2::read_xml(file.path(dir, options::opt("junit")))
    )
    # testsuite is constructed for non-testthat tests
    expect_equal(
      xml2::xml_attr(xml2::xml_find_first(junit, "testsuite"), "name"),
      "additional covr traces"
    )
    # name is created from test code
    expect_match(
      xml2::xml_attr(xml2::xml_find_first(junit, "//testcase"), "name"),
      "hypotenuse"
    )
  }
)


test_that("write_traceability_matrix executes successfully on bad packages", {
  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_traceability_matrix(bad)
    }))
    res
  })

  # expect a coverage notification
  expect_true(any(grepl("Coverage .* threshold", msgs)))
})

test_that(
  "write_traceability_matrix on bad packages produces desired output files",
  {
    dir <- options::opt("output")
    expect_true(file.exists(file.path(dir, options::opt("errors"))))
    expect_true(file.exists(file.path(dir, options::opt("junit"))))
    expect_true(file.exists(file.path(dir, options::opt("test_exec_log"))))
    expect_true(all(grepl("^0.\\d+", list.files(
      file.path(dir, options::opt("documentation"))
    ))))
    expect_true(file.exists(file.path(dir, options::opt("mapper"))))
  }
)

test_that(
  "write_traceability_matrix constructs a junit file when there's no testing",
  {
    dir <- options::opt("output")
    expect_silent(
      junit <- xml2::read_xml(file.path(dir, options::opt("junit")))
    )
    # testsuite is constructed for non-testthat tests
    expect_equal(
      xml2::xml_attr(xml2::xml_find_first(junit, "testsuite"), "name"),
      "additional covr traces"
    )
    # no test cases created if there's no testing suite
    expect_true(is.na(xml2::xml_find_first(junit, "//testcase")))
  }
)

test_that("reexports can be filtered from Rd docs used for requirements", {
  pkg_path <- attr(cov_good, "package")$path

  expect_silent({
    rd_df <- build_documentation_index(pkg_path)
    tt_df <- build_traceability_matrix(cov_good)
  })

  expect_true("reexport_help" %in% rd_df$alias)
  expect_true(!"reexport_help" %in% filter_reexports(rd_df, tt_df)$alias)
})

test_that(
  "Untested functions are included in traceability matrix and documentation",
  {
    pkg_path <- attr(cov_bad, "package")$path

    expect_silent({
      rd_df <- build_documentation_index(pkg_path)
      tt_df <- build_traceability_matrix(cov_bad)
    })

    expect_true("undocumented_args.Rd" %in% rd_df$file)
    expect_true("undocumented_args" %in% tt_df$alias)
    expect_true("undocumented_args" %in% filter_reexports(rd_df, tt_df)$alias)
  }
)

test_that(
  "write_traceability_matrix propeorly times out
  after options::opt('timeout') passes",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    expect_false({
      out <- capture.output(msgs <- capture.output(type = "message", {
        withr::with_options(new = list(autovalidateutils.timeout = 1), {
          res <- write_traceability_matrix(good)
        })
      }))
      res
    })

    # expect a coverage notification
    expect_true(any(grepl("callr timed out", msgs)))
  }
)

test_that(
  "write_traceability_matrix marks tests status as UNKNOWN if testthat is not
  used and R CMD check identified tests issues",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    expect_error(withr::with_envvar(c(
      "AUTOVALIDATEUTILS_R_CHECK_TESTS_FAILURE" = "TRUE"
    ), {
      suppressMessages(write_traceability_matrix(unknown))
    }), NA)

    expect_silent(
      junit <- xml2::read_xml(file.path(dir, options::opt("junit")))
    )
    test_list <- xml2::as_list(xml2::xml_find_first(junit, "testsuite"))
    test_statuses <- vapply(test_list, function(x) {
      names(x) %||% ""
    }, FUN.VALUE = character(1))

    expect_true("unknown" %in% test_statuses)
  }
)

test_that(
  "write_traceability_matrix marks tests status as UNKNOWN if testthat is not
  used and R CMD check results are not available",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    # Simulate the variable is not set
    expect_error(withr::with_envvar(c(
      "AUTOVALIDATEUTILS_R_CHECK_TESTS_FAILURE" = ""
    ), {
      suppressMessages(write_traceability_matrix(unknown))
    }), NA)

    expect_silent(
      junit <- xml2::read_xml(file.path(dir, options::opt("junit")))
    )
    test_list <- xml2::as_list(xml2::xml_find_first(junit, "testsuite"))
    test_statuses <- vapply(test_list, function(x) {
      names(x) %||% ""
    }, FUN.VALUE = character(1))

    expect_true("unknown" %in% test_statuses)
  }
)

test_that(
  "write_traceability_matrix produces valid junit file if R CMD check identified
  tests issues but testthat is used",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    expect_error(withr::with_envvar(c(
      "AUTOVALIDATEUTILS_R_CHECK_TESTS_FAILURE" = "TRUE"
    ), {
      suppressMessages(write_traceability_matrix(moderate))
    }), NA)

    expect_silent(
      junit <- xml2::read_xml(file.path(dir, options::opt("junit")))
    )
    test_list <- xml2::as_list(xml2::xml_find_first(junit, "testsuite"))
    test_statuses <- vapply(test_list, function(x) {
      names(x) %||% ""
    }, FUN.VALUE = character(1))
    expect_true("failure" %in% test_statuses)
    expect_true("" %in% test_statuses)
    expect_true("error" %in% test_statuses)
    expect_true(!"unknown" %in% test_statuses)
  }
)

test_that(
  "write_traceability_matrix produces valid junit and removes skipped testcases
  crosschecking them against traceability matrix",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)
    skipped_test_name <- "hypotenuse_is_calculated_correctly_but_skipped"
    expect_silent(suppressMessages(write_traceability_matrix(good3)))
    expect_silent(
      junit <- xml2::read_xml(file.path(dir, options::opt("junit")))
    )
    expect_silent(
      mapper <- yaml::read_yaml(file.path(dir, options::opt("mapper")))
    )

    expect_true(!skipped_test_name %in% junit_test_names(junit))
    expect_true(!skipped_test_name %in%
                  vapply(mapper, "[[", FUN.VALUE = character(1), "test"))
  }
)

test_that(
  "write_traceability_matrix properly identifies packages
  with no testable code",
  {
    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    withr::with_options(new = list(autovalidateutils.timeout = 1), {
      expect_message(write_traceability_matrix(no_code),
                     "No testable code found")
    })
  }
)

test_that(
  paste(
    "write_traceability_matrix mapper author, reviewer",
    "and review_date can be configured with or without default based on ",
    "option 'mapper_defaults'."
  ), {
    # pre-calculate to avoid repeatedly being derived
    trace_matrix_good <- build_traceability_matrix(cov_good)
    rd_df_good <- build_documentation_index(good)

    # mock a few long-running calculations
    local_mocked_bindings(
      safe_package_coverage = function(...) cov_good,
      build_traceability_matrix = function(...) trace_matrix_good,
      build_documentation_index = function(...) rd_df_good
    )

    # and trick function into skipping documation generation
    local_mocked_bindings(
      r_vanilla = function(...) TRUE,
      .package = "callr"
    )

    dir <- options::opt("output")
    mapper_file <- file.path(dir, "traceability_matrix", "mapper.yml")

    # case with mapper defaults
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)
    expect_silent(suppressMessages(write_traceability_matrix(good)))
    expect_silent(good_mapper <- yaml::read_yaml(mapper_file))
    expect_true(all(vapply(
      good_mapper,
      function(elem) !is.null(elem$author),
      logical(1L)
    )))

    # case with mapper defaults TRUE
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)
    expect_silent(suppressMessages(withr::with_options(
      list(autovalidateutils.mapper_defaults = TRUE),
      write_traceability_matrix(good)
    )))

    expect_silent(good_mapper <- yaml::read_yaml(mapper_file))
    expect_true(all(vapply(
      good_mapper,
      function(elem) !is.null(elem$author),
      logical(1L)
    )))

    # case with mapper defaults FALSE
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)
    expect_silent(suppressMessages(withr::with_options(
      list(autovalidateutils.mapper_defaults = FALSE),
      write_traceability_matrix(good)
    )))

    expect_silent(good_mapper <- yaml::read_yaml(mapper_file))
    expect_true(all(vapply(
      good_mapper,
      function(elem) {
        !any(c(
          "author", "reviewer", "review_date", "description"
        ) %in% names(elem))
      },
      logical(1L)
    )))
  }
)
