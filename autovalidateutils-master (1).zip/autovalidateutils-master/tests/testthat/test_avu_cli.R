unlink(options::opt("log_output"))

test_that(
  "avu_cli_h3 includes spaces in blank lines to preserve them during CI runs",
  {
    msgs <- capture.output(type = "message", invisible(avu_cli_h3("test")))
    expect_true(grepl("^    $", msgs[[1L]]))
    expect_true(grepl("test", msgs[[2L]]))
  }
)

test_that("avu_cli_task emit necessary command line interface output", {
  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      avu_cli_task("test task", {
      })

      avu_cli_task("test task - success", {
        success("success")
      })

      avu_cli_task("test task - info", {
        info("info")
      })

      avu_cli_task("test task - message", {
        message("message")
      })

      avu_cli_task("test task - warning", {
        warning("warning")
      })

      avu_cli_task("test task - message + warning", {
        message("message")
        warning("warning")
      })

      cat("regular output")
    }))
    TRUE
  })

  expect_true({
    alert <- capture.output(
      type = "message",
      cli::cli_alert_success("test task")
    )
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(
      type = "message",
      cli::cli_alert_success("test task - success")
    )
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(
      type = "message",
      cli::cli_alert_info("test task - info")
    )
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    any(grepl("regular output", out, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(
      type = "message",
      cli::cli_alert_warning("test task - message")
    )
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(type = "message", cli::cli_alert_warning("message"))
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(type = "message", cli::cli_alert_success("success"))
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(type = "message", cli::cli_alert_info("info"))
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(
      type = "message",
      cli::cli_alert_danger("test task - warning")
    )
    any(grepl(alert, msgs, fixed = TRUE))
  })

  expect_true({
    alert <- capture.output(
      type = "message",
      cli::cli_alert_danger("test task - message + warning")
    )
    any(grepl(alert, msgs, fixed = TRUE))
  })
})

test_that("avu_cli_task respects warning and error emitting parameters", {
  expect_warning(suppressMessages(avu_cli_task(
    "test task",
    message("test"),
    warning_on = "message"
  )))

  expect_silent(suppressMessages(avu_cli_task(
    "test task",
    message("test"),
    warning_on = "warning"
  )))

  expect_error({
    avu_cli_task("test task", message("test"), error_on = "message")
  })

  expect_error(suppressMessages(classes = "message", avu_cli_task(
    "test task",
    warning("test"),
    error_on = "warning"
  )))

  expect_silent(suppressMessages(classes = "message", avu_cli_task(
    "test task",
    warning("test"),
    error_on = "message"
  )))

  expect_output(suppressMessages(classes = "message", avu_cli_task(
    "test task",
    stop("test"),
    error_on = c(),
    callbacks = list(error = function(e) print("callback"))
  )), "callback")

  expect_silent(suppressMessages(classes = "message", avu_cli_task(
    "test task",
    warning("test"),
    error_on = "message"
  )))

  suppressMessages(
    classes = "message",
    expect_message(
      avu_cli_task("test task", signalCondition(
        simpleCondition("custom message condition class")
      )),
      "custom message condition class"
    )
  )
})

test_that("avu_cli_task callbacks get emitted upon message", {
  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", avu_cli_task(
      "test task",
      message("test"),
      callbacks = c(message = function(m) print("Aloha!"))
    )))
    any(grepl("Aloha!", out))
  })

  expect_true({
    out <- capture.output(type = "message", avu_cli_task(
      "test task",
      message("test"),
      callbacks = c(warning = function(m) print("Aloha!"))
    ))
    !any(grepl("Aloha!", out))
  })
})

test_that("avu_cli_task always emits to stdout for typical output", {
  expect_output(avu_cli_task("test task", cat("test"), quiet = TRUE))
  expect_output(suppressMessages(classes = "message", {
    avu_cli_task("test task", cat("test"), quiet = FALSE)
  }))
})

test_that("avu_cli_task doesn't emit to stdout when quiet = TRUE", {
  expect_silent(avu_cli_task("test task", info("test"), quiet = TRUE))
  expect_silent(avu_cli_task("test task", message("test"), quiet = TRUE))
  expect_warning(avu_cli_task("test task", warning("test"), quiet = TRUE))
  expect_error(avu_cli_task("test task", stop("test"), quiet = TRUE))
})

test_that("get_skip_messages works as expected", {
  expect_equal(
    get_skip_messages(c("Skip1" = TRUE, "Skip2" = TRUE, FALSE, TRUE)),
    c("Skip1", "Skip2")
  )
  expect_equal(
    get_skip_messages(c(TRUE, TRUE, FALSE, TRUE)),
    c("Skipped!")
  )
  expect_equal(
    get_skip_messages(c("Skip1" = FALSE, "Skip2" = FALSE, FALSE, TRUE)),
    c("Skipped!")
  )
})
