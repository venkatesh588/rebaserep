create_temp_repo <- function(dir, repo_path) {
  dir.create(
    ctburl <- utils::contrib.url(repo_path, type = "source"), recursive = TRUE
  )
  sources <- normalizePath(
    list.dirs(dir, full.names = TRUE, recursive = FALSE)
  )
  lapply(sources, add_package_to_repo, repo_path = ctburl)
  tools::write_PACKAGES(ctburl, type = "source")
}

add_package_to_repo <- function(pkg, repo_path) {
  callr::rcmd("build", pkg, wd = repo_path)
}
