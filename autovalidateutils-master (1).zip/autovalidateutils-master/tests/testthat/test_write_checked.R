output <- options::opt("output")
results <- file.path(output, "revdep", "results.txt")
source_dir_old <- file.path(test_path(), "data", "test_revdep", "v1")
source_dir_new <- file.path(test_path(), "data", "test_revdep", "v2")

temp_dir <- tempdir()
repo_dir <- file.path(temp_dir, "repo")
repo <- paste0("file://", repo_dir)

withr::defer(
  unlink_dir(temp_dir),
  envir = testthat::teardown_env()
)

test_that("Testing repo instantiates successfully", {
  expect_true(create_temp_repo(
    source_dir_old,
    repo_dir
  ) > 0)
})

test_that(
  paste0(
    "autovalidate with other steps produces the same output file as calling ",
    "the write_checked function directly and outputs correct message"
  ),
  {
    withr::with_options(new = list(
      repos = repo,
      autovalidateutils.quiet = TRUE,
      autovalidateutils.steps = "-write_revdep_check"
    ), {
      suppressWarnings({
        autovalidate(
          x = file.path(source_dir_new, "pkg.ok.error"),
          output = output,
          steps = avu_steps(),
          lib.loc = .libPaths(),
          quiet = TRUE
        )
      })
    })

    expect_true(file.exists(results))
    expect_silent(lines <- readLines(results, warn = FALSE))

    # expect at least one problem reported
    expect_true(any(grepl("# Revdep Check Task Spec", lines)))

    # expect newly broken package for package `rev.both.error`
    expect_true(any(grepl("rev.both.error package R CMD check diff", lines)))

    # expect a newly broken warning issue in the results summary
    expect_true(any(grepl("warnings: NEW ISSUES \\[1\\]", lines)))

    # expect a newly broken error issue in the results summary
    expect_true(any(grepl("errors: NEW ISSUES \\[1\\]", lines)))

    # expect Missing or unexported object warning
    expect_true(any(grepl("Missing or unexported object:", lines)))

    # expect proper files are deleted according to default revdep_clean_sources
    # and revdep_clean_sources options
    sources <- file.path(output, "revdep", "checks")
    library <- file.path(output, "revdep", "lib")

    revdep_sources <- list.files(
      sources,
      full.names = TRUE,
      recursive = TRUE,
      pattern = ".*\\.tar\\.gz$"
    )

    expect_length(revdep_sources, 0)
    expect_false(dir.exists(library))
  }
)

test_that(paste0(
  "write_checked output file shows no results with a package that has ",
  "no reverse dependencies and outputs the correct message"
), {
  withr::with_options(new = list(repos = repo), {
    expect_message(
      write_checked(
        x = file.path(source_dir_new, "pkg.none"),
        output = output
      ),
      "Writing revdepcheck report"
    )
  })

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect no revdeps issues header
  expect_false(any(grepl("# Revdep Check Task Spec", lines)))

  # expect no newly broken notes issues in the results summary
  expect_false(any(grepl("notes: NEW ISSUES", lines)))

  # expect no newly broken warning issues in the results summary
  expect_false(any(grepl("warnings: NEW ISSUES", lines)))

  # expect no newly broken errors issues in the results summary
  expect_false(any(grepl("errors: NEW ISSUES", lines)))

  # expect explicit "No issues identified." message
  expect_true(any(grepl("No issues identified\\.", lines, ignore.case = TRUE)))
})

test_that(paste0(
  "write_checked for package without release version in repos"
), {
  withr::with_options(new = list(
    repos = repo,
    autovalidateutils.build_binaries = TRUE,
    autovalidateutils.steps = "-write_revdep_check",
    pkgType = "source"
  ), {
    suppressWarnings(
      autovalidate(
        x = file.path(source_dir_new, "pkg.suggests"),
        output = output,
        steps = avu_steps(),
        lib.loc = .libPaths(),
        quiet = FALSE,
        clean = FALSE
      )
    )
  })

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect at least one problem reported
  expect_true(any(grepl("# Revdep Check Task Spec", lines)))

  # We are getting random covr errors here which are not reproducible
  # locally. Hence we print it here to debug whenver the issue reoccurs
  if (!any(grepl("# Revdep Check Task Spec ", lines))) {
    stop(lines)
  }

  # expect newly broken package for package `rev.both.error`
  expect_true(any(grepl("pkg.none package R CMD check diff", lines)))

  # expect a newly broken error issue in the results summary
  expect_true(any(grepl("errors: NEW ISSUES \\[1\\]", lines)))

  # expect Missing or unexported object warning
  expect_true(any(grepl("Error: hello_world", lines)))
})

test_that(paste0(
  "write_checked output file shows no results with a package that has ",
  "one reverse dependency and no breaking changes"
), {
  withr::with_options(
    new = list(repos = c(local = repo), autovalidateutils.quiet = TRUE),
    {
      write_checked(
        x = file.path(source_dir_new, "pkg.ok"),
        output = output,
        quiet = TRUE
      )
    }
  )

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect no revdeps issues header
  expect_false(any(grepl("# Revdep Check Task Spec", lines)))

  # expect no newly broken notes issues in the results summary
  expect_false(any(grepl("notes: NEW ISSUES", lines)))

  # expect no newly broken warning issues in the results summary
  expect_false(any(grepl("warnings: NEW ISSUES", lines)))

  # expect no newly broken errors issues in the results summary
  expect_false(any(grepl("errors: NEW ISSUES", lines)))

  # expect explicit "No issues identified." message
  expect_true(any(grepl("No issues identified\\.", lines, ignore.case = TRUE)))
})

test_that(paste0(
  "write_checked output file shows one new problem with a package that ",
  "has one reverse dependency and has a breaking change"
), {
  withr::with_options(
    new = list(repos = c(local = repo), autovalidateutils.quiet = TRUE),
    {
      expect_warning(write_checked(
        x = file.path(source_dir_new, "pkg.error"),
        output = output,
        quiet = TRUE
      ))
    }
  )

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect at least one problem reported
  expect_true(any(grepl("# Revdep Check Task Spec", lines)))

  # expect newly broken package for package `rev.both.error`
  expect_true(any(grepl("rev.error package R CMD check diff", lines)))

  # expect a newly broken error issue in the results summary
  expect_true(any(grepl("errors: NEW ISSUES \\[1\\]", lines)))

  # expect Missing or unexported object warning
  expect_true(any(grepl("Error: hello_world_wrapper", lines)))
})

test_that(paste0(
  "write_checked output file shows one new problem with a package that ",
  "has two reverse dependencies, one of which has a breaking change"
), {
  withr::with_options(
    new = list(repos = c(local = repo), autovalidateutils.quiet = TRUE),
    {
      expect_warning(write_checked(
        x = file.path(source_dir_new, "pkg.ok.error"),
        output = output,
        quiet = TRUE
      ))
    }
  )

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect at least one problem reported
  expect_true(any(grepl("# Revdep Check Task Spec", lines)))

  # expect newly broken package for package `rev.both.error`
  expect_true(any(grepl("rev.both.error package R CMD check diff", lines)))

  # expect a newly broken warning issue in the results summary
  expect_true(any(grepl("warnings: NEW ISSUES \\[1\\]", lines)))

  # expect a newly broken error issue in the results summary
  expect_true(any(grepl("errors: NEW ISSUES \\[1\\]", lines)))

  # expect Missing or unexported object warning
  expect_true(any(grepl("Missing or unexported object:", lines)))
})

test_that(paste0(
  "autovalidate with the 'write_checked' step alone produces same result ",
  "as calling the write_checked function directly"
), {
  withr::with_options(new = list(
    repos = c(local = repo),
    autovalidateutils.quiet = TRUE,
    autovalidateutils.steps = "-write_revdep_check"
  ), {
    suppressWarnings({
      autovalidate(
        x = file.path(source_dir_new, "pkg.ok"),
        output = output,
        steps = list("Writing reverse dependency check" = "write_checked"),
        quiet = TRUE
      )
    })
  })

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect no revdeps issues header
  expect_false(any(grepl("# Revdep Check Task Spec", lines)))

  # expect no newly broken notes issues in the results summary
  expect_false(any(grepl("notes: NEW ISSUES", lines)))

  # expect no newly broken warning issues in the results summary
  expect_false(any(grepl("warnings: NEW ISSUES", lines)))

  # expect no newly broken errors issues in the results summary
  expect_false(any(grepl("errors: NEW ISSUES", lines)))

  # expect explicit "No issues identified." message
  expect_true(any(grepl("No issues identified\\.", lines, ignore.case = TRUE)))
})

test_that(paste0(
  "write_checked output file shows no results with a package that",
  "is not available in the repos"
), {
  withr::with_options(new = list(repos = repo), {
    write_checked(
      x = file.path(source_dir_new, "pkg.ok.2"),
      output = output
    )
  })

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect no revdeps issues header
  expect_false(any(grepl("# Revdep Check Task Spec", lines)))

  # expect no newly broken notes issues in the results summary
  expect_false(any(grepl("notes: NEW ISSUES", lines)))

  # expect no newly broken warning issues in the results summary
  expect_false(any(grepl("warnings: NEW ISSUES", lines)))

  # expect no newly broken errors issues in the results summary
  expect_false(any(grepl("errors: NEW ISSUES", lines)))

  # expect explicit "No issues identified." message
  expect_true(any(grepl("No issues identified\\.", lines, ignore.case = TRUE)))
})

test_that("checked properly times out after options::opt('timeout') passes", {
  withr::with_options(
    new = list(
      autovalidateutils.timeout = as.difftime(2, units = "secs"),
      repos = repo
    ), {
      write_checked(
        x = file.path(source_dir_new, "pkg.ok.error"),
        output = output
      )
    }
  )

  expect_true(file.exists(results))
  expect_silent(lines <- readLines(results, warn = FALSE))

  # expect no revdeps issues header
  expect_false(any(grepl("# Revdep Check Task Spec", lines)))

  # expect no newly broken notes issues in the results summary
  expect_false(any(grepl("notes: NEW ISSUES", lines)))

  # expect no newly broken warning issues in the results summary
  expect_false(any(grepl("warnings: NEW ISSUES", lines)))

  # expect no newly broken errors issues in the results summary
  expect_false(any(grepl("errors: NEW ISSUES", lines)))

  # expect explicit "No issues identified." message
  expect_true(any(
    grepl("Reverse dependency check timed out\\.", lines, ignore.case = TRUE)
  ))
})

test_that("checked stops due to repository sanity check", {
  withr::with_options(new = list(
    repos = c(local = repo),
    autovalidateutils.quiet = TRUE
  ), {
    expect_error(
      write_checked(
        x = file.path(source_dir_new, "pkg.missing.revdep"),
        output = output,
        quiet = TRUE
      ),
      "is missing core dependencies in the repository"
    )
  })

})
