dir.create(example_package_lib <- tempfile("testthat_lib_"))
# Clean TRUE makes tests problematic, important libs are getting removed
options(
  "autovalidateutils.clean" = FALSE,
  repos = "https://cran.r-project.org/"
)
.libPaths(c(example_package_lib, old_libs <- .libPaths()))

withr::local_envvar(R_USER_CACHE_DIR = tempfile(),
  .local_envir = teardown_env()
)

# clean up temporary lib paths
withr::defer(envir = teardown_env(), {
  .libPaths(old_libs)
})

# return installed.packages as available.packages to avoid pulling cran db
mocked_check <- mockery::stub(
  check_dependencies_satisfiability,
  "available.packages",
  installed.packages()
)
mockery::stub(avu_install, "check_dependencies_satisfiability", mocked_check)

cli::cli_alert_info(
  "Setting up {.pkg autovalidateutils}: Installing Example Packages"
)

good <- file.path(testthat::test_path(), "data", "test_packages", "exampleGood")
avu_install(
  good,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_good <- safe_package_coverage(as.package(good))

good2 <- file.path(
  testthat::test_path(),
  "data", "test_packages",
  "exampleGood2"
)

avu_install(
  good2,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_good2 <- safe_package_coverage(as.package(good2))

good3 <- file.path(
  testthat::test_path(),
  "data", "test_packages",
  "exampleGood3"
)

avu_install(
  good3,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_good3 <- safe_package_coverage(as.package(good3))

no_code <- file.path(
  testthat::test_path(),
  "data",
  "test_packages",
  "exampleNoCode"
)

avu_install(
  no_code,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)

okay <- file.path(testthat::test_path(), "data", "test_packages", "exampleOkay")
avu_install(
  okay,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_okay <- safe_package_coverage(as.package(okay))

bad <- file.path(testthat::test_path(), "data", "test_packages", "exampleBad")
avu_install(
  bad,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_bad <- safe_package_coverage(as.package(bad))

moderate <- file.path(
  testthat::test_path(),
  "data",
  "test_packages",
  "exampleModerate"
)

avu_install(
  moderate,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_moderate <- safe_package_coverage(as.package(moderate))

unknown <- file.path(
  testthat::test_path(),
  "data",
  "test_packages",
  "exampleUnknown"
)

avu_install(
  unknown,
  lib.loc = .libPaths(),
  libs = .libPaths(),
  upgrade = FALSE,
  dependencies = FALSE,
  quiet = TRUE
)
cov_unknown <- safe_package_coverage(as.package(unknown))

example_pkg_deps <- file.path(
  testthat::test_path(),
  "data",
  "test_packages",
  "exampleDeps"
)
example_pkg_deps2 <- file.path(
  testthat::test_path(),
  "data",
  "test_packages",
  "exampleDeps2"
)
