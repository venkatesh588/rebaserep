test_that("write_packages_lock_json produces output", {
  # Function runs and output file is created
  path <- file.path(tempdir(), "installed_packages.json")
  expect_error(
    write_packages_lock_json(tempdir(), "installed_packages.json"),
    NA
  )
  expect_true(file.exists(path))

  # File can be read back
  path <- file.path(tempdir(), "installed_packages.json")
  expect_error(json <- jsonlite::fromJSON(path), NA)
  expect_named(json)
  unlink(path)
})

test_that("error_on_available_package_mismatch works as expected", {
  path <- file.path(tempdir(), "installed_packages.json")
  write_packages_lock_json(tempdir(), "installed_packages.json")
  withr::with_options(list(repos = "https://cran.r-project.org/"), {
    expect_error(error_on_available_package_mismatch(path), NA)
  })

  ip <- installed.packages()
  package_to_skip <- rownames(ip)[1]

  mockery::stub(
    error_on_available_package_mismatch, "available.packages",
    function(...) {
      ap <- available.packages(repos = "https://cran.r-project.org/")
      ap[ap[, "Package"] == package_to_skip, "Version"] <- "9.9.9"
      ap
    }
  )

  mockery::stub(
    error_on_available_package_mismatch, "installed.packages",
    function(...) {
      ip <- installed.packages()
      ip[ip[, "Package"] == package_to_skip, "Version"] <- "9.9.9"
      ip
    }
  )


  # File can be read back
  withr::with_options(list(repos = "https://cran.r-project.org/"), {
    expect_error(error_on_available_package_mismatch(path), package_to_skip)
  })

  unlink(file.path(tempdir(), "installed_packages.json"))
})
