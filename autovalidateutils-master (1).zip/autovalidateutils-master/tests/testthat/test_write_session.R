test_that(
  "avu_session_info successfully executes and captures diagnostic info",
  {
    expect_silent(info <- avu_session_info(good, quiet = TRUE))

    # expect that we can execute session info func successfully
    expect_true({
      out <- capture.output(msgs <- capture.output(type = "message", {
        info <- avu_session_info(good)
      }))
      TRUE
    })

    expect_true(any(grepl("sessionInfo", msgs, fixed = TRUE)))
    expect_true(all(lapply(info, length) > 0L))

    # expect that fields intended to capture console output are character values
    raw_fields <- c("version", "repos")
    info_output <- info[!names(info) %in% raw_fields]
    expect_true(all(lapply(info_output, class) == "character"))

    # expect structured data to have specific data types
    expect_true(is.numeric(info$version))
    expect_true(is.character(info$repos))

    expect_true("summary" %in% names(info))
    expect_match(info$summary, "sessionInfo")
    expect_match(info$summary, "capabilities")
    expect_match(info$summary, "libPaths")

    avu_deps <- utils::packageDescription("autovalidateutils")$Imports
    avu_deps <- gsub("\\s.*", "", trimws(strsplit(avu_deps, ",")[[1L]]))
    expect_true(all(sapply(
      avu_deps, grepl, info$supporting_packages
    )))
  }
)

test_that("write_session_info produces session metadata files", {
  dir <- options::opt("output")
  session_yml <- file.path(dir, options::opt("session"))
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_session_info(good, )
    }))
    res
  })

  expect_true(file.exists(file.path(dir, options::opt("session"))))
  expect_true(any(grepl("sessionInfo", yaml::read_yaml(session_yml)$summary)))

  dir <- options::opt("output")
  session_yml <- file.path(dir, "test_session_yml")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_session_info(good, file = session_yml)
    }))
    res
  })

  expect_true(any(grepl("sessionInfo", yaml::read_yaml(session_yml)$summary)))
})
