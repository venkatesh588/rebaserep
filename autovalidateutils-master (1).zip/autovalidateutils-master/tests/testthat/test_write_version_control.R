setup_repo <- function(remote_url = "repo.com/project.git") {
  origin_git <- file.path(tempdir(), "exampleGood")
  unlink_dir(origin_git)
  dir.create(origin_git, recursive = TRUE)
  file.copy(good, dirname(origin_git), recursive = TRUE) # nolint

  clone_git <- file.path(tempdir(), "exampleGoodClone")
  unlink_dir(clone_git)
  dir.create(clone_git, recursive = TRUE)

  repo_origin <- git2r::init(origin_git)
  git2r::config(
    repo = repo_origin,
    user.name = "xyz",
    user.email = "xyz@123.com"
  )
  git2r::add(repo = repo_origin, path = ".")
  git2r::commit(repo = repo_origin, message = "First commit")

  capture.output(repo <- git2r::clone(origin_git, clone_git))
  git2r::config(repo = repo, user.name = "abc", user.email = "abc@123.com")
  writeLines("lorem ipsum", file.path(clone_git, "example.txt"))
  git2r::add(repo = repo, path = ".")
  git2r::commit(repo = repo, message = "First commit on clone")
  git2r::remote_set_url(repo = repo, name = "origin", url = remote_url)

  clone_git
}

test_that("mocked repository is created succesfully", {
  remote_url <- "https://www.fake.repo/fake/project.git"
  git_repo_dir <- setup_repo(remote_url)
  repo <- git2r::repository(git_repo_dir)

  expect_true(dir.exists(git_repo_dir))
  expect_s3_class(repo, "git_repository")
  expect_true(
    !is.null(git2r::branch_get_upstream(git2r::repository_head(repo)))
  )
  expect_equal(
    git2r::branch_remote_url(
      git2r::branch_get_upstream(git2r::repository_head(repo))
    ),
    remote_url
  )
})

test_that("write_git_yml produces output file", {
  remote_url <- "https://www.fake.repo/fake/project.git"
  good_git <- setup_repo(remote_url)

  # create temporary output space
  dir <- options::opt("output")
  vc_yml <- avu_path(dir, options::opt("version_control"))
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  # Created dir is a git repository
  expect_equal(
    capture.output(git2r::status(good_git)),
    "working directory clean"
  )
  expect_true(!file.exists(file.path(dir, options::opt("version_control"))))

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_git_yml(x = good_git, output = dir)
    }))
    res
  })

  expect_true(file.exists(vc_yml))
  expect_silent(vc <- yaml::read_yaml(vc_yml))
  expect_true(!"username" %in% names(vc))
  expect_true("url" %in% names(vc))
  expect_true(vc$url == remote_url)
  expect_true("checksum" %in% names(vc))
  expect_true("protocol" %in% names(vc$checksum))
  expect_true("hash" %in% names(vc$checksum))
  expect_true(isTRUE(grepl("[a-fA-F0-9]{8,}", vc$checksum$hash)))
  expect_true("branch" %in% names(vc))
  expect_true("detached" %in% names(vc))
  expect_true("status" %in% names(vc))
})

test_that("write_git_yml for git subdir package produces output file", {
  remote_url <- "https://www.fake.repo/fake/project.git"
  good_git <- setup_repo(remote_url)

  # create temporary output space
  dir <- options::opt("output")
  vc_yml <- avu_path(dir, options::opt("version_control"))
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  x <- as.package(good_git)
  x$repo_path <- x$path
  x$path <- file.path(x$path, "R") # any path within the repo directory

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_git_yml(x = x, output = dir)
    }))
    res
  })

  expect_true(file.exists(vc_yml))
  expect_silent(vc <- yaml::read_yaml(vc_yml))
  expect_true(!"username" %in% names(vc))
  expect_true("url" %in% names(vc))
  expect_true(vc$url == remote_url)
  expect_true("checksum" %in% names(vc))
  expect_true("protocol" %in% names(vc$checksum))
  expect_true("hash" %in% names(vc$checksum))
  expect_true(isTRUE(grepl("[a-fA-F0-9]{8,}", vc$checksum$hash)))
  expect_true("branch" %in% names(vc))
  expect_true("detached" %in% names(vc))
  expect_true("status" %in% names(vc))
})

test_that(
  "write_md5_checksum produces output file if an object
  has md5 checksum metadata",
  {
    dir <- options::opt("output")
    vc_yml <- file.path(dir, options::opt("version_control"))
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    pkg <- as.package(good)
    pkg$src_url <- "http://git.com/org/exampleGood.git"
    pkg$checksum <- list(hash = "a1b2c3", protocol = "MD5")

    expect_silent(write_md5_checksum(pkg))
    expect_true(file.exists(vc_yml))
    expect_silent(vc <- yaml::read_yaml(vc_yml))
    expect_true(vc$url == pkg$src_url)
    expect_true(vc$checksum$hash == pkg$checksum$hash)
    expect_true(tolower(vc$checksum$protocol) == tolower(pkg$checksum$protocol))
  }
)

test_that(
  "write_md5_checksum produces output file if hash
  information is passed by options",
  {
    dir <- options::opt("output")
    vc_yml <- file.path(dir, options::opt("version_control"))
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    hash <- "a1b2c3"
    url <- "http://git.com/org/exampleGood.git"

    withr::with_options(
      list(
        autovalidateutils.version_control.md5 = hash,
        autovalidateutils.version_control.url = url
      ),
      {
        expect_silent(write_md5_checksum(good))
      }
    )

    expect_true(file.exists(vc_yml))
    expect_silent(vc <- yaml::read_yaml(vc_yml))
    expect_true(vc$url == url)
    expect_true(vc$checksum$hash == hash)
    expect_true(tolower(vc$checksum$protocol) == tolower("md5"))
  }
)

test_that(
  "write_version_control uses git data if available and falls back
  to md5 if provided",
  {
    # create a local repository using example package files
    remote_url <- "https://fake.repo/fake/project.git"
    good_git <- setup_repo(remote_url)

    # create temporary output space
    dir <- options::opt("output")
    vc_yml <- avu_path(dir, options::opt("version_control"))
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    # when git is provided, use git for version control
    pkg <- as.package(good_git)
    expect_output(
      msgs <- capture.output(type = "message", write_version_control_yml(pkg))
    )
    expect_true(any(grepl("No reproducible source", msgs)))
    expect_true(any(grepl("Checking version control.*git", msgs)))

    pkg <- as.package(good_git)
    pkg$src_url <- "http://git.com/org/exampleGood.git"
    expect_output(
      msgs <- capture.output(type = "message", write_version_control_yml(pkg))
    )
    expect_true(!any(grepl("No reproducible source", msgs)))
    expect_true(any(grepl("Checking version control.*git", msgs)))

    expect_true(file.exists(vc_yml))
    expect_silent(vc <- yaml::read_yaml(vc_yml))
    expect_true("url" %in% names(vc))
    expect_true(vc$url == remote_url)
    expect_true("checksum" %in% names(vc))
    expect_true("protocol" %in% names(vc$checksum))
    expect_true("hash" %in% names(vc$checksum))
    expect_true(isTRUE(grepl("[a-fA-F0-9]{8,}", vc$checksum$hash)))

    # when git AND md5 are provided, default to using git for version control
    pkg <- as.package(good_git)
    pkg$src_url <- "http://git.com/org/exampleGood.git"
    pkg$checksum <- list(hash = "a1b2c3", protocol = "MD5")
    expect_output(
      msgs <- capture.output(type = "message", write_version_control_yml(pkg))
    )
    expect_true(any(grepl("version control", msgs)))
    expect_true(any(grepl("reproducible source", msgs)))
    expect_true(file.exists(vc_yml))
    expect_silent(vc <- yaml::read_yaml(vc_yml))
    expect_true("url" %in% names(vc))
    expect_true(vc$url == remote_url)
    expect_true("checksum" %in% names(vc))
    expect_true("protocol" %in% names(vc$checksum))
    expect_true("hash" %in% names(vc$checksum))
    expect_true(isTRUE(grepl("[a-fA-F0-9]{8,}", vc$checksum$hash)))

    # when ONLY md5 is provided, use md5 metadata
    pkg <- as.package(good)
    pkg$src_url <- "http://git.com/org/exampleGood.git"
    pkg$checksum <- list(hash = "a1b2c3", protocol = "MD5")
    expect_output(
      msgs <- capture.output(type = "message", write_version_control_yml(pkg))
    )
    expect_true(any(grepl("version control", msgs)))
    expect_true(any(grepl("reproducible source", msgs)))
    expect_true(file.exists(vc_yml))
    expect_silent(vc <- yaml::read_yaml(vc_yml))
    expect_true("checksum" %in% names(vc))
    expect_true("protocol" %in% names(vc$checksum))
    expect_true("hash" %in% names(vc$checksum))
    expect_true(tolower(vc$checksum$protocol) == tolower("md5"))
  }
)

test_that(
  "write_version_control displays failure message when
  no version control is available",
  {
    # just point to package source, whose root dir is not a git repo
    bad_no_git <- bad

    # create temporary output space
    dir <- options::opt("output")
    vc_yml <- avu_path(dir, options::opt("version_control"))
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    # when git is provided, use git for version control
    bad_no_git_pkg <- as.package(bad_no_git)
    suppressMessages(expect_message(
      expect_message(
        write_version_control_yml(bad_no_git_pkg),
        "No valid version control"
      ),
      # fails due to lack of version control
      "Checking"
    )) # checking version control notice printed
    expect_true(!file.exists(vc_yml))
  }
)
