test_that("covr required features have not yet been released", {
  skip_on_covr()
  skip_if(getOption("repos", "@CRAN@") == "@CRAN@")

  # if new covr version has been released, we can omit Remotes dependencies on
  # the development version
  ap <- remotes::available_packages()
  available_covr_ver <- ap[ap[, "Package"] == "covr", "Version"]
  expect_true(package_version(available_covr_ver) > "3.5.2")
})
