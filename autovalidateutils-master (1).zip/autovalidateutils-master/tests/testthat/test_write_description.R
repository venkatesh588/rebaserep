test_that("avu_description correct messages", {
  msgs <- capture.output(type = "message", {
    info <- avu_description(
      x = file.path(test_path(), "data", "test_packages", "exampleGood"),
    )
  })

  expect_true(any(grepl("dependency", msgs, fixed = TRUE)))
  expect_true(any(grepl("Authors", msgs, fixed = TRUE)))
})

test_that("write_description_yml produces session metadata files", {
  dir <- options::opt("output")
  x <- file.path(test_path(), "data", "test_packages", "exampleGood")
  description_yml <- file.path(dir, options::opt("description"))
  unlink(dir, recursive = TRUE, force = TRUE)
  dir.create(dir, recursive = TRUE)

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_description_yml(x = x, output = dir)
    }))
    res
  })

  expect_true(file.exists(file.path(dir, options::opt("description"))))

  dir <- options::opt("output")
  description_yml <- file.path(dir, "test_description_yml")
  x <- file.path(test_path(), "data", "test_packages", "exampleGood")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  expect_true({
    out <- capture.output(msgs <- capture.output(type = "message", {
      res <- write_description_yml(x = x, output = dir, file = description_yml)
    }))
    res
  })

  expect_true(file.exists(description_yml))
})
