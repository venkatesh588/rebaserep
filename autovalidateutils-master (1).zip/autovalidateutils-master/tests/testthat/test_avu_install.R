# tests for installation are computationally expensive, so instead we mock the
# installation functions and print out where packages _would be_ installed,
# which we can test against our expected installation locations.
#
# Functions that perform the installation are mocked with a simpler function
# that instead prints out this diagnostic info.
#
# see ?mockery::stub for details

test_that("avu_install installs target package into validation library", {
  # don't actually install, just output where it would be installed to
  orig_libpaths <- .libPaths()
  unlink(file.path(options::opt("log_output"), "installation.log"))
  # don't try to load package from install location
  mockery::stub(avu_install, "as.package", function(...) {
    as.package(example_pkg_deps)
  })
  # don't throw errors when checking dependency availability
  mockery::stub(avu_install, "check_dependencies_satisfiability", NULL)

  # expect that we "install" (eg print with mocks)
  # to validated library (libs[[1L]])
  expect_error(avu_install(example_pkg_deps, quiet = FALSE), NA)
  expect_true(any(grepl(
    "* DONE (exampleBad)", readLines(file.path(
      options::opt("log_output"), "installation.log"
    )), fixed = TRUE
  )))
  .libPaths(orig_libpaths)
  unlink(options::opt("log_output"))
})

test_that(
  "install_validation_dependencies does not return error
  where package could not be installed",
  {
    expect_error(
      install_validation_dependencies(
        as.package(example_pkg_deps),
        deptype = "Depends",
        lib = file.path(tempdir(), "depends"),
        repos = getOption("repos"),
        upgrade = TRUE,
        additional_repositories = FALSE
      ),
      NA
    )
  }
)


test_that(
  "avu_install installs target package dependencies
  install into appropriate libraries",
  {
    # don't try to load package from install location
    mockery::stub(
      avu_install,
      "as.package",
      function(...) as.package(example_pkg_deps)
    )
    val <- file.path(tempdir(), "val")
    # with `dependencies == TRUE`, all deps installed
    avu_test_libs <- list(
      val,
      Depends = depends <- file.path(tempdir(), "depends"),
      Imports = imports <- file.path(tempdir(), "imports"),
      LinkingTo = linking_to <- file.path(tempdir(), "linking"),
      Suggests = suggests <- file.path(tempdir(), "suggests")
    )

    orig_libpaths <- .libPaths()
    lapply(avu_test_libs, dir_create)
    expect_error(out <- capture.output(invisible(
      avu_install(
        example_pkg_deps,
        dependencies = TRUE,
        upgrade = TRUE,
        libs = avu_test_libs,
        lib.loc = NULL
      )
    ), type = "message"), NA)
    expect_true(any(grepl(
      "Installing 'Depends' dependencies", out, fixed = TRUE
    )))
    expect_true(any(grepl(
      "Installing 'Imports' dependencies", out, fixed = TRUE
    )))
    expect_true(any(
      grepl("Installing 'LinkingTo' dependencies", out, fixed = TRUE)
    ))
    expect_true(any(grepl(
      "Installing 'Suggests' dependencies", out, fixed = TRUE
    )))
    expect_true(any(grepl(
      "Installing 'Enhances' dependencies", out, fixed = TRUE
    )))

    # clean up our new libraries when we're done
    .libPaths(orig_libpaths)
    lapply(avu_test_libs, unlink_dir)

    # with `dependencies == NA`, don't install Suggests
    # (similar to remotes default)
    orig_libpaths <- .libPaths()
    lapply(avu_test_libs, dir_create)
    expect_error(out <- capture.output(invisible(
      avu_install(
        example_pkg_deps,
        dependencies = NA,
        libs = avu_test_libs,
        upgrade = NULL
      )
    ), type = "message"), NA)
    expect_true(any(grepl(
      "Installing 'Depends' dependencies", out, fixed = TRUE
    )))
    expect_true(any(grepl(
      "Installing 'Imports' dependencies", out, fixed = TRUE
    )))
    expect_true(any(
      grepl("Installing 'LinkingTo' dependencies", out, fixed = TRUE)
    ))
    expect_false(any(grepl(
      "Installing 'Suggests' dependencies", out, fixed = TRUE
    )))
    expect_false(any(grepl(
      "Installing 'Enhances' dependencies", out, fixed = TRUE
    )))

    # clean up our new libraries when we're done
    .libPaths(orig_libpaths)
    lapply(avu_test_libs, unlink_dir)

    # `dependencies == FALSE` libraries are not installed
    orig_libpaths <- .libPaths()
    lapply(avu_test_libs, dir_create)
    expect_error(out <- capture.output(invisible(
      avu_install(
        example_pkg_deps,
        dependencies = FALSE,
        libs = avu_test_libs,
        upgrade = FALSE
      )
    ), type = "message"), NA)
    expect_false(any(grepl(
      "Installing 'Depends' dependencies", out, fixed = TRUE
    )))
    expect_false(any(grepl(
      "Installing 'Imports' dependencies", out, fixed = TRUE
    )))
    expect_false(any(
      grepl("Installing 'LinkingTo' dependencies", out, fixed = TRUE)
    ))
    expect_false(any(grepl(
      "Installing 'Suggests' dependencies", out, fixed = TRUE
    )))
    expect_false(any(grepl(
      "Installing 'Enhances' dependencies", out, fixed = TRUE
    )))

    # clean up our new libraries when we're done
    .libPaths(orig_libpaths)
    lapply(avu_test_libs, unlink_dir)
  }
)

test_that(
  "avu_install reports and continues when suggested packages
  can't be installed",
  {
    # don't try to load package from install location
    mockery::stub(
      avu_install,
      "as.package",
      function(...) as.package(example_pkg_deps)
    )

    orig_libpaths <- .libPaths()
    expect_message(avu_install(example_pkg_deps, dependencies = TRUE))
    .libPaths(orig_libpaths)
    lapply(avu_initialize_libs(), unlink_dir)
  }
)

test_that(
  "check_dependencies_satisfiability identifies unsatisfiable dependencies",
  {
    dir_create(options::opt("log_output"))
    err_msg <- tryCatch({
      check_dependencies_satisfiability(example_pkg_deps2, "Depends", c())
    }, error = function(e) {
      e$message
    })

    expect_match(err_msg, "^\\s*Dependencies not met")
    expect_match(err_msg, "depends_dep")
    expect_no_match(err_msg, "imports_dep")
    expect_no_match(err_msg, "linking_to_dep")

    err_msg <- tryCatch({
      check_dependencies_satisfiability(
        example_pkg_deps2,
        c("Depends", "Imports"),
        c()
      )
    }, error = function(e) {
      e$message
    })

    expect_match(err_msg, "^\\s*Dependencies not met")
    expect_match(err_msg, "depends_dep")
    expect_match(err_msg, "imports_dep")
    expect_match(err_msg, "utils\\s*>=\\s*1000\\.0\\.0")
    expect_no_match(err_msg, "utils\\s*<=\\s*2000\\.0\\.0")
    expect_no_match(err_msg, "tools")
    expect_no_match(err_msg, "linking_to_dep")

    err_msg <- tryCatch({
      check_dependencies_satisfiability(
        example_pkg_deps2,
        c("Depends", "Imports", "LinkingTo"),
        c()
      )
    }, error = function(e) {
      e$message
    })

    expect_match(err_msg, "^\\s*Dependencies not met")
    expect_match(err_msg, "depends_dep")
    expect_match(err_msg, "imports_dep")
    expect_match(err_msg, "Imports\\s*utils\\s*>=\\s*1000\\.0\\.0")
    expect_match(err_msg, "linking_to_dep")
  }
)
