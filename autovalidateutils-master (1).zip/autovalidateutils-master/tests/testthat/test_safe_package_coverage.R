test_that(
  "safe_package_coverage executes even without global options
  and records output files",
  {
    test_exec_log <- tempfile("test-safe-package-coverage-exec-log")
    test_results_file <- tempfile("test-safe-package-coverage-file")

    good_testthat <- file.path(
      test_path(),
      "data",
      "test_packages",
      "exampleGood"
    )
    expect_warning(suppressMessages(withr::with_options(
      list(
        covr.record_tests = FALSE,
        keep.source.pkgs = FALSE,
        autovalidateutils.use_testthat = FALSE
      ), {
        cov <- safe_package_coverage(
          good_testthat,
          file = test_results_file,
          test_exec_log = test_exec_log
        )
      }
    )), NA)

    # expect that coverage was calculated with options(covr.record_tests = TRUE)
    expect_true(!is.null(attr(cov, "tests")))
    expect_true(length(attr(cov, "tests")) > 0L)

    # logs contain proper test execution code
    expect_true(file.exists(test_exec_log))
    expect_true(any(grepl(
      "tools::testInstalledPackage", readLines(test_exec_log)
    )))
  }
)

test_that(
  "safe_package_coverage executes with testthat as flag set to TRUE
  and records output files",
  {
    test_exec_log <- tempfile("test-safe-package-coverage-exec-log")
    test_results_file <- tempfile("test-safe-package-coverage-file")

    old_opts <- options(covr.record_tests = FALSE, keep.source.pkgs = FALSE)
    on.exit(options(old_opts))
    dir_create(dirname(testing_session <- avu_path(
      options::opt("output"), options::opt("testing_session")
    )))
    dir_create(
      cov_logs <- avu_path(options::opt("output"), options::opt("cov_logs"))
    )
    dir_create(options::opt("log_output"))
    good_testthat <- file.path(
      test_path(),
      "data",
      "test_packages",
      "exampleGood"
    )
    expect_warning(suppressMessages(
      cov <- safe_package_coverage(
        good_testthat,
        file = test_results_file,
        test_exec_log = test_exec_log,
        uses_testthat_flag = TRUE,
        testing_session = testing_session,
        log_output = options::opt("log_output"),
        cov_logs = cov_logs
      )
    ), NA)

    # expect that coverage was calculated with options(covr.record_tests = TRUE)
    expect_true(!is.null(attr(cov, "tests")))
    expect_true(length(attr(cov, "tests")) > 0L)

    # logs contain proper test execution code
    expect_true(file.exists(testing_session))
    expect_true(any(grepl("rlang", readLines(testing_session))))
    expect_true(file.exists(avu_path(
      options::opt("log_output"), "testing_sessioninfo.json"
    )))
    expect_true(file.exists(test_exec_log))
    expect_true(any(grepl(
      "sessionInfo", readLines(test_exec_log)
    )))
    expect_true(any(grepl(
      "testthat::test_package", readLines(test_exec_log)
    )))
  }
)

test_that("safe_package_coverage succeeds even with packages with no tests", {
  test_exec_log <- tempfile("test-safe-package-coverage-exec-log")
  test_results_file <- tempfile("test-safe-package-coverage-file")
  dir_create(
    cov_logs <- avu_path(options::opt("output"), options::opt("cov_logs"))
  )
  old_opts <- options(covr.record_tests = FALSE, keep.source.pkgs = FALSE)
  on.exit(options(old_opts))

  bad_no_tests <- file.path(test_path(), "data", "test_packages", "exampleBad")
  expect_warning(
    suppressMessages(
      withr::with_libpaths(c(package_library("covr"), .libPaths()), {
        cov <- safe_package_coverage(
          bad_no_tests,
          file = test_results_file,
          test_exec_log = test_exec_log,
          cov_logs = cov_logs
        )
      })
    ), NA
  )

  # with no tests, we default to using tools::testInstalledPackage
  expect_true(file.exists(test_exec_log))
  expect_true(
    any(grepl("tools::testInstalledPackage", readLines(test_exec_log)))
  )

  # test results are not created since testthat is not used
  expect_false(file.exists(test_results_file))
})

test_that("prepare_coverage_df helper works as expected", {
  cov_table_bad <- prepare_coverage_df(cov_bad)
  cov_table_good <- prepare_coverage_df(cov_good)
  cov_table_okay <- prepare_coverage_df(cov_okay)
  cov_table_empty <- prepare_coverage_df(list())

  expect_s3_class(cov_table_bad, "data.frame")
  expect_s3_class(cov_table_good, "data.frame")
  expect_s3_class(cov_table_okay, "data.frame")
  expect_s3_class(cov_table_empty, "data.frame")

  expect_equal(NROW(cov_table_bad), 2)
  expect_equal(NROW(cov_table_good), 5)
  expect_equal(NROW(cov_table_okay), 2)
  expect_equal(NROW(cov_table_empty), 1)

  expect_equal(colnames(cov_table_empty), c("File", "Coverage"))
})
