test_that("avu_r_cmd_check runs rcmd check and presents messages as lists", {
  expect_silent(suppressMessages(rcc <- avu_r_cmd_check(good)))
  expect_true(
    all(lapply(rcc[c("errors", "warnings", "notes")], class) == "list")
  )

  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)

  expect_length(out <- capture.output(msgs <- capture.output(type = "message", {
    res <- write_r_cmd_check_yml(good)
  })), 0L)
  expect_true(res)
  testthat::expect_length(avu_callback(res), 1)

  # No messages issued when vignettes build properly
  expect_false(any(grepl("Errors.*building vignettes", msgs)))
})

test_that(
  "avu_r_cmd_check runs rcmd check and build vignettes
  for packages without inst/docs",
  {
    expect_silent(suppressMessages(rcc <- avu_r_cmd_check(good2)))
    expect_true(
      all(lapply(rcc[c("errors", "warnings", "notes")], class) == "list")
    )

    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    expect_length(
      out <- capture.output(msgs <- capture.output(type = "message", {
        res <- write_r_cmd_check_yml(good2)
      })),
      0L
    )
    expect_true(res)
    testthat::expect_length(avu_callback(res), 1)

    # No messages issued when vignettes build properly
    expect_false(any(grepl("Errors.*building vignettes", msgs)))
  }
)

test_that("write_r_cmd_check runs rcmd check on bad packages", {
  # warnings get captured
  expect_silent(suppressMessages(rcc <- avu_r_cmd_check(bad)))
  expect_true(length(rcc$warnings) > 0L)

  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)


  expect_length(out <- capture.output(msgs <- capture.output(type = "message", {
    res <- write_r_cmd_check_yml(bad)
  })), 0L)
  expect_true(res)
  testthat::expect_length(avu_callback(res), 1)


  # Failure to build a vignette issues a message
  expect_true(any(grepl("Errors.*building vignettes", msgs)))

  # all warnings printed as alerts
  expect_equal(
    sum(grepl("... WARNING", msgs, fixed = TRUE)), length(rcc$warnings)
  )

  # all notes printed as alerts
  expect_equal(sum(grepl("... NOTE", msgs, fixed = TRUE)), length(rcc$notes))
})

test_that("write_r_cmd_check runs rcmd check on okay packages", {
  # warnings get captured
  expect_silent(suppressMessages(rcc <- avu_r_cmd_check(okay)))
  expect_true(length(rcc$warnings) > 0L)

  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)


  expect_length(out <- capture.output(msgs <- capture.output(type = "message", {
    res <- write_r_cmd_check_yml(okay)
  })), 0L)
  expect_true(res)
  testthat::expect_length(avu_callback(res), 1)


  # all warnings printed as alerts
  expect_equal(
    sum(grepl("... WARNING", msgs, fixed = TRUE)), length(rcc$warnings)
  )
})

test_that("write_r_cmd_check runs rcmd check on okay packages with cran flag", {
  # warnings get captured

  withr::with_options(
    new = list(autovalidateutils.r_cmd_check_variables = "cran"),
    {
      expect_silent(suppressMessages(rcc <- avu_r_cmd_check(okay)))
    }
  )

  expect_true(length(rcc$warnings) > 0L)

  dir <- options::opt("output")
  unlink_dir(dir)
  dir.create(dir, recursive = TRUE)


  expect_length(out <- capture.output(msgs <- capture.output(type = "message", {
    res <- write_r_cmd_check_yml(okay)
  })), 0L)
  expect_true(res)
  testthat::expect_length(avu_callback(res), 1)


  # all warnings printed as alerts
  expect_equal(
    sum(grepl("... WARNING", msgs, fixed = TRUE)), length(rcc$warnings)
  )
})

test_that(
  "write_r_cmd_check runs rcmd check on okay packages with custom variables",
  {
    # warnings get captured
    withr::with_options(
      new = list(
        autovalidateutils.r_cmd_check_variables = c(
          "_R_CHECK_FORCE_SUGGESTS_" = FALSE,
          "_R_CHECK_RD_XREFS_" = FALSE,
          "_R_CHECK_SYSTEM_CLOCK_" = FALSE
        ),
        autovalidateutils.generalize_sources = TRUE
      ),
      {
        expect_silent(suppressMessages(rcc <- avu_r_cmd_check(okay)))
      }
    )

    expect_true(length(rcc$warnings) > 0L)

    dir <- options::opt("output")
    unlink_dir(dir)
    dir.create(dir, recursive = TRUE)

    withr::with_options(
      new = list(
        autovalidateutils.r_cmd_check_variables = c(
          "_R_CHECK_FORCE_SUGGESTS_" = FALSE,
          "_R_CHECK_RD_XREFS_" = FALSE,
          "_R_CHECK_SYSTEM_CLOCK_" = FALSE
        ),
        autovalidateutils.generalize_sources = TRUE
      ),
      {
        expect_length(
          out <- capture.output(msgs <- capture.output(
            type = "message",
            {
              res <- write_r_cmd_check_yml(okay)
            }
          )
          ), 0L
        )
      }
    )
    expect_true(res)
    expect_true(is.function(avu_callback(res)[[1]]))
    expect_true(any(grepl(
      "unlink", capture.output(avu_callback(res))
    )))

    # all warnings printed as alerts
    expect_equal(
      sum(grepl("... WARNING", msgs, fixed = TRUE)), length(rcc$warnings)
    )
  }
)

test_that("avu_r_cmd_check saves check results for default directories", {
  output <- options::opt("output")
  check_dir <- options::opt("check_dir")
  check_dir_path <- file.path(output, check_dir)
  unlink_dir(check_dir_path)

  expect_silent(suppressMessages(rcc <- avu_r_cmd_check(
    x = good,
    output = output,
    check_dir = check_dir
  )))

  actual_files <- list.files(check_dir_path)
  expected_files <- c(
    "exampleGood_0.0.0.9000.tar.gz",
    "exampleGood.Rcheck"
  )

  expect_equal(
    sort(actual_files),
    sort(expected_files)
  )

  unlink_dir(check_dir_path)
})

test_that("avu_r_cmd_check saves results for specified directories", {
  check_dir_parts <- list(
    list(
      output = tempfile("tmp_output"),
      check_dir = options::opt("check_dir")
    ),
    list(output = options::opt("output"), check_dir = "tmp_check_dir"),
    list(output = tempfile("tmp_output"), check_dir = "tmp_check_dir")
  )

  check_dir_paths <- lapply(
    check_dir_parts,
    function(i) {
      file.path(i$output, i$check_dir)
    }
  )

  lapply(check_dir_paths, unlink_dir)

  for (i in check_dir_parts) {
    expect_silent(suppressMessages(rcc <- avu_r_cmd_check(
      x = good,
      output = i$output,
      check_dir = i$check_dir
    )))
  }

  expected_files <- c(
    "exampleGood_0.0.0.9000.tar.gz",
    "exampleGood.Rcheck"
  )

  lapply(
    check_dir_paths,
    function(path) {
      actual_files <- list.files(path)
      expect_equal(
        sort(actual_files),
        sort(expected_files)
      )
    }
  )

  lapply(check_dir_paths, unlink_dir)
})
