pkg_w_vulns <- list(
  package = "igraph",
  version = "1.2.2"
)

pkg_w_vulns_expected_res <- list(
  "RSEC-2023-4" = list(
    name = "igraph",
    summary = "NULL pointer dereference vulnerability",
    url = "https://osv.dev/vulnerability/RSEC-2023-4",
    ecosystem = "CRAN"
  )
)

pkg_wo_vulns <- list(
  package = "rd2markdown",
  version = "0.0.1"
)

syspkgs <- data.frame(
  package = "libxml2",
  version = "2.9.13+dfsg-1ubuntu0.4"
)

syspkgs_expected_res <- list(
  `UBUNTU-CVE-2022-49043` = list(
    name = "libxml2",
    summary = NA_character_,
    url = "https://osv.dev/vulnerability/UBUNTU-CVE-2022-49043",
    ecosystem = "Ubuntu"
  ),
  `UBUNTU-CVE-2024-34459` = list(
    name = "libxml2",
    summary = NA_character_,
    url = "https://osv.dev/vulnerability/UBUNTU-CVE-2024-34459",
    ecosystem = "Ubuntu"
  ),
  `USN-7240-1` = list(
    name = "libxml2",
    summary = "libxml2 vulnerabilities",
    url = "https://osv.dev/vulnerability/USN-7240-1",
    ecosystem = "Ubuntu"
  )
)

ubuntu_deps <- list(
  packages = data.frame(
    sysreq = c("gmp", "glpk", "libxml2")
  )
)

test_that("test_api_calls", {
  expect_equal(
    get_osv_db_data_cran(pkg_w_vulns$package, pkg_w_vulns$version),
    pkg_w_vulns_expected_res
  )

  expect_equal(
    get_osv_db_data_cran(pkg_wo_vulns$package, pkg_wo_vulns$version),
    list()
  )

  # Subset response in case new vulns are discovered
  api_res <- get_osv_db_data_ubuntu(syspkgs$package, syspkgs$version)[c(
    "UBUNTU-CVE-2022-49043",
    "UBUNTU-CVE-2024-34459",
    "USN-7240-1"
  )]

  expect_equal(
    api_res,
    syspkgs_expected_res
  )
})

test_that("avu_vulnerabilities_info properly queries OSV database for
          a package with both CRAN and Ubuntu vulns", {

    # mock package data
    with_mocked_bindings({
      with_mocked_bindings({
        suppressMessages(
          res <- avu_vulnerabilities_info(pkg_w_vulns)
        )
      },
      as.package = function(x) x,
      is_ubuntu = function() TRUE,
      get_osv_db_data_cran = function(...) pkg_w_vulns_expected_res,
      get_osv_db_data_ubuntu = function(...) syspkgs_expected_res)
    },
    pkg_sysreqs = function(...) ubuntu_deps,
    sysreqs_list_system_packages = function(...) syspkgs,
    .package = "pak"
    )

    expect_type(res, "list")
    expect_identical(
      names(res),
      c(
        "RSEC-2023-4",
        "UBUNTU-CVE-2022-49043",
        "UBUNTU-CVE-2024-34459",
        "USN-7240-1"
      )
    )
    expect_identical(
      vapply(
        res,
        "[[",
        FUN.VALUE = character(1),
        "ecosystem",
        USE.NAMES = FALSE
      ),
      c("CRAN", "Ubuntu", "Ubuntu", "Ubuntu")
    )
    expect_identical(
      vapply(
        res,
        "[[",
        FUN.VALUE = character(1),
        "name",
        USE.NAMES = FALSE
      ),
      c("igraph", "libxml2", "libxml2", "libxml2")
    )
  }
)

test_that("avu_vulnerabilities_info properly queries OSV database for
          a package with only Ubuntu vulns", {

    with_mocked_bindings({
      with_mocked_bindings({
        suppressMessages(
          res <- avu_vulnerabilities_info(pkg_wo_vulns)
        )
      },
      as.package = function(x) x,
      is_ubuntu = function() TRUE,
      get_osv_db_data_cran = function(...) list(),
      get_osv_db_data_ubuntu = function(...) syspkgs_expected_res)
    },
    pkg_sysreqs = function(...) ubuntu_deps,
    sysreqs_list_system_packages = function(...) syspkgs,
    .package = "pak"
    )

    expect_type(res, "list")
    expect_identical(
      names(res),
      c("UBUNTU-CVE-2022-49043", "UBUNTU-CVE-2024-34459", "USN-7240-1")
    )
    expect_identical(
      vapply(
        res,
        "[[",
        FUN.VALUE = character(1),
        "ecosystem",
        USE.NAMES = FALSE
      ),
      c("Ubuntu", "Ubuntu", "Ubuntu")
    )
    expect_identical(
      vapply(res, "[[", FUN.VALUE = character(1), "name", USE.NAMES = FALSE),
      c("libxml2", "libxml2", "libxml2")
    )
  }
)

test_that("avu_vulnerabilities_info properly queries OSV database for
          a package with none vulns", {

    with_mocked_bindings({
      with_mocked_bindings({
        suppressMessages(
          res <- avu_vulnerabilities_info(pkg_wo_vulns)
        )
      },
      as.package = function(x) x,
      is_ubuntu = function() TRUE,
      get_osv_db_data_cran = function(...) list())
    },
    pkg_sysreqs = function(...) list(),
    sysreqs_list_system_packages = function(...) syspkgs,
    .package = "pak"
    )

    expect_type(res, "list")
    expect_length(res, 0)
  }
)

test_that("avu_vulnerabilities_info properly queries OSV database for
          a package with none vulns", {

    with_mocked_bindings({
      with_mocked_bindings({
        suppressMessages(
          res <- avu_vulnerabilities_info(pkg_wo_vulns)
        )
      },
      as.package = function(x) x,
      is_ubuntu = function() TRUE)
    },
    pkg_sysreqs = function(...) list(),
    sysreqs_list_system_packages = function(...) syspkgs,
    .package = "pak"
    )

    expect_type(res, "list")
    expect_length(res, 0)
  }
)

test_that("avu_vulnerabilities_info properly queries OSV database for
          a package with only Ubuntu vulns", {

    with_mocked_bindings({
      with_mocked_bindings({
        suppressMessages(
          write_vulnerabilities_info(pkg_w_vulns)
        )
      },
      as.package = function(x) x,
      is_ubuntu = function() TRUE)
    },
    pkg_sysreqs = function(...) ubuntu_deps,
    sysreqs_list_system_packages = function(...) syspkgs,
    .package = "pak"
    )

    file <- avu_path(options::opt("output"), options::opt("vulnerabilities"))

    expect_true(file.exists(file))
    expect_no_error(res <- yaml::read_yaml(file))
    expect_type(res, "list")
    # Subset response in case new vulns are discovered
    res <- res[c(
      "RSEC-2023-4",
      "UBUNTU-CVE-2022-49043",
      "UBUNTU-CVE-2024-34459",
      "USN-7240-1"
    )]
    expect_identical(
      names(res),
      c(
        "RSEC-2023-4",
        "UBUNTU-CVE-2022-49043",
        "UBUNTU-CVE-2024-34459",
        "USN-7240-1"
      )
    )
    expect_identical(
      vapply(
        res,
        "[[",
        FUN.VALUE = character(1),
        "ecosystem",
        USE.NAMES = FALSE
      ),
      c("CRAN", "Ubuntu", "Ubuntu", "Ubuntu")
    )
    expect_identical(
      vapply(
        res,
        "[[",
        FUN.VALUE = character(1),
        "name",
        USE.NAMES = FALSE
      ),
      c("igraph", "libxml2", "libxml2", "libxml2")
    )
  }
)
