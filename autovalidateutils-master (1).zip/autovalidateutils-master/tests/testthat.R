library(testthat)
library(autovalidateutils)

test_check("autovalidateutils")
