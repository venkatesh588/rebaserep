#' Write out an assortment of package metadata necessary to run autovalidate
#'
#' The core of autovalidateutils, this function will step through a series of
#' diagnostic steps and record metadata about the package in a format that can
#' be read into the `autovalidate` python tool to populate a validation report.
#'
#' @param x A file path, url or object of class 'package'. See "Details" section
#'   for specifications.
#' @param ... Additional arguments passed to methods
#' @param metadata A named list of additional fields for use within
#'   autovalidate. Primarily, this is used during method dispatch to record
#'   traceability information pertaining to the source of the package code.
#'
#' @inheritParams options_params
#'
#' @details
#' Parameter `x` accepts a number of different designations for package
#' sources, all provided as a `character` value or `package` class object.
#'
#' \describe{
#' \item{class 'package'}{A package class object, as produced by `devtools`
#' `as.package()`.}
#' \item{source code directory path}{A file path to an existing package source
#' code directory.}
#' \item{source code repository}{A url (.git) to git repository, which could be
#' used to clone the repository.}
#' \item{a package archive}{A file path to a local package archive (.tar.gz or
#' .tgz).}
#' \item{a url}{A url of a package archive, beginning with an "http(s?)://"
#' protocol designation.}
#' }
#'
#' @section S3 Dispatch & Recursion:
#' Internally, the protocol and file extension are used to recursively call
#' `autovalidate()` until a source code directory is prepared. For example,
#' provided an input such as `"https://host.com/archive.tar.gz"`, the `https`
#' protocol will be handled first, prompting a download of the source code
#' archive, then the `.tar.gz` extension will be handled, prompting the archive
#' to be extracted, and finally the source code directory will be used to build
#' a `package` object, which is evaluated.
#'
#' Throughout this process, metadata is bundled with the resulting object as it
#' is prepared, recording information such as the url from which the source code
#' was downloaded and the checksum of the downloaded package archive. Of note,
#' metadata fields `src_url` is populated for any `http(s)://` protocol url, or
#' for any `.git` url, and a `checksum` field whenever an intermediate package
#' archive is processed.
#'
#' @section Dependency Management:
#' By default, only `"Suggests"` dependencies are installed in addition to the
#' target package during installation from source. This is to prevent
#' accidentally introducing a package into a validated environment before its
#' dependencies have been validated, rendering it unusable upon deployment. This
#' default behavior can be configured further by setting the
#' `autovalidateutils.libs` option, providing a non-`NULL` library path for
#' other forms of dependencies.
#'
#' For further details about dependency management, see the `libs` entry in
#' `?autovalidateutils_options`.
#'
#' @examples
#' \dontrun{
#' # run against current source code directory, and save results
#' autovalidate(output = "path/to/validation/dir")
#'
#' # run against a package available in options("repos")
#' autovalidate("praise")
#'
#' # run against a source code archive (local or over http)
#' autovalidate("https://cran.r-project.org/src/contrib/praise_1.0.0.tar.gz")
#'
#' # run against a git repo
#' # (assuming you have git credentials configured to clone it)
#' autovalidate("https://code.roche.com/autovalidate-r/autovalidateutils.git")
#' }
#'
#' @rdname autovalidate
#' @export
#'
autovalidate <- function(
    x = ".",
    ...,
    metadata = list(),
    clean = options::opt("clean")) {
  # clean up tmp directory
  if (clean) {
    avu_files <- list.files(
      tempdir(),
      recursive = FALSE,
      pattern = "(autovalidateutils_)|(R_LIB_)",
      full.names = TRUE
    )
    on.exit(
      unlink(avu_files, recursive = TRUE),
      add = TRUE,
      after = TRUE
    )
  }

  # revert to original libpaths after running autovalidate
  inbound_libpaths <- .libPaths()
  on.exit(.libPaths(inbound_libpaths), add = TRUE, after = FALSE)

  UseMethod("autovalidate")
}

#' @method autovalidate character
#' @export
autovalidate.character <- function(x = ".", ..., metadata = list()) {
  if (file.exists(file.path(x, "DESCRIPTION"))) {
    metadata$src_url <- paste0("file://", x)
    return(autovalidate(as.package(x), ..., metadata = metadata))
  }

  if (x %in% rownames(ap <- available.packages())) {
    pkg <- ap[x, ]
    archive_url <- sprintf(
      "%s/%s_%s.tar.gz",
      pkg["Repository"],
      pkg["Package"],
      pkg["Version"]
    )

    return(autovalidate(archive_url, ..., metadata = metadata))
  }

  # dispatch on uri protocol and extension
  bn <- basename(x)
  ext <- if (grepl("\\.", bn)) gsub("^[^.]*\\.", "", bn) else character(0L)
  ext <- gsub("@.*$", "", ext) # omit repo@ref `@ref` from extension
  prot <- if (grepl("://", x)) gsub("://.*", "", x) else character(0L)

  # when extension is ambiguous (eg 2.3.tar.gz vs tar.gz vs gz), start with
  # most verbose interpretation and rely on dispatch to use first applicable
  exts <- strsplit(ext, "\\.")[1][[1L]] # handle zero-length ext
  exts <- vapply(
    seq_along(exts),
    function(i) paste(exts[i:length(exts)], collapse = "."),
    character(1L)
  )

  if (length(c(prot, exts)) == 0L || any(c(prot, exts) %in% class(x))) {
    stop(sprintf("Unable to autovalidate '%s', no source code found", x))
  }

  class(x) <- c(prot, exts, class(x))
  autovalidate(x, ..., metadata = metadata)
}

#'
#' @param steps A list of functions or function names to step through to
#'   generate autovalidate files. If named, the name will be used for
#'   communicating the step behavior in the console during execution. See
#'   "Steps" section for details on the default steps.
#' @param libs A `list` of library directories. The first value is used as the
#'   installation target for package `x`, and its dependencies are installed to
#'   libraries indicated by corresponding named entries in `libs`. For more
#'   details see the `avu_initialize_libs` documentation.
#' @inheritParams avu_install
#' @inheritParams options_params
#'
#' @importFrom cli cli_rule cli_text
#' @rdname autovalidate
#' @export
#'
autovalidate.package <- function(
    x = ".", output = options::opt("output"),
    steps = avu_steps(), quiet = options::opt("quiet"), ...,
    dependencies = options::opt("inst_deps"),
    log_output = options::opt("log_output"),
    lib.loc = options::opt("lib.loc"),
    metadata = list(), libs = avu_initialize_libs()) {
  # Save parameters so they could be used by steps functions
  args <- list(libs = libs)

  # Set options to be used later in steps
  options(options::opts_list(
    output = output,
    log_output = log_output,
    quiet = quiet,
    lib.loc = lib.loc
  ))

  # Strip non-utf8 signs from the DESCRIPTION as they may prevent manual
  # installation for some packages like sfsmisc

  if (options::opt("clear_description")) {
    remove_non_utf8_from_file(file.path(x$path, "DESCRIPTION"))
  }

  dir_create(output, recursive = TRUE)
  dir_create(log_output, recursive = TRUE)

  # install into our temporary validation library
  install_x <- avu_install(
    x$path,
    libs = libs,
    dependencies = dependencies,
    ...,
    log_output = log_output,
    quiet = quiet
  )
  x$libPath <- dirname(install_x$path)

  # mix in any metadata that was accumulated during package sourcing
  extra_fields <- setdiff(names(metadata), names(x))
  x[extra_fields] <- metadata[extra_fields]

  pkg_stub <- sprintf("%s (%s)", x$package, x$version)

  avu_log(c(), append = FALSE) # clear log file
  avu_cli(cli::cli_rule("autovalidateutils", right = pkg_stub))
  steps_callbacks <- list()
  for (i in seq_along(steps)) {
    is_named <- !is.null(names(steps)) && nchar(names(steps)[[i]]) > 0
    step_name <- if (is_named) names(steps)[[i]] else sprintf("Step %d", i)
    step_fn <- steps[[i]]
    if (is.character(step_fn)) {
      step_fn <- get(step_fn, envir = getNamespace(packageName()))
    }
    avu_cli_h3(step_name)
    steps_callbacks[[step_name]] <- avu_callback(step_fn(
      x,
      output = output,
      log_output = log_output,
      quiet = quiet,
      args = args
    )
    )
    # Make sure that after each step finishes, we garbage collect no longer
    # required objects
    gc(verbose = FALSE, reset = FALSE, full = TRUE)
  }

  # Run callbacks
  lapply(steps_callbacks, function(x) {
    lapply(x, do.call, args = list())
  })


  avu_cli(cli::cli_text()) # end with blank line
  invisible(output)
}

#' @export
autovalidate.http <- function(x = ".", ..., metadata = list()) {
  if (inherits(x, "git")) {
    return(NextMethod())
  }
  metadata$src_url <- x
  bn <- basename(x)
  # Rename package source to a generic name to make sure it does not
  # contain disallowed signs
  name <- gsub(
    tools::file_path_sans_ext(bn, compression = TRUE),
    "package",
    bn,
    fixed = TRUE
  )
  destfile <- file.path(tempfile("autovalidateutils_"), name)
  dir.create(dirname(destfile), recursive = TRUE)
  download.file(x, destfile = destfile)
  autovalidate(destfile, ..., metadata = metadata)
}

#' @export
autovalidate.https <- autovalidate.http

#'
#' @param ref A branch reference, passed to `git2r::checkout`'s `branch`
#'   parameter. Defaults to the trailing ref when a git path or url ends in a
#'   `remotes`-style reference string (eg `"prot://path.to.git@main"`), or
#'   `NULL` otherwise, using the existing ref of a local source or the the
#'   default ref (`"origin/HEAD"`) upon clone for a remote source.
#' @param subdir A relative file path to a package sub-directory within a
#'   repository.
#'
#' @rdname autovalidate
#'
#' @importFrom git2r clone checkout repository remote_url last_commit
#' @importFrom cli cli_text
#' @export
#'
autovalidate.git <- function(x = ".", ..., ref = NULL, subdir = ".",
                             quiet = options::opt("quiet"), metadata = list()) {
  if (grepl("\\.git@", x)) {
    ref <- gsub("^.*\\.git@", "", x)
    x <- gsub("\\.git@.*$", "\\.git", x) # strip ref
  }

  bn <- gsub("\\.git$", "", basename(x))
  destdir <- file.path(tempfile("autovalidateutils_"), bn)
  dir.create(destdir, recursive = TRUE)
  git2r::clone(x, local_path = destdir)
  repo <- git2r::repository(path = destdir)

  if (!is.null(ref) && startsWith(ref, "*tag")) {
    # filter tags using pattern defined as `*tag~=<regex>`
    tags <- git2r::tags(repo)
    tags <- tags[grepl(ref_tag_pattern(ref), names(tags), perl = TRUE)]

    if (!length(tags)) {
      stop(paste0("No matching tags for source: ", x))
    }

    # build ref using most recent matching tag
    tag_timestamps <- as.POSIXct(vapply(tags, git2r::when, character(1L)))
    ref <- tags[[which.max(tag_timestamps)]]
  }

  if (is.character(ref)) {
    git2r::checkout(repo, branch = ref)
  } else if (inherits(ref, "git_commit")) {
    git2r::checkout(ref)
  }

  metadata$repo_path <- destdir
  metadata$src_url <- sanitize_url(git2r::remote_url(destdir))
  metadata$checksum <- list(
    hash = git2r::last_commit(destdir)$sha,
    protocol = "SHA1"
  )

  if (!quiet) avu_cli(cli::cli_text("Extracted package source to '{destdir}'"))
  pkgdir <- normalize_path(file.path(destdir, subdir))
  autovalidate(pkgdir, ..., quiet = quiet, metadata = metadata)
}

#' @inheritParams options_params
#' @importFrom tools md5sum
#' @export
autovalidate.tar.gz <- function(
    x = ".", ..., quiet = options::opt("quiet"), libs = options::opt("libs"),
    metadata = list()) {

  bn <- gsub("\\.t(ar\\.)?gz$", "", basename(x))
  destdir <- file.path(tempfile("autovalidateutils_"), bn)

  split_path <- function(x) {
    if (dirname(x) %in% c(x, ".")) x else c(split_path(dirname(x)), basename(x))
  }

  # extract and install
  dir.create(destdir, recursive = TRUE)
  untar(x, exdir = destdir)
  paths <- untar(x, exdir = destdir, list = TRUE)
  pkg_path <- file.path(destdir, split_path(paths[[1L]])[[1L]])
  if (!quiet) avu_cli(cli::cli_text("Extracted package source to '{pkg_path}'"))

  # warn if a local file path is being used as source
  if (!"src_url" %in% names(metadata)) {
    warning(
      immediate. = TRUE,
      "No remote source url found, defaulting to local file uri. \n",
      "Please run against hosted tar archive urls that can be reproducibly ",
      "installed."
    )
  }

  # bundle tarball metadata
  pkg <- as.package(pkg_path)
  metadata$targz <- x
  metadata$src_url <-
    metadata$src_url %||% sprintf("file://%s", normalize_path(x))
  metadata$checksum <- list(hash = unname(tools::md5sum(x)), protocol = "md5")

  autovalidate(pkg, ..., quiet = quiet, metadata = metadata)
}

#' @export
autovalidate.tgz <- autovalidate.tar.gz


#' @describeIn autovalidate
#' Listing of all autovalidate steps
#'
#' [all_steps()] Returns a series of steps for evaluation with
#' [autovalidate()]. A named list of function names to execute as part of the
#' [autovalidate()] process.
#'
#' @section All Steps:
#'
#' All autovalidate steps include:
#'
#' ```{r, echo = FALSE, results = "asis"}
#' cat(mapply(
#'   sprintf,
#'   names(all_steps()),
#'   all_steps(),
#'   fmt = "1. %s ([%s()])\n"
#' ))
#' ```
#'
#' @export
#'
all_steps <- function() {
  list(
    "Recording version control metadata" = "write_version_control_yml",
    "Recording testing environment session metadata" = "write_session_info",
    "Recording DESCRIPTION file metadata" = "write_description_yml",
    "Recording NEWS file metadata" = "write_news_md",
    "Recording package's vulnerabilities" = "write_vulnerabilities_info",
    "Running R CMD check" = "write_r_cmd_check_yml",
    "Running tests & building traceability matrix" = "write_traceability_matrix", # nolint
    "Running checked" = "write_checked"
  )
}

#' @describeIn autovalidate
#' Retrieve list of steps to be executed
#'
#' @param modifications A `character` vector or `list` of step names or
#'   modifications to known steps. The vector or list must be all valid step
#'   names or modifications - these styles cannot be interspersed.
#'   Modifications are prefixed with a `-` (for example, `-write_checked`),
#'   and will remove this step from a list of all steps.
#'
#'
#' @export
#'
avu_steps <- function(modifications = options::opt("steps")) {
  steps <- all_steps()

  if (isTRUE(modifications) || is.null(modifications)) {
    return(steps)
  } else if (!is.character(modifications) && !is.list(modifications)) {
    stop("Not able to interpret autovalidateutils option 'steps'.")
  } else if (any(is_by_name <- !grepl("^(\\+|-)", modifications))) {
    # if a listing of all preferred steps, return as is
    if (!all(is_by_name)) {
      stop(
        "autovalidateutils option 'steps' must be either all named steps",
        "or all modifications of steps"
      )
    }

    return(modifications)
  } else if (any(i <- startsWith(modifications, "-"))) {
    # if modification starts with "-" prefix, subtract steps from defaults
    steps[!steps %in% gsub("^-", "", modifications[i])]
  }
}
