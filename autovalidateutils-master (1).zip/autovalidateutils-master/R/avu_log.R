#' Log to the autovalidateutils log file
#'
#' @param x A string or condition to emit to the log file
#' @inheritParams options_params
#' @inheritParams base::write
#'
avu_log <- function(
    x, output = options::opt("output"),
    file = options::opt("errors"), append = TRUE) {
  file <- avu_path(output, file)
  if (!dir.exists(dirname(file))) dir_create(dirname(file))
  write(format_autovalidate_message(x), file, append = append)
}



#' Simple helper for outputing messages in expected autovalidate
#' MessageRelayChecker format
#'
#' @param x An object to format into an `autovalidateutils` log entry
#'
format_autovalidate_message <- function(x) {
  UseMethod("format_autovalidate_message")
}

#' @export
format_autovalidate_message.NULL <- function(x) {
  NULL
}

#' @export
#' @importFrom yaml as.yaml
#' @export
format_autovalidate_message.character <- function(x) {
  yaml::as.yaml(list(list(name = "autovalidateutils", content = x)))
}

#' @export
#' @importFrom yaml as.yaml
#' @export
format_autovalidate_message.condition <- function(x) {
  yaml::as.yaml(list(list(name = "autovalidateutils", content = x$message)))
}

#' @export
#' @importFrom yaml as.yaml
#' @export
format_autovalidate_message.message <- function(x) {
  yaml::as.yaml(list(list(
    name = "autovalidateutils",
    severity = "WARNING",
    content = x$message
  )))
}

#' @export
#' @importFrom yaml as.yaml
#' @export
format_autovalidate_message.warning <- function(x) {
  yaml::as.yaml(list(list(
    name = "autovalidateutils",
    severity = "ERROR",
    content = x$message
  )))
}
