#' Write version control information out to a yaml file
#'
#' If possible, deduce a uniquely identifying hash of the source code.
#' Otherwise, use available precalculated hashes if provided.
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @param ... Passed to [write_git_yml] and [write_md5_checksum]
#'
#' @export
#'
write_version_control_yml <- function(
    x, output = options::opt("output"), quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), ...) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    output = output,
    log_output = log_output,
    quiet = quiet
  ))

  gitdata <- git_summary(x$repo_path %||% x$path)
  has_git_remote <- !is.null(gitdata) && !is.null(gitdata$url)

  avu_cli_task("Checking for reproducible source", {
    if (is.null(x$src_url)) {
      warning("No reproducible source of package code found")
    } else if (startsWith(x$src_url, "file://") && !has_git_remote) {
      message(
        "Installed from local source without version control.\n",
        "Instead, install from a reproducible remote source."
      )
    }
  })

  if (write_git_yml(x, gitdata = gitdata, ...)) {
    avu_cli_task("Checking version control: found git", {})
    return(TRUE)
  } else if (write_md5_checksum(x, ...)) {
    avu_cli_task("Checking version control: found tar.gz md5 checksum", {})
    return(TRUE)
  } else {
    avu_cli_task("Checking version control", {
      warning(
        "No valid version control found:\n",
        "Source must be a git repo with valid origin or tar.gz"
      )
    })
  }

  invisible(FALSE)
}

#' Write git repository information out to a yaml file
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams yaml::write_yaml
#' @inheritParams autovalidate
#' @param gitdata git_summary function output
#'
#' @importFrom yaml write_yaml
#'
#' @export
#'
write_git_yml <- function(
    x = ".", output = options::opt("output"),
    file = options::opt("version_control"), gitdata = NULL,
    log_output = options::opt("log_output"), ...) {
  file <- avu_path(output, file)
  x <- as.package(x)
  gitdata <- if (is.null(gitdata)) {
    git_summary(x$repo_path %||% x$path)
  } else {
    gitdata
  }

  if (!is.null(gitdata)) {
    yaml::write_yaml(gitdata, file)
    return(TRUE)
  } else {
    return(FALSE)
  }
}



#' Return a collection of information about a git repo
#'
#' @param path The path of the repository
#'
#' @importFrom git2r remote_url repository_head
#'   last_commit is_detached status workdir branch_get_upstream
#'   branch_remote_url
#'
git_summary <- function(path = ".") {
  # if directory is not a git repo, return empty list
  workdir <- tryCatch(git2r::workdir(path), error = function(i) NULL)
  if (is.null(workdir) || workdir != normalize_path(path)) {
    return(NULL)
  }

  url <- tryCatch({
    # try to get the upstream url of cloned repositories
    repo_head <- git2r::repository_head(path)
    branch_upstream <- git2r::branch_get_upstream(repo_head)
    git2r::branch_remote_url(branch_upstream)
  }, error = function(e) {
    # if branch has no upstream remote, use whatever remote is associated
    if (grepl("git2r_branch_get_upstream|git2r_branch_remote_url",
              e$message)) {
      # nolint
      git2r::remote_url(path)[[1L]]
    }
  })

  list(
    url = sanitize_url(url),
    branch = repo_head$name,
    checksum = list(
      protocol = "SHA1",
      hash = git2r::last_commit(path)$sha
    ),
    detached = git2r::is_detached(path),
    status = git2r::status(path)
  )
}



#' Sanitize a URL to ensure that it doesn't contain username and password parts
#'
#' @param url The url to sanitize
#'
#' @importFrom httr parse_url build_url
#'
sanitize_url <- function(url) {
  urlparts <- httr::parse_url(url)
  urlparts[c("username", "password")] <- NULL
  # remove protocol front matter if protocol wasn't defined
  gsub("^:///", "", httr::build_url(urlparts))
}

#' Write checksum information out to a yaml file
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams autovalidate
#' @param md5 An explicit md5 hash to write to file
#' @param url An explicit upstream url to write to file
#' @param file The file path into which to write version control metadata
#'
#' @importFrom yaml write_yaml
#'
#' @export
#'
write_md5_checksum <- function(
    x = ".", output = options::opt("output"),
    md5 = options::opt("version_control.md5"),
    url = options::opt("version_control.url"),
    file = options::opt("version_control"), ...) {
  x <- as.package(x)
  file <- avu_path(output, file)

  if (is.null(md5)) md5 <- x$checksum$hash
  if (is.null(url)) url <- x$src_url
  if (is.null(md5) || is.null(url)) {
    return(FALSE)
  }

  version_control_data <- list(
    url = url,
    checksum = list(protocol = "md5", hash = md5)
  )

  yaml::write_yaml(version_control_data, file)
  invisible(TRUE)
}
