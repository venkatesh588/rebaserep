#' callback management
#'
#' Set of wrapper around callbacks management. Callbacks in autovalidateutils
#' package are stored  as \code{callback} attributes to the objects.
#'
#' @param x - any R object with which callback should be associated
#' @param value - list that should be added as a callback to the object. If the
#' the object is a function it will be wrapped with a list.
#' @param fun - function to be appended as callback
#' or replace previous callbacks.
#' @rdname callback
avu_callback <- function(x) {
  attr(x, "callback", exact = TRUE)
}

#' @rdname callback
add_avu_callback <- function(x, fun) {
  stopifnot(is.function(fun))
  callback <- attr(x, "callback") %||% list()
  callback <- append(callback, list(fun))
  attr(x, "callback") <- callback
  x
}

#' @rdname callback
with_avu_callback <- function(x, value) {
  if (is.function(value)) value <- list(value)
  attr(x, "callback") <- value
  x
}
