#' Run R CMD check and write results out to a yaml file
#'
#' Run `R CMD check` and store output as a yaml-structured mapping of results.
#' Currently, all tests, examples and vignettes are executed, though this may
#' change in the future as the tests and examples are redundant with the
#' construction of a traceability matrix.
#'
#' @inheritParams options_params
#' @inheritParams yaml::write_yaml
#' @inheritParams autovalidate
#'
#' @importFrom yaml write_yaml
#' @export
#'
write_r_cmd_check_yml <- function(
    x = ".", output = options::opt("output"),
    file = options::opt("r_cmd_check"), check_dir = options::opt("check_dir"),
    errors = options::opt("errors"), quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), ...) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    output = output,
    log_output = log_output,
    quiet = quiet,
    # required for path helper functions
    check_dir = check_dir
  ))

  x <- as.package(x)

  # Run vignettes
  rendered_vignettes <- avu_build_vignettes(x)
  inst_doc <- file.path(x$path, "inst", "doc")
  if (length(rendered_vignettes) && !dir.exists(inst_doc)) {
    dir.create(inst_doc, recursive = TRUE)
  }

  for (f in rendered_vignettes) {
    dest <- file.path(inst_doc, basename(f))
    if (!file.exists(dest)) file.copy(f, dest)
  }

  # Run R CMD Check
  file <- avu_path(output, file)
  r_cmd_check <- avu_r_cmd_check(
    x,
    output = output,
    check_dir = check_dir,
    quiet = quiet
  )

  # interpret results and export diagnostic info to console
  avu_cli_task("Checking {.code R CMD check} results", quiet = quiet, {
    for (e in r_cmd_check$errors) {
      warning(e)
    }
    for (w in r_cmd_check$warnings) {
      warning(w)
    }
    for (n in r_cmd_check$notes) {
      warning(n)
    }
  })

  # Store R CMD check tests result as env variable so they could be used in
  # coverage job
  Sys.setenv("AUTOVALIDATEUTILS_R_CHECK_TESTS_FAILURE" = length(r_cmd_check$test_fail) > 0) # nolint

  yaml::write_yaml(r_cmd_check, file)

  invisible(with_avu_callback(TRUE, avu_callback(r_cmd_check)))
}



#' Run R CMD check and return a simplified output
#'
#' @inheritParams as.package
#' @inheritParams options_params
#'
#' @importFrom rcmdcheck rcmdcheck
#' @importFrom withr with_envvar
#' @importFrom cli ansi_strip
#'
avu_r_cmd_check <- function(
    x, output = options::opt("output"),
    check_dir = options::opt("check_dir"),
    quiet = options::opt("quiet")) {

  x <- as.package(x)
  check_dir_path <- avu_path(output, check_dir)

  build_args <- c("--no-build-vignettes", "--no-manual")
  check_args <- c("--timings", "--ignore-vignettes", "--no-manual")
  if (options::opt("build_binaries")) {
    check_args <- c(check_args, "--install-args=--build")
  }

  msg <- sprintf(
    "Running {.code R CMD check %s}",
    paste0(collapse = " ", setdiff(check_args, "--timings"))
  )

  avu_cli_task(msg, {
    withr::with_envvar(
      prepare_r_cmd_check_variables(),
      action = "replace",
      {
        r_cmd_check <- rcmdcheck::rcmdcheck(
          x$path,
          check_dir = check_dir_path,
          quiet = TRUE,
          build_args = build_args,
          args = check_args,
          error_on = "never"
        )
      }
    )
  })

  is_atomic <- vapply(r_cmd_check, is.atomic, logical(1L))
  is_list <- vapply(r_cmd_check, is.list, logical(1L))

  r_cmd_check <- r_cmd_check[is_atomic | is_list]

  # strip coloring as ESC sign (also known as \e or \033) used to indicate
  # start of the colored string cannot be rendered by markdown and crashes it.
  # By default rcmdcheck should strip it for us but in some cases it could go
  # through hence we need to remove it as a safety fuse.

  r_cmd_check$stdout <- cli::ansi_strip(r_cmd_check$stdout)
  r_cmd_check$install_out <- cli::ansi_strip(r_cmd_check$install_out)

  # exclude metadata that is captured and formatted by autovalidate functions
  to_exclude <- c("description")
  r_cmd_check <- r_cmd_check[!names(r_cmd_check) %in% to_exclude]

  # coerce some vector values to lists when they should assuredly be list-like
  # otherwise atomic vector values will not be lists when written to yml.
  # At the same time strip ESC signs for the same reason mentioned before.
  to_list <- c("errors", "warnings", "notes")
  r_cmd_check[to_list] <- lapply(r_cmd_check[to_list], function(x) {
    as.list(cli::ansi_strip(x))
  })

  # Generalize sources_names if option was set
  if (options::opt("generalize_sources")) {
    generalize_sources_names(x, check_dir_path)
    sources_to_unlink <- sources_internal_names(x, check_dir_path)
    r_cmd_check <- add_avu_callback(
      r_cmd_check,
      function() {
        unlink(
          sources_to_unlink,
          force = TRUE,
          recursive = TRUE
        )
      }
    )
  }

  # Unlink redundant file to lower the size of artifacts
  r_cmd_check <- add_avu_callback(
    r_cmd_check,
    function() {
      files_to_unlink <- c(
        # Untarred source
        file.path(check_dir_path, paste0(x$package, ".Rcheck"), "00_pkg_src"),
        # Installed package
        file.path(check_dir_path, paste0(x$package, ".Rcheck"), x$package),
        # Tests cases
        if (options::opt("r_cmd_check_clean_tests")) {
          list.dirs(
            file.path(check_dir_path, paste0(x$package, ".Rcheck"), "tests"),
            recursive = FALSE,
            full.names = TRUE
          )
        }
      )

      unlink(
        files_to_unlink,
        force = TRUE,
        recursive = TRUE
      )

      writeLines(
        c(
          "Directories removed when cleaning up the output: ",
          files_to_unlink
        ),
        file.path(
          check_dir_path,
          paste0(x$package, ".Rcheck"),
          "cleaning_up.log"
        )
      )
    }
  )


  invisible(r_cmd_check)
}

prepare_r_cmd_check_variables <- function() {
  r_cmd_check_variables <- options::opt("r_cmd_check_variables")
  if (identical(r_cmd_check_variables, "internal")) {
    c(
      "_R_CHECK_FORCE_SUGGESTS_" = FALSE,
      "_R_CHECK_RD_XREFS_" = FALSE,
      "_R_CHECK_SYSTEM_CLOCK_" = FALSE
    )
  } else if (identical(r_cmd_check_variables, "cran")) {
    c(
      "_R_CHECK_FORCE_SUGGESTS_" = FALSE,
      "_R_CHECK_RD_XREFS_" = FALSE,
      "_R_CHECK_PKG_SIZES_" = FALSE,
      "_R_CHECK_SYSTEM_CLOCK_" = FALSE
    )
  } else {
    r_cmd_check_variables
  }
}

#' Run tools::buildVignettes
#'
#' This function is called for its side effects, which are captured and
#' displayed as \code{avu_cli_task} output. The code is heavily inspired by
#' \code{covr:::run_vignettes}, which runs the vignette building through \code{R
#' CMD BATCH}, as a means of capturing an exit status to indicate whether the
#' build was successful.
#'
#' @inheritParams as.package
#' @importFrom tools buildVignettes pkgVignettes
#'
avu_build_vignettes <- function(x) {
  x <- as.package(x)

  avu_cli_task("Running {.code tools::buildVignettes}", {
    # code largely inspired by covr:::run_vignettes
    build_vign_script <- tempfile(paste0(x$package, "-build-vignettes.R"))
    out_file <- tempfile(paste0(x$package, "-vignette.Rout"))

    cat(
      deparse(bquote(.libPaths(.(.libPaths())))),
      deparse(bquote(tools::buildVignettes(dir = .(x$path)))),
      file = build_vign_script,
      sep = "\n"
    )

    cmd <- paste(
      shQuote(file.path(R.home("bin"), "R")),
      "CMD BATCH --quiet --vanilla --no-timing",
      shQuote(build_vign_script),
      shQuote(out_file)
    )

    rendered_vignettes <- character(0L)
    exit_status <- system(cmd)
    if (exit_status != 0) {
      msg <- paste(collapse = "\n", c(
        "Errors encountered while building vignettes",
        readLines(out_file)[-1]
      ))
      message(msg)
    } else {
      vignettes <- tools::pkgVignettes(dir = x$path, output = TRUE)
      rendered_vignettes <- vignettes$outputs
    }
  })

  rendered_vignettes
}

#' Generalize sources names
#'
#' Sources and binaries produced during R CMD check execution have
#' package and system specific names that are not controllable by any
#' variables making it difficult to use them in an actual production pipeline.
#' The function recreates internal R logic of producing those names and
#' renames matched files to generalized names. \code{sources_internal_names}
#' is a helper that generates default internal R names
#'
#' @param x - package object
#' @param path - rcmdcheck check_dir path
generalize_sources_names <- function(x, path) {
  default_names <- sources_internal_names(x, path)
  binary_filename <- default_names$binary
  source_filename <- default_names$source

  if (options::opt("build_binaries")) {
    file.copy(
      binary_filename,
      file.path(
        path,
        paste0("package_binary.", tools::file_ext(binary_filename))
      )
    )
  }

  file.copy(
    source_filename,
    file.path(path, "package_source.tar.gz")
  )

  invisible(TRUE)
}



#' @rdname generalize_sources_names
sources_internal_names <- function(x, path) {
  version <- x$version
  pkg_name <- x$package

  on_windows <- .Platform$OS.type == "windows"
  on_macos <- grepl("darwin", R.version$os)

  os <- if (on_windows) {
    "windows"
  } else if (on_macos) {
    "macos"
  } else {
    "unix"
  }

  binary_filename <- switch(os,
    windows = paste0(pkg_name, "_", version, ".zip"),
    macos = paste0(pkg_name, "_", version, ".tgz"),
    paste0(pkg_name, "_", version, "_R_", Sys.getenv("R_PLATFORM"), ".tar.gz")
  )

  source_filename <- paste0(pkg_name, "_", version, ".tar.gz")

  list(
    source = file.path(path, source_filename),
    binary = file.path(path, binary_filename)
  )
}

#' @rdname generalize_sources_names
get_check_tarball_path <- function(x) {
  path <- file.path(options::opt("output"), options::opt("check_dir"))
  if (options::opt("generalize_sources")) {
    file.path(path, "package_source.tar.gz")
  } else {
    sources_internal_names(x, path)[["source"]]
  }
}
