`%||%` <- function(x, y) {
  if (!is.null(x)) {
    x
  } else {
    y
  }
}



#' A simple alternative to `devtools::as.package`
#'
#' Functionally identical to `devtools`' `as.package`, but without interactive
#' options for package creation.
#'
#' @note Code inspired by `devtools` `load_pkg_description` with very minor
#' edits to further reduce `devtools` dependencies.
#'
#' @param x A package object to coerce
#'
as.package <- function(x) {
  if (inherits(x, "package")) {
    return(x)
  }
  info <- read.dcf(file.path(x, "DESCRIPTION"))[1L, ]
  Encoding(info) <- "UTF-8"
  desc <- as.list(info)
  names(desc) <- tolower(names(desc))
  desc$path <- x
  structure(desc, class = "package")
}



#' Partially from `devtools::uses_testthat`
#'
#' The only devtools-specific function needed, and does not in-and-of-itself
#' warrant the additional overhead of including the dependency. The content of
#' the function was copied from the devtools package and the additional test
#' whether testthat file contain any .R files was added at the and.
#'
#' @inheritParams as.package
#'
uses_testthat <- function(x = ".") {
  x <- as.package(x)

  paths <- c(
    file.path(x$path, "inst", "tests"),
    file.path(x$path, "tests", "testthat")
  )

  # If directories in paths would not exists
  # then list.files would return character(0) (same as it were empty)
  # so we don't have to check if those directories exist.
  dir_contains_r_scripts <- vapply(paths, function(p) {
    length(list.files(p, pattern = "\\.[Rr]$")) > 0
  }, FUN.VALUE = logical(1))

  any(dir_contains_r_scripts)
}



#' Wrapper around `base::normalizePath`
#'
#' A forward slash separator is hard-coded for Windows so the file path format
#' is compatible with modern packages such as \code{git2r}.
#'
#' @details See
#'   \href{https://github.com/r-lib/covr/blob/deba93819d2b39c7016c365f7df1669d444c9e05/R/utils.R#L315-L319}{utils.R#L315-319} # nolint
#'    in the \code{covr} package for another use-case.
#'
#' @inheritParams base::normalizePath
#'
normalize_path <- function(path, mustWork = TRUE) {
  normalizePath(
    # Strip any trailing slashes as they are invalid on windows
    gsub("/*$", "", path),
    winslash = "/",
    mustWork = mustWork
  )
}



#' Test whether a file path is absolute
#'
#' @details Inspired by `fs`'s `is_absolute_path`
#'
#' @param path A character vector of file paths
#'
is_path_absolute <- function(path) {
  grepl("^~", path) | grepl("^(/+|[A-Za-z]:)", path)
}


#' A helper to create a directory or the parent directory of a file path
#'
#' @param path A file or directory path
#' @inheritParams base::dir.create
#'
dir_create <- function(path, recursive = TRUE) {
  if (!dir.exists(path)) dir.create(path, recursive = recursive)
}



#' A wrapper around `base::unlink`
#'
#' Sometimes directories won't be deleted on Windows because of permission
#' issues. This usually doesn't cause errors but will cause a warning if the
#' directory is created again. This wrapper hard-codes \code{force = TRUE} to
#' get around this.
#'
#' @inheritParams base::unlink
#'
unlink_dir <- function(x) {
  unlink(x, recursive = TRUE, force = TRUE)
}


#' Pad a string to a given length
#'
#' @param x A string to pad
#' @param n The number of characters that the string should be padded to
#' @param char The character to use for padding
#'
lpadstr <- function(x, n, char = " ") {
  paste0(strrep(char, pmax(n - nchar(x), 0)), x)
}


#' Check if URL is available
#'
#' Pings the URL and checks whether the resources are available
#'
#' @param url character url
is_url_available <- function(url) {
  ping_code <- tryCatch(
    httr::HEAD(url)$status_code,
    error = function(e) 408 # timeout
  )

  ping_code < 400
}

#' Convert markdown headers to hash-style
#'
#' This is a copy of the helper function from rd2markdown package
#'
#' @param md A markdown-formatted character value or vector to convert.
#'
#' @keywords internal
#'
convert_markdown_headers_to_hash <- function(md) {
  md <- gsub(
    "(?m)(^|\n)([^\n]*)\\s*\n\\s{0,3}---+(\\s*\n|$)",
    "\\1# \\2\\3", md, perl = TRUE
  )
  md <- gsub(
    "(?m)(^|\n)([^\n]*)\\s*\n\\s{0,3}===+(\\s*\n|$)",
    "\\1## \\2\\3", md, perl = TRUE
  )
  md
}


#' Escape special characters
#'
#' The function takes the character string and escapes all unicode and markdown
#' special characters.
#'
#' @param text character text
#'
#' @keywords internal
escape_special <- function(text) {
  # regex special chars escaped with \\
  markdown_chars <- c(
    "\\{", "\\(", "\\[", "<",
    "\\}", "\\)", "\\]", ">",
    "\\|", "\\*",
    "\`", "_", "#", "~"
  )

  regexp <- paste0("(", paste0(markdown_chars, collapse = "|"), ")")

  # escape special unicode characters, as well as markdown-specific characters
  gsub(regexp, "\\\\\\1", stringi::stri_escape_unicode(text))
}

#' Loading unexported helpers from testthat
#'
.testthat <- as.list(getNamespace("testthat"), all.names = TRUE)[c(
  "classnameOK"
)]

#' Loading unexported helpers from tools
#'
.tools <- as.list(getNamespace("tools"), all.names = TRUE)[c(
  ".split_dependencies"
)]

#' Check if testthat identifies cran environment
#'
#' Checks NOT_CRAN env variable used by testthat internals to derive
#' whether CRAN specific tests should be skipped and returns TRUE
#' if theses tests would've been skipped.
testthat_is_on_cran <- function() {
  tryCatch(
    {
      testthat::skip_on_cran()
      FALSE
    },
    skip = function(e) TRUE,
    error = function(e) {
      message("testthat::skip_on_cran function in not avaialble")
      FALSE
    }
  )
}

#' Check if testthat identifies CI environment
#'
#' Checks CI env variable used by testthat internals to derive
#' whether CI specific tests should be skipped and returns TRUE
#' if theses tests would've been skipped.
testthat_is_on_ci <- function() {
  tryCatch(
    {
      testthat::skip_on_ci()
      FALSE
    },
    skip = function(e) TRUE,
    error = function(e) {
      message("testthat::skip_on_ci function in not avaialble")
      FALSE
    }
  )
}

#' Copy loaded version of a package to the minimal library
#'
#' This function copies loaded version of the package into a temporary library
#' if it cannot be satisfied by a lib.loc
#'
#' @param package A name of the package which loaded version should be copied to
#'   lib if version in lib.loc does not satisfy requirements.
#' @param lib library to which appropriate version of the package should be
#'   copied if necessery.
#' @param lib.loc A \code{character} vector of library locations to consider
#'   when searching for permissible satisfying library locations.
#' @param original_libpaths A character vecotr of original .libPaths() values
#'   before they were changed in avu_install
#'
#' @return A logical value indicating whether a package was sym linked to lib
package_to_lib <- function(
    package,
    lib,
    lib.loc = .libPaths(),
    original_libpaths = options::opt("original_libpaths")) {
  # loadedversion will satisfy autovalidateutils dependencies, regardless
  # of whether it's available in lib.loc
  # If the package is not loaded, always copy the version form original libpaths

  loaded_pkg_ver <- try(packageVersion(package), silent = TRUE)
  if (!inherits(loaded_pkg_ver, "try-error")) {
    loaded_pkg_path <- find.package(package)

    # discover covr versions available in lib.loc
    lib_pkg_vers_strs <- try(
      installed.packages(lib.loc = lib.loc)[package, "Version"],
      silent = TRUE
    )

    lib_pkg_get_loaded <- if (inherits(lib_pkg_vers_strs, "try-error")) {
      FALSE
    } else {
      lib_pkg_vers <- lapply(lib_pkg_vers_strs, package_version)
      lib_pkg_get_loaded <- vapply(
        lib_pkg_vers, `>=`, logical(1L),
        loaded_pkg_ver
      )
    }
  } else {
    lib_pkg_get_loaded <- FALSE
    ip_org <- installed.packages(lib.loc = original_libpaths)
    # [[1]] at the end ensures that only one path is passed in case
    # of multiple installations
    loaded_pkg_path <- try(
      paste0(ip_org[package, "LibPath"][[1]], "/", package),
      silent = TRUE
    )
  }


  if (inherits(loaded_pkg_path, "try-error")) {
    # package does not exists
    FALSE
  } else if (any(lib_pkg_get_loaded)) {
    # if lib.loc already satisfy covr needs, don't create a new library
    FALSE
  } else if (!dir.exists(file.path(lib, basename(loaded_pkg_path)))) {
    file.symlink(loaded_pkg_path, file.path(lib, basename(loaded_pkg_path)))
    TRUE
  } else {
    TRUE
  }
}

#' Create a temporary library containing only a satisfactory version of the
#' package
#'
#' This function copies this recent version of the package into a temporary
#' library such that it can impose minimal additions to the testing environment.
#'
#' @inheritParams package_to_lib
#'
#' @return A \code{character} value containing a new, temporary library path to
#'   a library containing only \code{package} if the provided \code{lib.loc}
#'   paths do not satisfy the \code{package} dependency, or an empty
#'   \code{character} vector otherwise.
#'
package_library <- function(package, lib.loc = .libPaths()) {
  tmp_lib <- tempfile(paste(package, "_lib_", sep = ""))
  dir.create(tmp_lib)

  if (package_to_lib(package, tmp_lib, lib.loc)) {
    tmp_lib
  } else {
    character()
  }
}

#' Expand a regular expression version class
#'
#' Expand a POSIX-class-like regular expression shorthand. Unlike POSIX classes
#' like `[:digit:]` or `[:alpha:]`, which are character classes, `[:version:]`
#' deviates slightly by representing a sub-expression from
#' `.standard_regexps()`.
#'
#' @param re A regular expression, possibly containing a `[:version:]` class.
#'
#' @return A regular expression with `[:version:]` replaced with the R standard
#'   regular expression for any valid package version number.
#'
expand_regex_version_class <- function(re) {
  std_re <- .standard_regexps()
  gsub("\\[:version:\\]", std_re$valid_package_version, re)
}

#' Convert a `*tag` ref to a suitable matching expression
#'
#' @param ref A character value representing a repository reference, assumes
#'   beginning with `*tag`.
#'
#' @return A regular expression used for filtering tags. If no pattern is
#'   provided, a regular expression is returned to match all tags.
#'
ref_tag_pattern <- function(ref) {
  pattern <- ".*"
  if (startsWith(ref, "*tag=~")) {
    pattern <- expand_regex_version_class(substring(ref, 7))
  }
  paste0("^", pattern, "$")
}

#' Code Backticks
#'
#' Format the text as code by adding appropriate number of backticks surrounding
#' the text. The number of backticks added is the maximum number of consecutive
#' backticks used in text + 1 ti ensure markdown will render it properly.
#' Function is vectorized
#'
#' @param text character vector
code_backticks <- function(text) {
  vapply(text, function(x) {
    max_cons_backticks <- max(
      nchar(strsplit(gsub("[^`]+", " ", x), "\\s+")[[1]])
    )
    sprintf(
      "%2$s %1$s %2$s",
      x,
      strrep("`", max_cons_backticks + 1)
    )
  }, FUN.VALUE = character(1), USE.NAMES = FALSE)
}

#' bquote deparse paste wrapper
#'
#' A wrapper around \code{deparse(bquote(...))} that also pastes lines
#' creating a multiline chunk of code that is 1L length string and
#' could be easily written to the file or passed r covr.
#'
#' @param ... A languauge object
#' @inheritParams base::bquote
bquote_deparse_paste <- function(..., where = parent.frame()) {
  paste0(collapse = "\n", deparse(bquote(..., where = where)))
}

#' Options negative
#'
#' Return list of options with names passed in opts excluded. It could be
#' seen as a negative of the original options output
#'
#' @param opts character vector of options to exclude from the original options
#' output
options_negative <- function(opts) {
  options <- options()
  options[!names(options) %in% opts]
}

#' Remove duplicate available.packages filters
#'
#' Updated version of the internal tools:::.remove_stale_dups
#' which is function used by the default "duplicates" filters. autovalidateutils
#' version of the filter will pick first repo on the list, but among all
#' packages available within this repo, including archives, the latest version
#' of the package will be chosen. This is to avoid situation when archive
#' duplicates are available within the repo and appear on the list before the
#' actual version of the package.
#'
#' @param ap available.packages matrix
avu_remove_duplicates <- function(ap) {
  pkgs <- ap[, "Package"]
  dup_pkgs <- pkgs[duplicated(pkgs)]
  stale_dups <- integer(length(dup_pkgs))
  i <- 1L
  for (dp in dup_pkgs) {
    wh <- which(dp == pkgs)
    repos <- ap[wh, "Repository"]
    # Remove "/Older" from the end of the repository
    # "/Older" in not a natural part of the repo URL,
    # it is added by the PACKAGES.rds manifest to include
    # potential duplicates in the Archive. We need to remove
    # this so we can accurately choose first repository on the list,
    # but within one repository the latest version of the pacakge.
    # ie. we want to avoid when we just choose first entry and this
    # happens to be archived version still kept in the loop
    repos <- gsub("/Older$", "", repos)
    vers <- package_version(ap[wh, "Version"])

    # Consider only packages provided by the first repository
    # on the list.
    keep_ver <- max(vers[repos == repos[1]])
    keep_idx <- which.max(vers == keep_ver)
    wh <- wh[-keep_idx]
    end_i <- i + length(wh) - 1L
    stale_dups[i:end_i] <- wh
    i <- end_i + 1L
  }
  if (length(stale_dups)) {
    ap[-stale_dups, , drop = FALSE]
  } else {
    ap
  }
}

#' Remove non utf8 signs from the file
#'
#' Remove all the non utf8 signs form the file. Function at first rads the file,
#' then enforce encoding and finally saves it again to the same location.
#'
#' @param file Path to the file from which non-ut8 signs should be removed.
remove_non_utf8_from_file <- function(file) {
  text <- readLines(file)
  text <- iconv(text, "UTF-8", "UTF-8", sub = "?")
  writeLines(text, file)
}


#' autovalidateutils isolated process
#'
#' Runs the child process using the `callr` function. The said process
#' is configured to address various validation needs and potential issues
#' coming from the nature of the autovaldiateutils and dependencies
#' structures.
#'
#' @param callr_f callr package function which starts the separate process
#' @param f user provided custom function which should be run in the
#'   already configured process
#' @param args named list of arguments which will be supplied to f
#'   with `do.call`
#' @param ... extra arguments passed to [callr::r()] and [processx::run()]
#' @inheritParams callr::r
avu_isolated_process <- function(
    callr_f, f, args, system_profile = FALSE,
    user_profile = FALSE, repos = "", env = c("R_PROFILE" = ""), ...) {
  callr_f(
    # nocov start
    function(f, args, opts, callr_version) {
      # callr pre 3.7.0 disallows changing R env related sys variables
      # using env parameter in the callr:r(). Therefore for older version
      # of callr we have to do it manually
      if (callr_version < "3.7.0") {
        Sys.unsetenv(
          c(
            # List taken from the callr/R/setup.R
            "R_ENVIRON",
            "R_ENVIRON_USER",
            "R_PROFILE",
            "R_PROFILE_USER",
            "R_LIBS",
            "R_LIBS_USER",
            "R_LIBS_SITE"
          )
        )
      }
      do.call(options, opts)

      do.call(f, args)
      # nocov end
    },
    args = list(
      f = f,
      args = args,
      # we don't want to pass repos option as it is handled by the
      # repos parameter
      opts = options_negative("repos"),
      callr_version = packageVersion("callr")
    ),
    system_profile = system_profile,
    user_profile = user_profile,
    repos = repos,
    # Regardless of options, install.packages always run .Rprofile
    # which could alter libPaths and result with wrong dependencies
    # being picked up and ultimately prevent installation. Hence
    # the default `env = c("R_PROFILE" = "")`
    env = env,
    ...
  )
}

#' Normalize text
#'
#' Attempt to normalize the text by escaping ANSI escape codes. Currently
#' replaces all octal characters between 001 and 010 with "?" and removes
#' console coloring with cli::ansi_strip().
#'
#' @param text text_to be normalized
#'
#' @importFrom cli ansi_strip
normalize_text <- function(text) {
  text <- gsub("[\001-\010]", "?", text)
  cli::ansi_strip(text)
}

#' Dependencies Satisfiability
#'
#' A helper function to generate a data.frame of satisfiable (available and
#' permitted to be installed) dependencies.
#'
#' @inheritParams get_package_dependencies
#' @inheritParams utils::available.packages
#' @inheritParams options_params
#'
dependencies_satisfiability <- function(
    x,
    req_deps = options::opt("req_deps"),
    inst_deps = options::opt("inst_deps"),
    lib.loc = options::opt("lib.loc"),
    repos = getOption("repos", NULL)) {
  # check for dependencies of dependency types that must already be installed
  if (is.null(lib.loc)) {
    lib.loc <- character(0L)
  }

  inst <- installed.packages(lib.loc = lib.loc)
  avail <- available.packages(repos = repos, ignore_repo_cache = TRUE)

  # gather dependencies for R filtering out R itself and dependecies
  # that are not required
  deps <- get_package_dependencies(x, repos)
  deps <- deps[deps$package != "R" & deps$type %in% req_deps, ]

  # process existing version strings into "op" (eg >=) and "version"
  deps$op <- gsub("[^>=<]", "", deps$version)
  deps$version <- gsub("([>=<])|(\\*)|(\\s*)", "", deps$version)

  # add installed and available package versions for assessment
  deps_rows_inst <- match(deps$package, inst[, "Package"])
  deps_rows_avail <- match(deps$package, avail[, "Package"])
  deps$installed <- inst[deps_rows_inst, "Version"]
  deps$libpath <- inst[deps_rows_inst, "LibPath"]
  deps$available <- avail[deps_rows_avail, "Version"]

  # Set availability to NA if the package is not permitted to be installed
  deps$available[!deps$type %in% inst_deps] <- NA

  # derive dependency satisfiability
  deps$satisfiable <- mapply(function(op, version, installed, available) {
    if (nchar(op)) {
      # We are doing it right now rather than upon creation of deps df
      # to avoid unnecessary conversions when dependecy is clearly
      # unavailable. Additionally it saves a lot of overhead with processing
      # later on
      installed <- package_version(installed, strict = FALSE)
      available <- package_version(available, strict = FALSE)
      version <- package_version(version, strict = FALSE)

      isTRUE(get(op)(installed, version) || get(op)(available, version))
    } else {
      !(is.na(installed) && is.na(available))
    }
  }, deps$op, deps$version, deps$installed, deps$available)

  deps
}

#' Get package deps
#'
#' Get package dependencies by inspecting matrix returned by available.packages
#' or read.dcf.
#'
#' @param x - character, either package object or package's name. If `x`
#' inherits from `package` class, then `DESCRIPTION` file is used to read
#' dependencies. Otherwise, `x` is treated as the package name and dependencies
#' are fetched using `utils::available.packages`.
#' @inheritParams utils::available.packages
get_package_dependencies <- function(x, repos = NULL) {
  drlapply <- function(...) {
    do.call(rbind, lapply(...))
  }

  desc <- if (inherits(x, "package")) {
    read.dcf(file.path(x$path, "DESCRIPTION"))
  } else {
    available.packages(repos = repos)[x, , drop = FALSE]
  }

  drlapply(c(DEP_LIB_CORE, DEP_LIB_OPTIONAL), function(dep) {
    if (!dep %in% colnames(desc) || is.na(desc[, dep])) {
      data.frame(
        type = character(0),
        package = character(0),
        version = character(0)
      )
    } else {
      deps_split <- .tools$.split_dependencies(desc[, dep])
      drlapply(deps_split, function(d) {
        ver <- if (is.null(d$op)) {
          "*"
        } else {
          paste0(d$op, " ", d$version)
        }

        data.frame(
          type = dep,
          package = d$name,
          version = ver
        )
      })
    }
  })
}

#' Combine path components into a file path
#'
#' If any path element is itself an absolute path, previous elements are ignored
#' and the last absolute path is used as the root for future path elements.
#'
#' @param ... \code{character(1L)} elements of a path. Relative elements are
#'   concatenated, but will be masked by any absolute path.
#'
avu_path <- function(...) {
  elements <- list(...)
  last_abs <- Position(is_path_absolute, elements, nomatch = 1L, right = TRUE)
  do.call(file.path, elements[last_abs:length(elements)])
}

#' Check if package is installed
#'
#' Function checks if a package is installed in the given lib.loc. Function
#' uses base's find.package to check installation status without loading the
#' package.
#'
#' @param pkg package name
#' @inheritParams base::find.package
is_package_installed <- function(pkg, lib.loc) {  # nolint object_name_linter
  path <- find.package(pkg, lib.loc = lib.loc, quiet = TRUE)
  length(path) > 0
}
