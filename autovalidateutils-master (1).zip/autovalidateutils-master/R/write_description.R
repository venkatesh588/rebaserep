#' Write an R package description out to a yaml file
#'
#' R package DESCRIPTION metadata is converted into a yaml format and written
#' out as a metadata file for use in `autovalidate`. The "Authors@R" field is
#' parsed and evaluated and used to populate the "Authors" and "Maintainer"
#' fields if not otherwise provided. Dependencies are separated into a list.
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams yaml::write_yaml
#' @inheritParams autovalidate
#'
#' @importFrom yaml write_yaml
#'
#' @export
#'
write_description_yml <- function(
    x = ".", output = options::opt("output"),
    file = options::opt("description"), quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), ...) {

  withr::local_options(options::opts_list(
    output = output
  ))

  file <- avu_path(output, file)

  yaml::write_yaml(avu_description(
    x = x,
    quiet = quiet,
    log_output = log_output
  ), file = file)

  invisible(TRUE)
}



#' Extract DESCRIPTION data and convert to native R data structure
#'
#' @inheritParams as.package
#' @inheritParams options_params
#'
avu_description <- function(
    x = ".", quiet = options::opt("quiet"),
    log_output = options::opt("log_output")) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    log_output = log_output,
    quiet = quiet
  ))

  x <- as.package(x)

  desc <- as.list(as.data.frame(
    read.dcf(file.path(x$path, "DESCRIPTION")),
    stringsAsFactors = FALSE
  ))

  # split any fields that can be lists of strings
  fields <- c(
    "Depends",
    "Imports",
    "Suggests",
    "Enhances",
    "LinkingTo",
    "Remotes"
  )
  avu_cli_task("Parsing DESCRIPTION dependency fields", {
    for (field in intersect(fields, names(desc))) {
      desc[[field]] <- as.list(do.call(c, strsplit(desc[[field]], "\\s*,\\s*")))
    }
  })

  # process Authors@R and standardize on plain text fields
  avu_cli_task("Processing DESCRIPTION Authors", {
    if ("Authors@R" %in% names(desc)) {
      authors <- eval(parse(text = desc[["Authors@R"]]))

      if (!"Authors" %in% names(desc)) {
        desc$Authors <- paste(as.character(authors), collapse = ", ")
      }

      if (!"Maintainer" %in% names(desc)) {
        desc$Maintainer <- as.character(
          Find(function(i) "cre" %in% i$role, authors)
        )
      }
    }

    if (any(grepl("YOUR-ORCID-ID", desc$Authors))) {
      warning("Found placeholder names in Authors")
    }
  })

  invisible(desc)
}
