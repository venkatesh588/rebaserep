DEP_LIB_CORE <- c("Depends", "Imports", "LinkingTo")
DEP_LIB_OPTIONAL <- c("Suggests", "Enhances")

#' Manage the installation of a package and its dependencies
#'
#' For validated package installation, it is important that we don't
#' accidentally install dependent packages into a library representing a cohort
#' of validated packages without first ensuring that they have gone through
#' appropriate validation procedures. To address this, we install dependencies
#' into separate library directories by dependency type, or completely ignore
#' certain types of dependencies if we would prefer that the package fail to
#' install if those dependencies are not already present. Any packages installed
#' outside of \code{lib.loc} (defaulting to the site and user default library
#' directories) will be reinstalled from available repositories, and the newly
#' installed versions of those packages will be used for testing.
#'
#' Only for `"Suggests"` dependencies, failure to install dependencies is
#' permitted, as some packages will suggest packages that are not available
#' through typical package distribution channels - often for the purpose of
#' including large datasets which would otherwise be rejected from common
#' package repositories. The lack of these `"Suggests"` dependencies may cause
#' tests to be skipped or fail, which would prompt more granular review of the
#' validation failure modes.
#'
#' @inheritParams autovalidate
#' @param libs A `list` of library directories. The first value is used as the
#'   installation target for package `x`, and its dependencies are installed to
#'   libraries indicated by corresponding named entries in `libs`. For more
#'   details see the `avu_initialize_libs` documentation.
#' @inheritParams remotes::install_local
#' @inheritParams check_dependencies_satisfiability
#' @inheritParams options_params
#'
#' @importFrom remotes dev_package_deps install_local
#'
avu_install <- function(
    x = ".", libs = avu_initialize_libs(),
    dependencies = options::opt("inst_deps"),
    upgrade = options::opt("upgrade_deps"),
    quiet = options::opt("quiet"), ..., lib.loc = options::opt("lib.loc"),
    repos = getOption("repos"), log_output = options::opt("log_output")) {

  options(options::opts_list(
    original_libpaths = .libPaths()
  ))

  # prioritize new validation libraries then default libraries as.character is
  # equivalent to unlist(use.names = FALSE) here
  install_libpaths <- as.character(c(libs, lib.loc))

  # After installing all validation libraries, we have to add
  # avu libraries back to the libPaths as all validation libraries
  # were already installed and prioritized
  # This is mostly for the purpose of maintaining avu libraries
  avu_libpaths <- unique(as.character(c(libs, .libPaths(), lib.loc)))

  # Create log directory
  dir_create(options::opt("log_output"))

  .libPaths(install_libpaths)

  # upon return from avu_install, add back in any user libraries
  on.exit(.libPaths(avu_libpaths), add = TRUE, after = FALSE)

  # temporarily set environment variable "CI" to unset, as this causes `remotes`
  # to hit rate limit with its embedded github token (see: remotes:::github_pat)
  envvar_ci_orig <- Sys.getenv("CI")
  Sys.setenv(CI = "")
  on.exit(Sys.setenv(CI = envvar_ci_orig), add = TRUE, after = FALSE)

  # Ensure that dependencies will be processed in an appropriate order.
  installation_order <- options::opt("installation_order")
  dependencies <- avu_discover_dependencies_types(
    dependencies,
    installation_order
  )

  # coerce any file paths to a package object
  x <- as.package(x)

  # check that dependencies are installed or available for installation
  check_dependencies_satisfiability(
    x = x,
    req_deps = options::opt("req_deps"),
    inst_deps = dependencies,
    lib.loc = lib.loc,
    repos = repos
  )
  # install dependencies into respective libraries
  # set env variable to make sure that crancache is not used
  # and that native git is used (instead of git2r)
  withr::with_envvar(c("R_REMOTES_STANDALONE" = "true"), {
    withr::with_options(list(available_packages_filters = list(
      # defaults, minus "duplicates"
      "R_version", "OS_type", "subarch",
      # custom duplicates
      # prioritizing first repo where the package is discovered
      "use first available repo" = avu_remove_duplicates
    )), {
      installation_steps <- avu_discover_installation_steps(
        dependencies,
        installation_order
      )
      # install_validation_dependencies uses remotes::dev_package_deps which
      # excludes recommended packages from update and installation.
      # Therefore we need to force upgrade of these packages
      update_r_recommended(repos = repos)
      for (step in installation_steps) {
        if (step == "Validation") {
          isolate_install_source_package(x, libs[[1]], install_libpaths)
          if (!is_package_installed(x$package, libs[[1]])) {
            stop(sprintf(
              "The validation package `%s` did not install sucesfully.\n (log: '%s').", # nolint
              x$package,
              file.path(options::opt("log_output"), "installation.log")
            ))
          }
        } else {
          install_validation_dependencies(
            x = x,
            deptype = step,
            lib = libs[["Dependencies"]],
            repos = repos,
            upgrade = avu_upgrade_policy(upgrade, step),
            installation_libpath = install_libpaths,
            INSTALL_opts = c("--with-keep.source", "--install-tests"),
            quiet = FALSE,
            ...
          )
        }
      }
    })
  })

  # return a new package object pointing to newly installed version
  as.package(file.path(libs[[1]], x$package))
}



#' Check dependency satisfiability
#'
#' A helper function to throw an error before attempting to update packages if
#' dependencies are unsatisfiable.
#'
#' @inheritParams dependencies_satisfiability
#'
#' @importFrom jsonlite toJSON
#'
check_dependencies_satisfiability <- function(
    x,
    req_deps = options::opt("req_deps"),
    inst_deps = options::opt("inst_deps"),
    lib.loc = options::opt("lib.loc"),
    repos = getOption("repos", NULL)) {
  x <- as.package(x)

  deps <- dependencies_satisfiability(
    x = x,
    req_deps = req_deps,
    inst_deps = inst_deps,
    lib.loc = lib.loc,
    repos = repos
  )

  # stop if some dependencies can't be satisfied
  if (!all(deps$satisfiable)) {
    # Pick relevant columns and rows in order
    missing_deps <- deps[
      !deps$satisfiable,
      c("type", "package", "op", "version", "installed", "available")
    ]

    # Gather deps as json that can be later used and dump into the file
    pkgs_names <- unique(missing_deps$package)
    deps_json <- lapply(pkgs_names, function(pkg) {
      pkg_row <- missing_deps[missing_deps$package == pkg, ]
      list(
        type = pkg_row[["type"]],
        op = pkg_row[["op"]],
        version = pkg_row[["version"]],
        installed = pkg_row[["installed"]],
        available = pkg_row[["available"]]
      )
    })
    names(deps_json) <- pkgs_names
    deps_json <- jsonlite::toJSON(deps_json)

    f <- file.path(options::opt("log_output"), "unmet_deps.json")
    writeLines(deps_json, con = f)

    # Stop validation with an error
    missing_deps_err_msg <- capture.output(missing_deps)
    stop(call. = FALSE, paste0(
      "\n",
      "Dependencies not met and not permitted to be installed or updated:\n",
      "    \n",
      paste0("    ", missing_deps_err_msg, "\n", collapse = ""),
      "    \n"
    ))
  }

  deps
}

#' Install validation dependencies
#'
#' Install dependencies required by the package based on the type. Functions
#' takes the package `x`, resolves its dependencies using
#' `remotes::dev_package_deps` for type `deptype` including
#' dependencies of higher order. Then it uses `remotes:::update.package_deps`
#' generic to install packages based in its type.
#'
#' @param x a package object.
#' @param deptype character string with type of dependency to install.
#' @param lib library dedicated for a given dependency.
#' @param upgrade logical whether packages should be allowed to be upgraded.
#' @param installation_libpath libpath used during packages installation
#' @param ... other parameters passed to the install.packages
#' @inheritParams avu_install
#'
install_validation_dependencies <- function(
    x, deptype, lib, repos, upgrade,
    installation_libpath, ...) {
  msg <- sprintf("Installing '%s' dependencies", deptype) # nolint
  status <- avu_cli_status(paste(
    "{cli::symbol$arrow_right}",
    "{msg}",
    "{cli::symbol$ellipsis}"
  ))

  repos <- if (deptype %in% DEP_LIB_CORE) {
    repos
  } else {
    c(repos, options::opt("suggests_repos"))
  }

  deps_to_install <- resolve_dependencies(x, deptype, repos, upgrade)

  for (i in seq_len(NROW(deps_to_install))) {
    pkg_dep <- deps_to_install[i, ]
    pkg_name <- if (pkg_dep$is_cran) {
      pkg_dep$package
    } else {
      paste(pkg_dep$package, "(Remote)")
    }

    status <- avu_cli_status_update(status, paste(
      "{cli::symbol$arrow_right}",
      "{msg}",
      "{cli::symbol$ellipsis}",
      "{pkg_name}",
      "({i}/{NROW(deps_to_install)})"
    ))

    package_log_dir <- file.path(
      options::opt("log_output"), "packages", make.names(pkg_name)
    )

    dir_create(package_log_dir, recursive = TRUE)

    update_args <- c(
      list(
        object = pkg_dep,
        dependencies = DEP_LIB_CORE,
        lib = lib,
        repos = repos,
        upgrade = upgrade,
        keep_outputs = package_log_dir
      ),
      list(...)
    )

    result <- avu_isolated_process(
      callr::r,
      f = function(update_args, pkg_name, remotes_lib) {
        requireNamespace("remotes", lib.loc = remotes_lib)
        tryCatch(
          {
            # In remotes code 2 stands for unavailable package
            if (update_args$object$diff == 2) {
              warning("Package ", pkg_name, " is not available")
            }
            # remotes are loaded prior by the isolated_installation_process so
            # there is no issue with S3 methods dispatch
            do.call(stats::update, update_args)
          },
          error = function(e) {
            structure(e$message,
              status = "error"
            )
          },
          warning = function(w) {
            structure(w$message,
              status = "warning"
            )
          }
        )
      },
      args = list(
        update_args = update_args,
        pkg_name = pkg_name,
        remotes_lib = dirname(find.package("remotes"))
      ),
      libpath = installation_libpath,
      stdout = file.path(package_log_dir, "callr.log"),
      stderr = file.path(package_log_dir, "callr.log"),
    )

    if (!is.null(result) && attr(result, "status") %in% c("error", "warning")) {
      avu_cli_multiline_alert(cli::cli_alert_info, result)
    }
  }

  avu_cli_status_clear(
    id = status,
    result = "done",
    msg_done = "{cli::symbol$tick} {msg} DONE"
  )
}

#' Isolated Installation of the source Package
#'
#' Install a package from source in a separate process with a restricted set of
#' environment variables and options to avoid stateful installation
#' artifacts.
#'
#' @details
#' Packages that are the focus of validation need to be installed in a
#' separate process to make sure `autovalidateutils` libraries will
#' not conflict with the package's dependencies. This is not an issue
#' as all of our checks that require to load the package are run in
#' separate processes as
#'
#' @inheritParams install_validation_dependencies
#'
isolate_install_source_package <- function(x, lib, installation_libpath) {
  # We need to install the package under validation in a separate process
  # to make sure autovalidateutils libraries will not conflict with
  # packages' dependencies. This is not an issue us all of our checks
  # that require to load the package are run in separate processes as well.
  avu_isolated_process(
    callr_f = callr::r,
    f = function(x, lib, remotes_lib) {
      requireNamespace("remotes", lib.loc = remotes_lib)
      remotes::install_local(
        x$path,
        force = TRUE, # always install into validation library
        INSTALL_opts = c("--with-keep.source", "--install-tests"),
        dependencies = FALSE,
        quiet = FALSE,
        upgrade = FALSE,
        lib = lib
      )
    },
    args = list(
      x = x,
      lib = lib,
      remotes_lib = dirname(find.package("remotes"))
    ),
    libpath = installation_libpath,
    stdout = file.path(options::opt("log_output"), "installation.log"),
    stderr = file.path(options::opt("log_output"), "installation.log")
  )
}

#' Initialize autovalidateutils libraries
#'
#' Dependencies of the validated package shall be installed into separate
#' temporary library. The function creates this library as well as library
#' for Validation package and returns a named list
#' `c("Validation", "Dependencies")` of localization. Elements of that list are
#' paths to the libraries. "Validation" element represents installation path for
#' the actual package.
avu_initialize_libs <- function() {
  libs <- list(
    Validation = file.path(normalize_path(tempdir()), "R_LIB_validation"),
    Dependencies = file.path(normalize_path(tempdir()), "R_LIB_dependencies")
  )

  for (lib in libs) {
    dir_create(lib, recursive = TRUE)
  }

  libs
}

#' Should a Dependency Version be Upgraded
#'
#' By default, `autovalidateutils` wants to upgrade all core dependencies to
#' make sure that whenever there is a dependency pre-installed to the system,
#' it is updated to the latest version available in the validated repository.
#' This is to make sure that package is always tested against set of core
#' dependencies that are up to date with the validated sources.
#'
#' The default behavior (`NULL`) prevents upgrades for optional dependencies as
#' we want to disallow upgrades for optional packages. These upgrades might
#' potentially include packages from non-validated repos specified by
#' the `suggests_repos` option (CRAN for instance).
#'
#' @param upgrade `logical` indicating whether all or no dependencies should be
#'   upgraded, or `NULL` (Default) to indicate that only "core" dependencies
#'   (Depends, Imports and LinkingTo) should be upgraded.
#' @param dep `character` specifying dependency type.
#'
#' @return A `logical` scalar indicating whether the dependency type should be
#'   upgraded.
#'
avu_upgrade_policy <- function(
    upgrade = options::opt("upgrade_deps"), dep = NULL) {
  dep <- match.arg(
    dep, c("Depends", "Imports", "LinkingTo", "Suggests", "Enhances")
  )
  if (is.logical(upgrade)) {
    upgrade
  } else if (is.null(upgrade) && dep %in% DEP_LIB_CORE) {
    TRUE
  } else {
    FALSE
  }
}

#' Discover dependencies types
#'
#' Dependencies can be passed as logical or character objects. The function
#' matches logical values to appropriate character equivalents. Additionally
#' it sorts dependencies according to order set by installation_order vector
#'
#' @param dependencies a character or logical indicating dependencies
#' @param installation_order Character vector specifying in which order
#'   dependencies types and the package under validation should be installed.
avu_discover_dependencies_types <- function(dependencies, installation_order) {
  dependencies <- if (isTRUE(dependencies)) {
    # This is intentionally different to what remotes promotes
    # due to the specifics of validation
    c("Depends", "Imports", "LinkingTo", "Suggests", "Enhances")
  } else if (length(dependencies) == 1 && is.na(dependencies)) {
    c("Depends", "Imports", "LinkingTo")
  } else if (is.character(dependencies)) {
    dependencies
  } else {
    # Note that it also covers FALSE values
    c()
  }

  dependencies[order(match(dependencies, installation_order))]
}


#' Discover installation steps
#'
#' Append "Validation" step to the list of all dependencies to produce full list
#' of steps required to install the package. Next, sort the new vector
#' according to the installation_order value
#'
#' @inheritParams avu_discover_dependencies_types

avu_discover_installation_steps <- function(dependencies, installation_order) {
  steps <- c("Validation", dependencies)
  steps[order(match(steps, installation_order))]
}

#' Resolve validation dependencies
#'
#' Discover dependencies of the given type for the package under validation.
#' Internal make use of the "use_remotes" option to discover remotes
#' configuration and accepts remotes or Additional_repository sources
#' accordingly. Then `remotes::dev_package_deps` is used to discover actual
#' dependencies which is later filtered according to options and `deptype`.
#'
#' @inheritParams install_validation_dependencies
resolve_dependencies <- function(x, deptype, repos, upgrade) {
  # Discover remotes settings
  use_remotes <- options::opt("use_remotes")
  remotes_options <- if (is.logical(use_remotes)) {
    list(allow = use_remotes, prefer = use_remotes)
  } else if (!is.null(names(use_remotes)) && deptype %in% names(use_remotes)) {
    switch(use_remotes[deptype],
      "allow" = list(allow = TRUE, prefer = FALSE),
      "prefer" = list(allow = TRUE, prefer = TRUE),
      "disallow" = list(allow = FALSE, prefer = FALSE),
    )
  } else {
    list(allow = FALSE, prefer = FALSE)
  }

  # Suppress warnings coming from unavailable remote sources
  # For some reason suppressWarnings does not work therefore
  # we run this bit with special options.
  withr::with_options(list(warn = -1), {
    deps_to_install <- remotes::dev_package_deps(
      x$path,
      repos = repos,
      dependencies = deptype,
      remote_precedence = remotes_options$prefer,
      additional_repositories = remotes_options$allow
    )
  })

  # Filter remotes sources packages
  deps_to_install <- filter_remotes(
    x = x,
    deps_to_install = deps_to_install,
    deptype = deptype,
    allow = remotes_options$allow,
    prefer = remotes_options$prefer
  )

  # Remotes sources
  # If upgrade is false, filter out already installed packages from
  # the list to not inflate total count, otherwise filter out
  # those which available version matches installed
  if (!upgrade) {
    deps_to_install <- deps_to_install[is.na(deps_to_install$installed), ]
  } else {
    deps_to_install <- deps_to_install[
      is.na(deps_to_install$installed) |
        deps_to_install$installed != deps_to_install$available,
    ]
  }

  deps_to_install
}

#' Filter remote sources
#'
#' Filter list of dependencies to install based on the options to include only
#' expected remotes sources. In case when remote source name is unavailable,
#' but the source itself can be fetched, source is cloned to tmp in order
#' to derive whether it should be included. Shuch situation might happen for
#' instance when specifying corporate gitlab as remotes source.
#'
#' @inheritParams install_validation_dependencies
#' @param deps_to_install - data.frame of dependencies generated with
#' \code{remotes::dev_package_deps}
#' @param allow - logical flag whether remote sources should be included
#' @param prefer - logical flag whether remote sources should be prefered
#' over standard ones
#'
filter_remotes <- function(x, deps_to_install, deptype, allow, prefer) {
  # Packages that cannot be installed will have available version as NA
  # we can filter those right away
  deps_to_install <- deps_to_install[!is.na(deps_to_install$available), ]

  # Packages that are hosted in the corporate gitlab will have the NA name
  # but they still can be installed. However we cannot just install them
  # as they will appear for any dependency type, for instance remotes
  # "Imports" dependencies will also show when looking only for "Suggests"
  # dependencies. That's why we have to shallow clone the remote to check
  # for the name of the package and it's dependency type
  avu_install_clone_path <- file.path(tempdir(), "avu_install_clone_path")
  unlink(avu_install_clone_path, recursive = TRUE)
  dir.create(avu_install_clone_path, showWarnings = FALSE)
  rows_to_exclude <- c()

  for (i in seq_len(NROW(deps_to_install))) {
    if (!is.na(deps_to_install[i, ]$package)) {
      next()
    }

    # Suppress debug messages
    repo_path <- suppressMessages(remotes::remote_download(
      deps_to_install[i, ]$remote[[1]]
    ))

    pkg <- as.package(repo_path)
    pkg_deps <- get_package_dependencies(x)
    pkg_deps_of_deptype <- pkg_deps[pkg_deps$type == deptype, "package"]

    if (pkg$package %in% deps_to_install$package && !prefer) {
      rows_to_exclude <- c(rows_to_exclude, i)
    } else if (pkg$package %in% deps_to_install$package && prefer) {
      # Exclude standard source + set correct name of the remote
      rows_to_exclude <-
        c(rows_to_exclude, which(deps_to_install$package == pkg$package))
      deps_to_install[i, ]$package <- pkg$package
    } else if (pkg$package %in% pkg_deps_of_deptype) {
      deps_to_install[i, ]$package <- pkg$package
    } else {
      rows_to_exclude <- c(rows_to_exclude, i)
    }
  }

  if (length(rows_to_exclude) > 0) {
    deps_to_install <- deps_to_install[-rows_to_exclude, ]
  }

  if (!allow) {
    deps_to_install <- deps_to_install[deps_to_install$is_cran, ]
  }

  deps_to_install
}

#' Update R-recommended
#'
#' Identify which installed R-recommended packages are behind default
#' repositories and update them in respective libraries.
#'
#' @inheritParams avu_install
update_r_recommended <- function(repos) {
  ip <- installed.packages()
  idx <- !is.na(ip[, "Priority"]) & ip[, "Priority"] == "recommended"
  recommended <- ip[idx, "Package"]
  op <- utils::old.packages(repos = repos)
  recommended_op <- op[op[, "Package"] %in% recommended, , drop = FALSE]
  if (length(recommended_op) < 1) {
    return(invisible(NULL))
  }
  for (i in seq_along(NROW(recommended_op))) {
    pkg <- recommended_op[i, , drop = FALSE]
    install.packages(
      pkg[, "Package"],
      lib = pkg[, "LibPath"],
      repos = repos,
      dependencies = FALSE,
      verbose = FALSE,
      quiet = TRUE
    )
  }
  invisible(NULL)
}
