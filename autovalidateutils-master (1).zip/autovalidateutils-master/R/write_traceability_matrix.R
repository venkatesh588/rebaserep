#' Write Traceability Matrix metadata
#'
#' Build traceability matrix metadata for use with `autovalidate`. This process
#' uses `covr::package_coverage` to trace expressions evaluated by individual
#' tests, and links each expression to package requirements, defined in
#' namespace export documentation.
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams autovalidate
#'
#' @importFrom covr package_coverage to_sonarqube report
#' @importFrom yaml write_yaml
#' @importFrom withr with_libpaths
#' @importFrom xml2 write_xml
#' @importFrom knitr kable
#' @export
#'
write_traceability_matrix <- function(
  x = ".",
  output = options::opt("output"),
  test_exec_log = options::opt("test_exec_log"),
  documentation = options::opt("documentation"),
  mapper = options::opt("mapper"),
  mapper_defaults = options::opt("mapper_defaults"),
  junit = options::opt("junit"),
  sonarqube = options::opt("sonarqube"),
  errors = options::opt("errors"),
  cov_report = options::opt("cov_report"),
  cov_table = options::opt("cov_table"),
  cov_logs = options::opt("cov_logs"),
  testing_session = options::opt("testing_session"),
  log_output = options::opt("log_output"),
  quiet = options::opt("quiet"),
  ...
) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    output = output,
    log_output = log_output,
    quiet = quiet
  ))

  x <- as.package(x)

  # If `Running R CMD check` step was run during the autovalidateutils run
  # try to reuse source built then to make sure tests are run on the same source
  tarball_path <- get_check_tarball_path(x)
  if (file.exists(tarball_path) && options::opt("reuse_check_source")) {
    exdir <- file.path(tempfile("autovalidateutils_check_source"))
    untar(tarball_path, exdir = exdir)
    x <- as.package(file.path(exdir, x$package))
  }

  dir_create(dirname(errors <- avu_path(output, errors)))
  dir_create(dirname(test_exec_log <- avu_path(output, test_exec_log)))
  dir_create(dirname(junit <- avu_path(output, junit)))
  dir_create(dirname(testing_session <- avu_path(output, testing_session)))
  dir_create(dirname(mapper <- avu_path(output, mapper)))
  dir_create(documentation <- avu_path(output, documentation))
  dir_create(dirname(sonarqube <- avu_path(output, sonarqube)))
  dir_create(dirname(cov_report <- avu_path(output, cov_report)))
  dir_create(dirname(cov_table <- avu_path(output, cov_table)))
  dir_create(cov_logs <- avu_path(output, cov_logs))

  # Check if there is an actual code base to test

  avu_cli_task("Checking for code to test", {
    if (check_if_no_code_to_test(x)) {
      # Set the flag to exit from this function after the task completes
      no_code_to_test <- TRUE
      warning("No testable code found")
    } else {
      no_code_to_test <- FALSE
    }
  })

  # Exit the function if there is no code to test
  if (no_code_to_test) {
    return(invisible(FALSE))
  }

  # Messages about environment configuration should go before actual tests
  avu_cli_task("Check environment configuration", {
    message_testthat_configuration(x)
  })

  # run package_coverage, reporting unit test results out to junit subdir
  avu_cli_task("Running covr (with {.code options(covr.record_tests = TRUE)})", { # nolint
    cov <- try(safe_package_coverage(
      x,
      type = "tests",
      file = junit,
      test_exec_log = test_exec_log,
      testing_session = testing_session,
      log_output = log_output,
      cov_logs = cov_logs
    ),
    silent = TRUE
    )

    cov_failure <- inherits(cov, "try-error")

    if (cov_failure) {
      warn_coverage_failure(cov)
    } else {
      warn_insufficient_coverage(x, cov)
    }
  })

  # save coverage report
  avu_cli_task("Writing interactive coverage report", {
    tryCatch(
      callr::r_vanilla(
        function(cov, cov_report) {
          # nocov start
          if (!(
            requireNamespace("htmltools", quietly = TRUE) &&
              requireNamespace("DT", quietly = TRUE)
          )) {
            stop(
              "The `DT` and `htmltools` packages must be ",
              "installed to use `covr::report()`"
            )
          } else {
            covr::report(cov, file = cov_report, browse = FALSE)
          }
          # nocov end
        },
        args = list(cov = cov, cov_report = cov_report),
        libpath = options::opt("original_libpaths")
      ),
      error = function(e) {
        message(
          "Error encountered while generating interactive coverage report: \n",
          conditionMessage(e)
        )
      }
    )
  },
  skip_if = c(
    "Skipping interactive coverage report generation due to the coverage calculation failure" = cov_failure, # nolint
    "Skipping interactive coverage report generation due to the 'skip_cov_report' set to TRUE" = as.logical(options::opt("skip_cov_report")) # nolint
  )
  )

  # save coverage table
  avu_cli_task("Writing coverage table",
    {
      withr::with_libpaths(
        c(package_library("knitr"), .libPaths()),
        {
          tryCatch(
            {
              cov_df <- prepare_coverage_df(cov)
              writeLines(
                knitr::kable(
                  cov_df,
                  col.names = sprintf("**%s**", colnames(cov_df))
                ),
                con = cov_table
              )
            },
            error = function(e) {
              message(
                "Error encountered while generating coverage table: \n",
                conditionMessage(e)
              )
            }
          )
        }
      )
    },
    skip_if = c("Skipping coverage table generation due to the coverage calculation failure" = cov_failure) # nolint
  )

  # extract and structure test traces
  avu_cli_task("Building traceability matrix",
    {
      trace_matrix <- build_traceability_matrix(cov)

      if ("testthat" %in% trace_matrix$test_type) {
        # logical mask for tests that use testthat
        i <- !is.na(trace_matrix$test_type) &
          trace_matrix$test_type == "testthat"
        trace_matrix[i, ]$test_description <- escape_special(
          trace_matrix[i, ]$test_description
        )
      }

      not_testthat_traces <-
        !is.na(trace_matrix$test_type) & trace_matrix$test_type != "testthat"
      # Condition below assures us that there are tests
      # to change the description.
      # any(logical(0)) == FALSE so we don't need to check whether NROW(df) > 0
      if (any(not_testthat_traces)) {
        test_description <- trace_matrix[not_testthat_traces, ]$test_description
        code_test_description <- vapply(
          test_description,
          code_backticks,
          character(1)
        )
        trace_matrix[not_testthat_traces, ]$test_description <-
          code_test_description
      }
    },
    skip_if = c("Skipping traceability matrix building due to the coverage calculation failure" = cov_failure) # nolint
  )

  avu_cli_task("Building documentation index", {
    rd_df <- build_documentation_index(x)
  })

  avu_cli_task("Filtering reexports and joining documentation indices",
    {
      rd_df <- filter_reexports(build_documentation_index(x), trace_matrix)
      trace_matrix <- join_traceability_docindex(trace_matrix, rd_df)
    },
    skip_if = c("Skipping filtering reexports due to the coverage calculation failure" = cov_failure) # nolint
  )

  avu_cli_task("Writing autovalidate requirements from object documentation", {
    which_rds <- !duplicated(rd_df$index)
    rdfilepaths <- rd_df$filepath[which_rds]
    rdindices <- rd_df$index[which_rds]
    mds <- append_indices_to_documentation(rdfilepaths, indices = rdindices)
    for (i in seq_along(mds)) {
      md_filename <- file.path(documentation, names(mds)[[i]])
      md_content <- mds[[i]]
      tryCatch(writeLines(md_content, md_filename),
        error = function(e) {
          stop(sprintf("Error writing file '%s'", md_filename))
        }
      )
    }
  })

  # All steps below require coverage object to succeed, therefore we
  # exit the function after generating documentation
  # if a coverage failure was identified before
  if (cov_failure) {
    return(invisible(FALSE))
  }

  avu_cli_task("Preparing junit file and matching with traceability matrix", {
    # JUnit file and the tractability matrix tests names should undergo the
    # same treatment making sure they could be combined into a mapper
    junit_xml <- junit_load_or_create(junit)
    trace_matrix$test_name <- normalize_text(trace_matrix$test_name)
  })


  # add in traces that were not covered in the testresults file
  #   - either covr traces from outside explicit testthat tests
  #   - or covr traces from non-testthat packages, which produce no junit file
  avu_cli_task("Suplement junit with traces not covered in the testresults", {
    missing_tests <- setdiff(unique(trace_matrix$test_name),
                             junit_test_names(junit_xml))

    # Exclude NA from the missing tests as this is actually an indicator
    # that the test is missing
    missing_tests <- missing_tests[!is.na(missing_tests)]

    # We inverse isFALSE so the TRUE value will be assumed for everything except
    # explicit "FALSE" to ensure conservative default value
    r_cmd_check_failures <- !isFALSE(as.logical(
      Sys.getenv("AUTOVALIDATEUTILS_R_CHECK_TESTS_FAILURE", TRUE)
    ))
    agnostic_tests_status <- if (r_cmd_check_failures &&
                                   !uses_testthat(x)) {
      message(
        "testthat infrastructure was not detected and R CMD check reported ",
        "test failures. Marking tests results as unknown."
      )
      "unknown"
    } else {
      "success"
    }
    junit_xml <- junit_add_tests(
      junit_xml,
      "additional covr traces",
      missing_tests,
      statuses = agnostic_tests_status
    )
  },
    skip_if = c("Skipping suplementing junit with missing traces" = !as.logical(options::opt("add_missing_traces"))) # nolint
  )

  avu_cli_task("Post-process junit file", {
    # skip events are reported as testcases in the junit file, despite not
    # being associated with specific tests. remove to avoid ambiguity.
    junit_xml <- junit_remove_skipped_nodes(junit_xml)
    xml2::write_xml(junit_xml, junit)
  })

  # build mapping file contents, mapping unique tests to associated requirements
  avu_cli_task("Writing traceability matrix mapping", {

    # subset for only tests in junit file, possibly with skipped tests removed
    in_junit <- trace_matrix$test_name %in% junit_test_names(junit_xml)
    is_missing_name <- is.na(trace_matrix$test_name)
    is_reported <- in_junit | is_missing_name

    # cross-check trace matrix against junit file
    trace_matrix <- trace_matrix[is_reported, ]

    max_n <- nchar(length(unique(rd_df[["file"]]))) # nolint object_usage_linter.
    mapping <- unname(lapply(
      split(trace_matrix, trace_matrix$test_name),
      function(i) {
        with(i, Filter(Negate(is.null), list(
          test = head(test_name, 1L),
          requirements =
            as.list(lpadstr(na.omit(unique(docindex)), max_n, "0")),
          description = if (isTRUE(mapper_defaults))
            head(test_description, 1L),
          author = if (isTRUE(mapper_defaults))
            "author traceable within git",
          reviewer = if (isTRUE(mapper_defaults))
            "reviewer traceable within git",
          review_date = if (isTRUE(mapper_defaults))
            "review data traceable within git",
          id = as.character(head(test_id, 1L))
        )))
      }
    ))
    yaml::write_yaml(mapping, mapper)
  })

  invisible(TRUE)
}


#' Resolve `test_trace_df` test names in testthat style
#'
#' Converts tests names to mirror the names used in a `testthat` "junit" output
#' file and names any additional tests as "unnamed". The `data.frame` is also
#' reordered by test name and a test index is created in preparation for
#' producing a mapper file.
#'
#' @param df A `test_trace_df` `data.frame` to process
#'
test_trace_df_clean_test_names <- function(df) {
  df$test_description <- df$test_name
  df$test_name <- .testthat$classnameOK(df$test_name)
  na_traces <- which(is.na(df$test_name))
  duplicated_na <- duplicated(df[na_traces, c("alias", "test_name")])
  traces_to_skip <- na_traces[duplicated_na]
  # Skip only if there are actual traces that should be skipped
  # We are using base functions so df[-traces_to_skip, ] when
  # traces_to_skip is integer(0) would return an empty data.frame
  # rather than a full one.
  if (length(traces_to_skip) > 0) {
    df <- df[-traces_to_skip, ]
  }
  df <- df[order(df$test_name), ]
  is_test <- !is.na(df$test_name)
  df[is_test, "test_id"] <- rep(
    seq_along(unique(df[is_test, ]$test_name)),
    times = vapply(
      split(df[is_test, ], df[is_test, ]$test_name),
      nrow,
      numeric(1L)
    )
  )

  df
}


#' Build documentation index
#'
#' @param x A package object
#'
#' @importFrom covtracer Rd_df
#' @importFrom callr r_vanilla
#'
build_documentation_index <- function(x) {
  # call covtracer in separate environment to avoid clashes with packages
  # already loaded autovalidateutils deps libraries
  rd_df <- run_covtracer(
    # nocov start
    func = function(x) {
      covtracer::Rd_df(x)
    },
    # nocov end
    args = list(x = x),
    libpath = c(package_library("covtracer"), .libPaths())
  )

  rd_is_testable <- is.na(rd_df$doctype) |
    !rd_df$doctype %in% c("data", "class")
  rd_df <- rd_df[rd_df$is_exported & rd_is_testable, ]
  rd_df$index <- match(rd_df$file, sort(unique(rd_df$file)))
  rd_df
}



#' Filter reexports from documentation index
#'
#' @param rd_df A documentation data frame, as produced by
#' `build_documentation_index`.
#' @param tt_df A trace matrix, as produced by `build_traceability_matrix`.
#'
filter_reexports <- function(rd_df, tt_df) {
  # filter out Rd files where all related objects are from other namespaces
  is_reexport <- vapply(
    split(tt_df, tt_df$filepath),
    function(df) all(df$is_reexported),
    logical(1L)
  )

  rd_df <-
    rd_df[rd_df$filepath %in% names(is_reexport[!is_reexport]), , drop = FALSE]

  # reindex docs
  rd_df$index <- match(rd_df$file, sort(unique(rd_df$file)))

  rd_df
}


#' Build traceability matrix
#'
#' @param cov Coverage object
#'
#' @importFrom covtracer test_trace_df
#' @importFrom callr r_vanilla
#'
build_traceability_matrix <- function(cov) {
  # call covtracer in separate environment to avoid clashes with packages
  # already loaded autovalidateutils deps libraries
  tt_df <- run_covtracer(
    # nocov start
    func = function(cov) {
      covtracer::test_trace_df(cov)
    },
    # nocov end
    args = list(cov = cov),
    libpath = c(package_library("covtracer"), .libPaths())
  )

  tt_df <- test_trace_df_clean_test_names(tt_df)
  tt_df[order(tt_df$test_name), , drop = FALSE]
}

run_covtracer <- function(func, args, ...) {
  if (options::opt("covtracer_debug")) {
    do.call(func, args)
  } else {
    callr::r_vanilla(func, args, ...)
  }
}

#' Add Rd documentation index to test traces
#'
#' @param tt_df A test-trace data frame, as produced by covtracer
#' @param rd_df Documentation index dataframe, as produced by
#'   \code{\link{build_documentation_index}}.
#'
join_traceability_docindex <- function(tt_df, rd_df) {
  docindex <- rd_df$index[match(tt_df$file, rd_df$file)]
  cbind(tt_df, docindex = docindex)
}

check_if_no_code_to_test <- function(x) {
  number_of_R_files <- length(list.files(file.path(x$path, "R")))
  no_R_files <- number_of_R_files == 0

  namespace <- readLines(file.path(x$path, "NAMESPACE"))
  empty_namespace <- !any(!(startsWith(namespace, "#") | namespace == ""))

  no_R_files || empty_namespace
}

warn_coverage_failure <- function(x) {
  warning("Coverage calculation failed with a message: \n\n", x)
}

message_not_using_testthat <- function(x) {
  x <- as.package(x)
  if (!uses_testthat(x)) {
    message("Use testthat to provide meaningful test descriptions")
  }
}

message_testthat_configuration <- function(x) {
  x <- as.package(x)
  if (!uses_testthat(x)) {
    message("Use testthat to provide meaningful test descriptions")
  }
  if (testthat_is_on_cran()) {
    message("Skipping `testthat::skip_on_cran` tests")
  }
  if (testthat_is_on_ci()) {
    message("Skipping `testthat::skip_on_ci` tests")
  }
}

#' @importFrom covr percent_coverage
warn_insufficient_coverage <- function(x, cov) {
  cov_thresh <- options::opt("coverage_threshold")
  cov_perc <- covr::percent_coverage(cov)
  # In some cases covr::percent_coverage may return NaN or NA causing problems
  # further into those checks. By checking first its finiteness we make sure
  # that cov_perc is a number for which comparisons are meaningful
  if (!is.finite(cov_perc)) {
    warning(sprintf(
      "Package's coverage is '%s' which is not a meaningful number",
      cov_perc
    ))
  } else if (cov_perc < cov_thresh) {
    warning(
      sprintf(
        "Coverage is at %.2f%% and does not meet %.2f%% threshold",
        cov_perc,
        cov_thresh
      )
    )
  }
}

#' Append indices to documentation files
#'
#' This is the wrapper over \code{\link[rd2markdown]{documentation_to_markdown}}
#' function. Please visit documentation of \code{documentation_to_markdown}
#' for any details. The purpose of this wrapper is to add indices to the output
#' list names that are used for mapping the tests

#' @param indices Documentation indices corresponding to each documentation
#'   file.
#' @inheritParams options_params
#' @inheritParams rd2markdown::documentation_to_markdown
#'
#' @importFrom rd2markdown documentation_to_markdown
#' @importFrom tools file_path_sans_ext
#' @return A named character vector of markdown content, with the name providing
#'   an `autovalidate`-style requirements filename.
#'
append_indices_to_documentation <- function(
  rdfilepaths,
  fragments = options::opt("documentation_fragments"),
  rd_transform = options::opt("rd_transform"),
  indices = seq_along(rdfilepaths)
) {

  rds <- mapply(function(x) {
    rd <- rd2markdown::get_rd(file = x)
    rd_transform(rd)
  }, rdfilepaths, SIMPLIFY = FALSE)
  docmds <- lapply(rds, rd2markdown::rd2markdown, fragments = fragments)
  names(docmds) <- basename(rdfilepaths)

  max_n <- nchar(max(indices, 1))
  names(docmds) <- sprintf(
    "0.%s-%s.md",
    lpadstr(indices, max_n, "0"),
    tools::file_path_sans_ext(basename(rdfilepaths))
  )

  docmds
}
