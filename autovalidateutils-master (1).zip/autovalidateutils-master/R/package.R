# Throughout this package you may see plenty of importFrom statements.
# We appreciate the fact that there were mostly used with disregard to general
# guidelines applicable to this statement. However this is our deliberate action
# that takes into consideration nature of this package which is altering
# the .libPaths during the run time. By putting multiple importFrom statements
# we assure that the packages we use as dependencies are loaded whenever
# autovalidateutils is loaded, and therefore potential change to .libPahts
# will not affect the execution.
#' @import utils
utils::globalVariables(".")
NULL
