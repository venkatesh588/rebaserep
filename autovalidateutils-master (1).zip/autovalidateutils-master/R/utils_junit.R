#' Extract test names from a JUnit-style xml document
#'
#' @param xmlobj (\code{\link[xml2:xml_new_document]{xml_document}}) An xml node
#'   to which JUnit structure should be added.
#'
#' @importFrom xml2 read_xml xml_find_all
#' @family junit
#'
junit_test_names <- function(xmlobj) {
  unique(xml2::xml_attr(xml2::xml_find_all(xmlobj, ".//testcase"), "name"))
}



#' Append tests to a JUnit-style xml document
#'
#' While executing a test suite, it's possible to evaluate code that isn't bound
#' to any test case. In order to capture all testing expressions which may
#' affect code coverage, additional traces may need to be added to the test
#' document.
#'
#' @param xmlobj (\code{\link[xml2:xml_new_document]{xml_document}}) A JUnit
#'   test results object into which new tests should be inserted.
#' @param testsuite (\code{character(1L)}) The testsuite name under which the
#'   new tests should be inserted.
#' @param testcases (\code{character(n)}) A vector of testcase names which
#'   should be inserted. Vector values will be recycled to the maximum length of
#'   each vector argument.
#' @param statuses (\code{character(n)}) A vector of test exit statuses. One of
#'   "success", "failure", "error", "skipped" or "unknown". Vector values will
#'   be recycled to the maximum length of each vector argument. Defaults to
#'   "success".
#' @param time (\code{numeric(n)}) A vector of test execution times. Vector
#'   values will be recycled to the maximum length of each vector argument.
#'   Defaults to \code{0L}.
#'
#' @importFrom xml2 xml_new_document xml_add_child
#' @family junit
#'
junit_add_tests <- function(
    xmlobj, testsuite, testcases, statuses = "success",
    time = 0L) {
  statuses <- rep_len(statuses, length(testcases))
  time <- rep_len(time, length(testcases))
  stopifnot(
    all(statuses %in% c("failure", "error", "skipped", "success", "unknown"))
  )

  ts <- xml2::xml_new_document("testsuites")
  ts <- xml2::xml_add_child(ts,
    "testsuite",
    name = testsuite,
    timestamp = "",
    hostname = "",
    tests = length(testcases),
    skipped = sum(statuses == "skipped"),
    failures = sum(statuses == "failure"),
    errors = sum(statuses == "error"),
    time = sum(time)
  )

  for (i in seq_along(testcases)) {
    testcase <- xml2::xml_add_child(ts,
      "testcase",
      time = time[[i]],
      classname = testsuite,
      name = testcases[[i]]
    )

    if (statuses[[i]] == "failure") {
      xml2::xml_add_child(testcase, statuses[[i]], type = "failure")
    } else if (statuses[[i]] != "success") {
      xml2::xml_add_child(testcase, statuses[[i]])
    }
  }

  xml2::xml_add_child(xmlobj, ts)
  xmlobj
}



#' Create a new JUnit-style xml document
#'
#' @importFrom xml2 xml_new_root
#' @family junit
#'
junit_create <- function() {
  xml2::xml_new_root("testsuites")
}



#' Load a JUnit-style xml document from file, or create if it doesn't exist
#'
#' @param f (\code{character(1L)}) A file path to attempt to load from
#'
#' @importFrom xml2 read_xml
#' @family junit
#'
junit_load_or_create <- function(f) {
  if (file.exists(f)) {
    junit_read_and_repair(f)
  } else {
    junit_create()
  }
}

#' Read and Repair JUnit file
#'
#' Try to read JUnit. In case of problems, raw file is read line by line and
#' attempts are made to fix the content. If the file is readable after
#' intervention, it overwrites original file, if not, error is returned.
#'
#' @param f A file path to attempt validation
#' @importFrom xml2 read_xml
#' @family junit
#'
junit_read_and_repair <- function(f) {
  # Apart from repairs we are editing junit file in a few other ways as well
  # therefore we want to always save original junit as a point of reference
  file.copy(
    f,
    paste0(tools::file_path_sans_ext(f), "_original.", tools::file_ext(f))
  )
  xml <- try(xml2::read_xml(f), silent = TRUE)

  if (!inherits(xml, "try-error")) {
    return(xml)
  }

  if (any(grepl("invalid character in attribute value", xml, fixed = TRUE))) {
    raw <- normalize_text(readLines(f))
  }
  # Add further steps of fixing the files here as another if statements

  # Check whether raw lines can be parsed as xml after changes
  xml <- try(xml2::read_xml(paste0(raw, collapse = "\n")), silent = TRUE)

  if (inherits(xml, "try-error")) {
    warning(
      "JUnit file is invalid and it could not be repaired. ",
      "Creating empty JUnit"
    )
    junit_create()
  } else {
    writeLines(raw, f)
    message("JUnit file was invalid and required patching")
    xml
  }
}

#' Remove skipped nodes JUnit file
#'
#' Remove nodes which have siblings of class "skipped" and adjust testsuite
#' attribute to match the new number of tests and skipped.
#'
#' @param xmlobj xml object to remove skipped tests from
#' @importFrom xml2 read_xml
#' @family junit
junit_remove_skipped_nodes <- function(xmlobj) {
  lapply(xml2::xml_find_all(xmlobj, ".//testsuite"), function(x) {
    skipped_tests <- as.numeric(xml2::xml_attr(x, "skipped"))
    xml2::xml_attr(x, "skipped") <- "0"
    tests <- as.numeric(xml2::xml_attr(x, "tests"))
    xml2::xml_attr(x, "tests") <- as.character(tests - skipped_tests)
    xml2::xml_remove(xml2::xml_parent(xml2::xml_find_all(x, ".//skipped")))
  })
  xmlobj
}
