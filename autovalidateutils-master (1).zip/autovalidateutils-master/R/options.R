set_envvar_name_fn(function(package, name) {
  gsub("[^A-Z0-9]", "_", toupper(paste0(package, "_", name)))
})

#' @import options
options::define_options(
  # General
  "Whether execution should suppress output. When `TRUE`, only warnings
   are emitted. When `FALSE`, a pretty-formatted log is emitted to the
   console.",
  quiet = FALSE,
  envvar_fn = envvar_is_true(),
  "Whether directories created by autovaldiateutils in /tmp directory
   should be removed. Set to TRUE if you want to save space in your /tmp. Keep
   FALSE to maintain all the output in /tmp. Does not affect regular output",
  clean = TRUE,
  envvar_fn = envvar_is_true(),
  "A difftime object or a numeric value with a real number indicating
   number of seconds that should pass before certain calls are timed out. Set to
   Inf to turn off timeout. By deafult set to difftime 14 hours.",
  timeout = as.difftime(14, units = "hours"),
  "A parent directory for all non-relative output files. Defaults to the
   current working directory.",
  output = file.path(normalize_path(tempdir()), "autovalidateutils"),
  "path to the directory where log files will be created.",
  log_output = file.path(normalize_path(tempdir()), "log_autovalidateutils"),
  "Vector storing original .libPaths before the vector was
   altered by avu_install function. It is always overwritten during
   autovalidateutils runtime.",
  original_libpaths = NULL,
  "Character vector describing the location of R library trees to search
   through. It will be passed to installed.packages() while deriving whether all
   required dependencies are installed.
   Defaults to c(.Library, .Library.site).",
  lib.loc = c(.Library, .Library.site),
  "Logical value whether all non-utf8 characters should be removed from
   the DESCRIPTION value. This is to avoid potential erros that might
   occure when installing the package from the source.",
  clear_description = FALSE,
  envvar_fn = envvar_is_true(),

  # Basic environment, session, package & execution info
  "The file path of the session information metadata file, a
   yaml-formatted itemization of a few characteristic measures of an R session
   environment.",
  session = "session.yml",
  "The file path of the `DESCRIPTION` file contents, written out to
   a plain text, yaml-formatted file.",
  description = "description.yml",
  "The file path of the `NEWS` (or `NEWS.md`) file contents. If the `NEWS` file
   is not already markdown formatted, it will be converted into a preformatted
   markdown code block to be embedded in an `autovalidate` report.",
  news = "news.md",
  "The file path of the file to which errors should be emitted. Messages
   are logged in yaml format, which is read by `autovalidate` to re-emit errors
   as `autovalidate` checks.",
  errors = "errors.yml",
  "Logical whether binary source of the package should be compiled during
   validation.",
  build_binaries = FALSE,
  envvar_fn = envvar_is_true(),
  "Logical whether sources produced during validation should be renamed to
   general 'package_binary.tgz/tar.gz/zip' and 'package_source.tar.gz'.",
  generalize_sources = FALSE,
  envvar_fn = envvar_is_true(),
  "A listing of autovalidateutils steps to perform. Either a `character` vector
   or `list`. Alternatively, the vector or list may consist of modifications
   to a listing of all steps, which must be prefixed by `-` (for example,
   `-write_revdep_check`, which will use all steps except reverse dependency
   checks).",
  steps = c("-write_checked"),

  # Debug files
  "The name of the installed packages json file. It keeps track of
   the information about which packages were installed to the environemnt
   and their versions. File will be written to the log_output directory",
  installed_packages = "installed_packages.json",

  # remotes control
  "Logical flag or named character mapping dependency types to the mechanism of
   handling remotes, one of \"allow\", \"prefer\" or \"disallow\". \"allow\"
   option means that the remote sources are allowed but will not take precedence
   over other standard sources if both available. \"prefer\" means allow and
   overwrite standard sources while \"disallow\" stands for skipping remote
   sources at all. If no value is provided for a dependency type it is
   considered to be \"disallow\". Can also be set to TRUE to \"prefer\" all or
   FALSE to \"disallow\ all.",
  use_remotes = c(
    "Depends" = "disallow",
    "Imports" = "disallow",
    "LinkingTo" = "disallow",
    "Suggests" = "allow",
    "Enhances" = "allow"
  ),

  # source control metadata
  "The file path to which package version control metadata
   should be captured.",
  version_control = "version_control.yml",
  "When a source control hash can't be derived from
   the target directory, this option will be used to populate version control
   metadata. This is of particular interest when the source code has been
   extracted from a tar.gz package bundle. In this case, the md5 hash should
   reflect the hash of the originating package bundle.",
  version_control.md5 = NULL,  # only used for tar.gz archives
  "When a source control origin can't be derived from
   the target directory, this option will be used to populate version control
   metadata. This is of particular interest when the source code has been
   extracted from a tar.gz package bundle. In this case, the url should
   reflect the url from which the originating package bundle was downloaded.",
  version_control.url = NULL,  # only used for tar.gz archives

  # vulnerabilities
  "The file path to which metadata reagarding possible package's
   vulnerabilities should be captured.",
  vulnerabilities = "vulnerabilities.yml",

  # R CMD check
  "The file path to which `R CMD check` results should be written.
   Contents are written in yaml format.",
  r_cmd_check = "r_cmd_check.yml",
  "The named character vector of environmental variables,
   that will be passed to the `withr::with_envvar` function and used to execute
   rcmdcheck::rcmdcheck. It can also be a single keyword, either 'cran' or
   'internal' that will result in using predefined set of variables.",
  r_cmd_check_variables = "internal",
  "Logical flag whether the <pkg>.Rcheck/<pkg>/tests
   directory should be cleared by removing all the directories in it",
  r_cmd_check_clean_tests = FALSE,
  envvar_fn = envvar_is_true(),

  # R CMD check results
  "The directory R CMD check results should be written to
   (.tag.gz, .Rcheck).",
  check_dir = "check",

  # code coverage
  "The file path in which to record a sonarqube xml coverage output file.",
  sonarqube = file.path("coverage", "sonarqube.xml"),
  "The file path in which to save coverage .html report.",
  cov_report = file.path("coverage", "cov_report.html"),
  "Logical whether interactive coverage report calculation shall be skipped",
  skip_cov_report = FALSE,
  envvar_fn = envvar_is_true(),
  "The file path in which to save markdown table with coverage percentage for
   each file.",
  cov_table = file.path("coverage", "cov_table.md"),
  "Directory where logs gathered during coverage execution are saved.",
  cov_logs = file.path("coverage", "logs"),
  "The file path of the yml parsed sessionInfo file that
   captures the environment in which units tests were executed.",
  testing_session = file.path("coverage", "testing_session.yml"),
  "The numeric value of the minimal code coverage percentage
   required for package to be validated",
  coverage_threshold = 80,

  # traceability matrix
  "Logical whether the source generated when running
   R CMD check should be used when calcualting coverage code coverage instead
   of the raw source.",
  reuse_check_source = TRUE,
  envvar_fn = envvar_is_true(),
  "The directory path into which R documentation should
   be written as markdown-formatted files. Files will be named with a prefixed
   index according to their lexical Rd name sorting. This index corresponds to
   the requirements index in the `mapper_file` option, and is used by
   `autovalidate` to generate a traceability matrix.",
  documentation = file.path("traceability_matrix", "documentation"),
  "A `character` vector of the types of `Rd` fragments 
   to be included in the resulting documentation markdown files, or `NULL` to 
   include all `Rd` contents.",
  documentation_fragments = c("title", "usage", "description", "details"),
  "A function which will be applied to the raw rd object before
  converting it to the markdown file. Identity function by default.",
  rd_transform = function(x) x,
  "The file path into which an `autovalidate`-style mapper file should
   be written.",
  mapper = file.path("traceability_matrix", "mapper.yml"),
  "If `TRUE`, default values will be injected into the
   autovalidate mapper.yml file for fields that have no direct analog in a
   typical testthat-generated junit.xml file. This includes the `author`,
   `reviewer` and `review_date`.",
  mapper_defaults = TRUE,
  envvar_fn = envvar_is_true(),
  "Logical whether covtracer shall be run in a debug mode. Debug
   means covtracer functions are run in the main process rather that
   callr::r_vanilla",
  covtracer_debug = FALSE,
  envvar_fn = envvar_is_true(),
  "Logical if covr traces which are missing in the testresults file should be
   added to the JUnit",
  add_missing_traces = TRUE,
  envvar_fn = envvar_is_true(),

  # unit testing
  "The file path of a file in which console output generated during test
   execution.",
  test_exec_log = "tests.Rout",
  "The file path into which a JUnit-style xml test results
   file should be written.",
  junit = file.path("traceability_matrix", "junit.xml"),
  "A quoted expression, producing a `testthat` reporter. The
   reporter's initialization is expected to match the signature of 
   `testthat::JunitReporter$new()`, notably expecting a `file` argument to
   use as the output `junit.xml` filepath.",
  junit_reporter = quote(testthat::JunitReporter),
  "Whether testthat infrastructure should be available within
   autovalidateutils. The actual usage will be determined based on the
   uses_testthat function output. Defaults to `TRUE`.",
  use_testthat = TRUE,
  envvar_fn = envvar_is_true(),

  # libraries and packages
  "Character vector of dependency types. All packages with those types
   are permitted to be installed from any available repo during validation.
   Defaults to only 'Suggests'",
  inst_deps = "Suggests",
  "Character vector of dependecies types. All packages with those types
   are required to be installed before the validation can start.",
  req_deps = c("Depends", "Imports", "LinkingTo"),
  "Whether packages should be upgraded if higher version than installed is
   available. Keep NULL to use the default autovalidateutils behavior
   which is upgrading for DEP_LIB_CORE and not upgrading for DEP_LIB_OPTIONAL.",
  upgrade_deps = NULL,
  "Character vector of libraries that will be appended to
   standard repos during installation of suggested packages.",
  suggests_repos = c("https://cran.r-project.org/"),
  "Character vector specifying in which order dependencies
   types and the package under validation should be installed. By default
   c(\"Depends\", \"Imports\", \"LinkingTo\", \"Validation\", \"Suggests\", \"Enhances\"). # nolint
   It should always contain all the values, regardless of the inst_deps param
   value",
  installation_order = c(
    "Depends",
    "Imports",
    "LinkingTo",
    "Validation",
    "Suggests",
    "Enhances"
  ),

  # revdepcheck
  "Repository used for identyfying reverse dependencies. It should
   be the same as `repos` unless using linux binaries, then it should be
   repo URL without binaires part.",
  revdep_repos = getOption("repos"),
  "Number of subprocesses used by the checked package for
   executing tasks when running reverse dependecy check.",
  revdep_n_workers = 20L,
  "Logical flag whether the sources of reverse dependencies should be removed.",
  revdep_clean_sources = TRUE,
  envvar_fn = envvar_is_true(),
  "Logical whether the source of the target package should be removed after
   completing checks.",
  revdep_clean_library = TRUE,
  envvar_fn = envvar_is_true()
)

#' @eval options::as_roxygen_docs()
#'
#' @family documentation
NULL

#' autovalidateutils Options
#' @eval options::as_params()
#' @name options_params
#'
#' @family documentation
NULL
