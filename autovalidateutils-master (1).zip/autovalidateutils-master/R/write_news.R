#' Write package NEWS out to a markdown file
#'
#' Search and process any bundled NEWS files to prepare them for incorporation
#' into an autovalidate report. Minimal processing is done in order to converge
#' on a markdown format that is permitted for the report.
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams autovalidate
#' @param file Optionally, an explicit filepath at which to place output
#'   markdown file.
#' @param quiet Whether command line output should be presented
#'
#' @export
#'
write_news_md <- function(
    x = ".", output = options::opt("output"),
    file = options::opt("news"), quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), ...) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    output = output
  ))

  x <- as.package(x)
  file <- avu_path(output, file)

  text <- avu_prepare_news_file(x, quiet = quiet, log_output = log_output)
  if (!is.null(text)) writeLines(text, file)

  invisible(TRUE)
}



#' Discover NEWS files and prepare as markdown contents for autovalidate
#'
#' @inheritParams as.package
#' @inheritParams write_news_md
#'
avu_prepare_news_file <- function(
    x, quiet = options::opt("quiet"), log_output = options::opt("log_output")) {

  x <- as.package(x)

  withr::local_options(options::opts_list(
    log_output = log_output,
    quiet = quiet
  ))

  news_files <- list.files(
    c(x$path, file.path(x$path, "inst")),
    full.names = TRUE,
    ignore.case = TRUE,
    pattern = "^NEWS(\\.(md|rd))?"
  )

  names(news_files) <- tolower(basename(news_files))

  # In case of multiple entires with the same name first one is chosen
  # according to how R works
  avu_cli_task("Processing NEWS", {
    news_file <- if ("news.md" %in% names(news_files)) {
      text <- readLines(news_files[["news.md"]], warn = FALSE)
      text <- partition_yaml_front_matter(text)$body
      # try to wrap anything that might be interpreted as a LaTeX or pdf control
      # sequence within an inline codeblock
      convert_markdown_headers_to_hash(paste0(text, collapse = "\n"))
    } else if ("news" %in% names(news_files)) {
      c("```", readLines(news_files[["news"]], warn = FALSE), "```")
    } else if ("news.rd" %in% names(news_files)) {
      rd2markdown::rd2markdown(file = news_files[["news.rd"]])
    } else {
      message("No NEWS file found")
      NULL
    }

    if (is.null(news_file)) {
      invisible(news_file)
    } else {
      invisible(iconv(news_file, "UTF-8", "ASCII//TRANSLIT", sub = "?"))
    }
  })
}

# This is the rmarkdown:::partition_yaml_front_matter function
# copied form the rmarkdown package on 25.02.2022 to not
# cause hard dependencies just for the one function
partition_yaml_front_matter <- function(input_lines) {
  validate_front_matter <- function(delimiters) {
    if (length(delimiters) >= 2 &&
          (delimiters[2] - delimiters[1] > 1) &&
          grepl("^---\\s*$", input_lines[delimiters[1]])) {
      if (delimiters[1] == 1) {
        TRUE
      } else {
        all(grepl(
          "^\\s*(<!-- rnb-\\w*-(begin|end) -->)?\\s*$",
          input_lines[1:delimiters[1] - 1]
        ))
      }
    } else {
      FALSE
    }
  }
  delimiters <- grep("^(---|\\.\\.\\.)\\s*$", input_lines)
  if (validate_front_matter(delimiters)) {
    front_matter <- input_lines[(delimiters[1]):(delimiters[2])]
    input_body <- c()
    if (delimiters[1] > 1) {
      input_body <- c(input_body, input_lines[1:delimiters[1] - 1])
    }
    if (delimiters[2] < length(input_lines)) {
      input_body <- c(input_body, input_lines[-(1:delimiters[2])])
    }
    list(front_matter = front_matter, body = input_body)
  } else {
    list(front_matter = NULL, body = input_lines)
  }
}
