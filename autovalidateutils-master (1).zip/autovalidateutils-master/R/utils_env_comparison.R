#' Write current library package lock file to JSON
#'
#' Save named list of installed packages to a JSON file. The list contains
#' vectors of versions and names distinguish particular packages. If "Suggests"
#' value was passed to libs, packages install to that library will be skipped.
#'
#' @param libs List of libraries used for dependecy installation
#' @inheritParams options_params
#' @inheritParams base::write
#'
#' @importFrom jsonlite toJSON
#' @export
write_packages_lock_json <- function(
    log_output = options::opt("log_output"),
    file = options::opt("installed_packages"),
    libs = avu_initialize_libs()) {
  libraries <- .libPaths()
  libraries_to_skip <- which(libraries == libs[["Validation"]])
  if (length(libraries_to_skip) != 0) {
    libraries <- libraries[-libraries_to_skip]
  }
  ip <- installed.packages(lib.loc = libraries)
  packages <- unique(row.names(ip))
  packages_list <- lapply(packages, function(p) {
    unname(ip[ip[, "Package"] == p, "Version"])
  })
  names(packages_list) <- packages
  write(
    jsonlite::toJSON(packages_list, auto_unbox = TRUE, pretty = TRUE),
    file.path(log_output, file)
  )
}

#' Compare validation environment
#'
#' Take the list of installed packages created during validation and check
#' whether the same environments (in terms of used packages) could be restored
#' in the current session. Raises and error if environment cannot be restored.
#'
#' @param ip - path to the installed_packages.json created during past
#'    validation
#'
#' @importFrom jsonlite fromJSON
#' @export
error_on_available_package_mismatch <- function(ip) {
  ip_old <- jsonlite::fromJSON(ip)
  ip_old_names <- names(ip_old)
  ip_current <- installed.packages()
  ip_current_names <- row.names(ip_current)
  ap <- available.packages()
  ap_names <- row.names(ap)

  for (package_name in ip_old_names) {
    versions <- ip_old[[package_name]]

    if (package_name %in% ip_current_names && !package_name %in% ap_names) {
      # package is installed but not available in the repos, meaning we take
      # only the last version to compare as other had to be installed
      # through suggested repos
      versions <- versions[length(versions)]
    } else if (!package_name %in% c(ip_current_names, ap_names)) {
      # If the package is not available in getOption("repos") nor is installed
      # then there is nothing to check
      next()
    }

    installed_versions <- unname(
      ip_current[ip_current[, "Package"] == package_name, "Version"]
    )
    available_versions <- unname(ap[ap[, "Package"] == package_name, "Version"])
    if (!all(versions %in% c(installed_versions, available_versions))) {
      stop(
        paste0(
          "`", package_name, "`",
          ": Previous validation versions `",
          paste0(versions, collapse = "`, `"),
          "` do not match available and installed versions `",
          paste0(c(installed_versions, available_versions), collapse = "`, `"),
          "`"
        )
      )
    }
  }
}
