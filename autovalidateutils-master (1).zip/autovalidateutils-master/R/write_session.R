#' Write session info, producing yaml and json formatted metadata
#'
#' Record various measures of the active R session, used for documenting test
#' execution characteristics which may be necessary if one wishes to reproduce
#' the results of the test evaluation. This includes various diagnostic
#' functions provided by the R standard library.
#'
#' As well, the most critical measures are compiled into a long-form summary
#' for easy embedding into a validation report.
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams autovalidate
#' @inheritParams yaml::write_yaml
#' @param args list of parameters initially passed to the autovalidate function
#'
#' @importFrom yaml write_yaml
#' @importFrom jsonlite toJSON
#' @export
#'
write_session_info <- function(
    x = ".", output = options::opt("output"),
    file = options::opt("session"), quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), args = list()) {

  withr::local_options(options::opts_list(
    output = output
  ))

  file <- avu_path(output, file)
  yaml::write_yaml(avu_session_info(x = x, quiet = quiet), file = file)

  # Save sessionInfo object for programmatic debugging
  session_json <- jsonlite::toJSON(
    rapply(sessionInfo(), unclass, how = "list"),
    auto_unbox = TRUE,
    pretty = TRUE
  )
  write(session_json, file.path(log_output, "sessioninfo.json"))

  write_packages_lock_json(log_output, libs = args$libs)

  invisible(TRUE)
}



#' Execute a few diagnostic snippets to assess session info
#'
#' @inheritParams as.package
#' @param ... Additional arguments unused
#' @inheritParams options_params
#'
#' @importFrom withr with_options
#' @importFrom tools package_dependencies
#'
avu_session_info <- function(
    x = ".", ..., quiet = options::opt("quiet"),
    log_output = options::opt("log_output")) {

  x <- as.package(x)

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    log_output = log_output,
    quiet = quiet
  ))

  # Xchk added in r4.0.0
  capabilities_expr <- if (R.Version()$major >= 4) {
    quote(capabilities(Xchk = FALSE))
  } else {
    quote(capabilities())
  }

  # fields to evaluate and capture as console output
  session_fields <- list(
    sessionInfo = quote(sessionInfo()),
    capabilities = capabilities_expr,
    libPaths = quote(.libPaths()),
    os = quote(cat(sessionInfo()$running)),
    platform = quote(cat(R.version$platform)),
    system = quote(cat(R.version$system)),
    time = quote(cat(format(Sys.time(), tz = "GMT", usetz = TRUE))),
    installed_packages = bquote({
      inst <- as.data.frame(installed.packages(), stringsAsFactors = FALSE)
      for (libinst in split(inst, inst[["LibPath"]])) {
        cat(sprintf('Library: "%s"', libinst[1L, "LibPath"]), "\n")
        print(noquote(sort(sprintf(
          "%s (%s)", libinst[["Package"]], libinst[["Version"]]
        ))))
        cat("\n")
      }
    }),
    supporting_packages = bquote({
      inst <- as.data.frame(installed.packages(), stringsAsFactors = FALSE)
      # all except 'Enhances' for direct target dependencies
      target_pkgs <- tools::package_dependencies(
        .(x$package),
        db = inst,
        which = "most"
      )
      target_pkgs <- tools::package_dependencies(
        target_pkgs[[1L]],
        db = inst,
        recursive = TRUE
      )
      avu_pkgs <- tools::package_dependencies(
        .(packageName()),
        db = inst,
        recursive = TRUE
      )
      pkgs <- c(
        names(target_pkgs),
        names(avu_pkgs),
        unlist(target_pkgs),
        unlist(avu_pkgs)
      )
      pkgs <- sort(unique(pkgs))
      print(noquote(sprintf("%s (%s)", pkgs, inst[pkgs, "Version"])))
    })
  )

  session_data <- mapply(
    session_fields,
    i = seq_along(session_fields),
    name_i = names(session_fields),
    SIMPLIFY = FALSE,
    FUN = function(expr_i, i, name_i) {
      withr::with_options(c(width = 80L, max.print = 1e6), {
        avu_cli_task(paste0("Querying session ", name_i), {
          res <- capture.output(source(
            exprs = expr_i,
            print.eval = TRUE,
            local = TRUE
          ))
          paste0(res, collapse = "\n")
        })
      })
    }
  )

  # additional fields to calculate as structured data
  session_data$version <- unlist(getRversion())
  session_data$repos <- unname(getOption("repos"))

  summary_info <- c("sessionInfo", "capabilities", "libPaths")
  session_data$summary <- paste0(
    collapse = "\n\n",
    lapply(summary_info, function(item) {
      # deparse and format command for output
      cmd <- deparse(session_fields[[item]])
      cmd[1L] <- paste0("> ", cmd[1L])
      cmd[-1L] <- paste0("  ", cmd[-1L])

      # combine command and output for summary info
      sprintf("%s\n%s", paste0(cmd, collapse = "\n"), session_data[[item]])
    })
  )

  invisible(session_data)
}
