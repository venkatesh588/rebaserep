#' covr package coverage with configuration to avoid termination on error
#'
#' @inheritParams as.package
#' @inheritParams covr::package_coverage
#' @inheritParams options_params
#' @param type Passed to \code{\link[tools]{testInstalledPackage}} for packages
#'   that do not use testthat.
#' @param file An optional output file to record testthat results.
#' @param test_exec_log An optional output file to record test execution logs.
#' @param testing_session An optional output file (.yml file) to record
#'   `sessionInfo()` output as text.
#' @param log_output Path to the directory where json version of
#'   sessionInfo shall be stored for programmatic debugging. Set NULL to skip.
#' @param uses_testthat_flag Whether to use testthat specific test runner, or
#'   agnostic runner.
#'
#' @importFrom withr with_options
#' @importFrom covr package_coverage
#' @importFrom stringi stri_escape_unicode
safe_package_coverage  <- function(
  x,
  ...,
  clean = TRUE,
  type = "tests",
  file = NULL,
  test_exec_log = NULL,
  testing_session = NULL,
  log_output = options::opt("log_output"),
  cov_logs = options::opt("cov_logs"),
  uses_testthat_flag = options::opt("use_testthat")
) {
  x <- as.package(x)

  # TODO: Remove normalization once https://github.com/r-lib/covr/pull/593
  # TODO: is merged
  cov_tmp_tests_dir <- normalizePath(
    file.path(tempdir(), "covr"),
    winslash = "/",
    mustWork = FALSE
  )
  dir.create(cov_tmp_tests_dir)
  dir_create(covr_process_logs <- file.path(log_output, "covr"))

  code <- if (uses_testthat_flag && uses_testthat(x)) {
    # avoid using hardcoded output files... looking at you, rtables
    package_coverage_testthat_code(
      x,
      type = type,
      file = file,
      testing_session = testing_session,
      log_output = log_output,
      cov_logs = cov_logs
    )
  } else {
    package_coverage_test_code(
      x,
      type = type,
      file,
      install_path = cov_tmp_tests_dir,
      testing_session = testing_session,
      log_output = log_output
    )
  }

  cov <- avu_isolated_process(
    callr::r_vanilla,
    f = function(x, code, clean, install_path) {
      withr::with_options(
        list(covr.record_tests = TRUE, width = 80L),
        {
          covr::package_coverage(
            path = x$path,
            type = "none", # don't run default tests runner
            code = code,
            clean = clean,
            install_path = install_path
          )
        }
      )
    },
    args = list(
      x = x,
      code = code,
      clean = is.null(test_exec_log) && clean,
      install_path = cov_tmp_tests_dir
    ),
    libpath = c(package_library("covr"), .libPaths()),
    stdout = normalizePath(
      file.path(covr_process_logs, "process_std.log"),
      mustWork = FALSE
    ),
    stderr = normalizePath(
      file.path(covr_process_logs, "process_err.log"),
      mustWork = FALSE
    ),
    timeout = options::opt("timeout")
  )

  if (is.null(cov)) {
    stop("Coverage calculation process failed because of the unexpected issue")
  }

  if (!is.null(test_exec_log)) {
    test_output <- head(Sys.glob(file.path(
      attr(cov, "library"),
      sprintf("%s-commands.Rout*", attr(cov, "package")$package)
    )), 1L)

    test_output_content <- readLines(test_output)
    test_output_content_ascii <-
      stringi::stri_escape_unicode(test_output_content)

    # remove non-ascii characters which can cause errors when rendering
    # documentation using pandoc, issue notification if characters were removed.
    if (!all(test_output_content == test_output_content_ascii)) {
      message(
        "test output contains non-ascii characters which were ",
        "automatically escaped."
      )
    }

    writeLines(test_output_content_ascii, test_exec_log)
  }

  # Delete covr temporary library, akin to setting `clean = TRUE`.  There may be
  # additional intermediate files in the package path, but we will disregard
  # those.
  if (!is.null(test_exec_log) && clean) {
    unlink_dir(attr(cov, "library"))
  }

  cov
}



#' Build a string value to pass to package_coverage to evaluate unit tests
#'
#' This implementation assumes that testthat is used, which imposes constraints
#' on the files that are used for testing.
#'
#' @inheritParams safe_package_coverage
#' @importFrom tools file_path_as_absolute
#' @importFrom testthat SummaryReporter MultiReporter JunitReporter test_package
#'
package_coverage_testthat_code <- function(
  x,
  type = "tests",
  file = NULL,
  testing_session = NULL,
  log_output = NULL,
  cov_logs = options::opt("cov_logs")
) {
  x <- as.package(x)

  if (!is.null(file)) {
    file <- file.path(
      tools::file_path_as_absolute(dirname(file)),
      basename(file)
    )
  }

  junit_reporter <- options::opt("junit_reporter")
  reporter <- if (is.null(file) || is.null(cov_logs)) {
    quote(testthat::SummaryReporter$new(show_praise = FALSE, omit_dots = TRUE))
  } else {
    location_reporter_file <- file.path(cov_logs, "error_locations.log")
    summary_reporter_file <- file.path(cov_logs, "tests_summary.log")
    bquote({
      # nocov start
      testthat::MultiReporter$new(reporters = list(
        # add a SummaryReporter to output test running to console
        testthat::SummaryReporter$new(
          file = .(summary_reporter_file),
          show_praise = FALSE,
          omit_dots = TRUE,
          max_reports = Inf
        ),
        # include JunitReporter for logging test xml metadata
        .(junit_reporter)$new(file = .(file)),
        testthat::LocationReporter$new(file = .(location_reporter_file))
      ))
      # nocov end
    })
  }

  options <- bquote_deparse_paste(
    # nocov start
    options(
      width = 80L,
      testthat.progress.max_fails = 1L,
      testthat.use_colours = FALSE,
      cli.unicode = FALSE,
      crayon.enabled = FALSE,
      useFancyQuotes = FALSE
    )
    # nocov end
  )

  test <- bquote_deparse_paste(
    # nocov start
    testthat::test_package(
      .(x$package),
      stop_on_failure = FALSE,
      reporter = .(reporter)
    )
    # nocov end
  )

  # arrange code snippet for use with covr::package_coverage
  paste(sep = "\n",
    options,                                            # setup
    test,                                               # test
    test_sessioninfo_code(testing_session, log_output)  # capture session info
  )
}



#' Build a string value to pass to package_coverage to evaluate unit tests
#'
#' This implementation aspires to be completely test-framework-independent, but
#' may need more testing to gauge reliability.
#'
#' @inheritParams safe_package_coverage
#' @inheritParams covr::package_coverage
#' @importFrom tools file_path_as_absolute testInstalledPackage
#'
package_coverage_test_code <- function(
  x,
  type = "tests",
  file = NULL,
  test_exec_log = NULL,
  install_path = file.path(tempdir(), "cov"),
  testing_session = NULL,
  log_output = NULL
) {
  # an alternative that doesn't rely on testthat::test_package
  # perhaps an option if we face any issues with generalizability of testthat
  # specific functions

  x <- as.package(x)

  if (!is.null(file)) {
    file <- file.path(
      tools::file_path_as_absolute(dirname(file)),
      basename(file)
    )
  }

  # Some test frameworks load the package in a fresh environment before
  # executing tests. In order to set options regardless of environment, we
  # inject code during the startup hook. Inspired by covr:::add_hook.
  set_hook <- bquote(setHook(
    packageEvent(.(x$package), "onLoad"),
    function(...) {
      # nocov start
      message("Running autovalidate onLoad callback, setting test options")
      options(
        width = 80L,
        testthat.default_reporter = "junit",
        testthat.default_check_reporter = "junit",
        testthat.output_file = .(file),
        testthat.progress.max_fails = 1L,
        testthat.use_colours = FALSE,
        crayon.enabled = FALSE,
        useFancyQuotes = FALSE
      )
      # nocov end
    }
  ))

  # build code for injecting startup code
  setup <- bquote_deparse_paste({
    # nocov start
    msg <- "## covr onLoad options ##"
    load_script <- file.path(.libPaths()[[1]], .(x$package), "R", .(x$package))
    lines <- readLines(load_script)
    if (!any(grepl(msg, lines))) {
      lines <- append(lines, c(msg, .(set_hook)), after = length(lines) - 1L)
    }

    # write modified startup back into temp package load script
    writeLines(text = lines, con = load_script)

    # create a temporary directory for test outputs
    tmpdir <- .(file.path(install_path, x$package))
    if (!dir.exists(tmpdir)) dir.create(tmpdir, recursive = TRUE)
    # nocov end
  })

  # build code for executing tests
  test <- bquote_deparse_paste(
    # nocov start
    # execute package tests
    tools::testInstalledPackage(
      .(x$package),
      lib.loc = .libPaths()[[1]],
      outDir = tmpdir,
      types = .(type)
    )
    # nocov end
  )

  # arrange code snippet for use with covr::package_coverage
  paste(sep = "\n",
    # setup
    setup,
    # unload pkg
    sprintf('detach("package:%s", unload = TRUE)', x$package),
    # reload new onLoad hooks
    sprintf('library("%s")', x$package),
    # test
    test,
    # capture session info
    test_sessioninfo_code(testing_session, log_output)
  )
}

#' Build a string value to pass to package_coverage_*_code to capture testing
#' sessionInfo
#'
#' Based on the passed paths, create ready-to-parse character value with code
#' saving sessionInfo to appropriate files.
#'
#' @inheritParams safe_package_coverage
test_sessioninfo_code <- function(testing_session = NULL, log_output = NULL) {
  # Save sessionInfo object in two forms for programmatic debugging
  # and report purpose

  # If there is a pacakge that install mock packages to temporary library this
  # sessionInfo would crash, therefore we add tryCatch
  if (!is.null(testing_session)) {
    yaml_session_info <- bquote_deparse_paste(
      yaml::write_yaml(
        x = paste0(
          tryCatch(
            capture.output(sessionInfo()),
            error = function(e) list(as.character(e))
          ),
          collapse = "\n"
        ),
        file = .(testing_session)
      )
    )
  }

  if (!is.null(log_output)) {
    json_session_info <- bquote_deparse_paste(
      write(
        jsonlite::toJSON(
          rapply(
            tryCatch(sessionInfo(), error = function(e) list(as.character(e))),
            unclass,
            how = "list"
          ),
          auto_unbox = TRUE,
          pretty = TRUE
        ),
        file.path(.(log_output), "testing_sessioninfo.json")
      )
    )
  }

  paste(
    if (exists("yaml_session_info")) {
      yaml_session_info
    },
    if (exists("json_session_info")) {
      json_session_info
    },
    sep = "\n"
  )
}


#' @importFrom covr tally_coverage
prepare_coverage_df <- function(cov) {
  df <- covr::tally_coverage(cov, by = "line")

  if (NROW(df) == 0) {
    return(data.frame(
      File = "Total coverage",
      Coverage = "0.00%",
      stringsAsFactors = FALSE
    ))
  }

  precentages <- tapply(
    df$value,
    df[["filename"]],
    FUN = function(x) (sum(x > 0) / length(x)) * 100
  )

  df <- data.frame(
    File = names(precentages),
    Coverage = unname(precentages),
    stringsAsFactors = FALSE
  )

  df <- rbind(
    df,
    list(File = "**Total coverage**", Coverage = covr::percent_coverage(cov)),
    stringsAsFactors = FALSE
  )

  df$Coverage <- sprintf("%.2f%%", round(df$Coverage, 2))
  df
}
