#' Write Reverse Dependency R CMD check results
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams autovalidate
#'
#' @export
#'
write_checked <- function(
    x = ".", output = options::opt("output"),
    quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), ...) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    output = output,
    log_output = log_output,
    quiet = quiet
  ))

  x <- as.package(x)

  withr::with_options(list(available_packages_filters = list(
    # defaults, minus "duplicates"
    "R_version", "OS_type", "subarch",
    # custom duplicates, prioritizing first repo where the package is discovered
    "use first available repo" = avu_remove_duplicates
  )), {
    write_checked_output(
      x = x,
      output = output,
      quiet
    )
  })

  avu_cli_task("Writing revdepcheck report", {
    warn_checked_problems(file.path(revdep_dir(output), "results.txt"))
  })


  invisible(TRUE)
}

#' @importFrom checked rev_dep_check_tasks_df check_design results
write_checked_output <- function(
    x,
    output = options::opt("output"),
    quiet = options::opt("quiet")) {
  x <- as.package(x)
  raw_output <- revdep_dir(output)

  # avu_initialize_libs doesn't re-create libs if they were already initialized
  avu_libs <- as.character(avu_initialize_libs())
  checked_lib_loc <- c(
    avu_libs[!endsWith(avu_libs, "R_LIB_validation")],
    options::opt("lib.loc")
  )

  start_time <- Sys.time()

  pkgs_done <- c()
  status <- avu_cli_status(
    "{cli::symbol$arrow_right} Initializing reverse dependecy check {cli::symbol$ellipsis}" # nolint
  )

  df <- checked::rev_dep_check_tasks_df(
    path = x$path,
    repos = options::opt("revdep_repos"),
    versions = c("dev", "release"),
    lib.loc = checked_lib_loc
  )

  revdeps <- vapply(df$package, function(x) x$package_spec$name, character(1))

  for (revdep in unique(revdeps)) {
    deps <- dependencies_satisfiability(
      revdep,
      req_deps = DEP_LIB_CORE,
      inst_deps = DEP_LIB_CORE,
      lib.loc = options::opt("lib.loc"),
      repos = getOption("repos", NULL)
    )

    if (!all(deps$satisfiable)) {
      stop(
        call. = FALSE,
        paste0(
          sprintf(
            paste0(
              "\nReverse dependecy - %s - is missing core ",
              "dependencies in the repository."
            ),
            revdep
          ),
          "\nContact repository administrator to resolve the issue:\n  \n",
          paste0("    ", capture.output(deps), "\n", collapse = ""),
          "    \n"
        )
      )
    }
  }

  design <- checked::check_design$new(
    df = df,
    n = options::opt("revdep_n_workers"),
    output = raw_output,
    lib.loc = checked_lib_loc,
    repos = c(getOption("repos"), options::opt("suggests_repos")),
    restore = FALSE
  )

  # We are removing the package under validation from graph if it is not
  # available in default repositories to allow checked to run proper
  # reverse dependency check for possible reverse suggests dependencies. This
  # can be done safely, as the package under validation, cannot be a hard
  # dependency for any packages which are scheduled to be checked, as
  # otherwise it would need to be part of the repository.

  if (!x$package %in% available.packages()[, "Package"] &&
        x$package %in% igraph::V(design$graph)$name) {
    design$graph <- igraph::delete_vertices(design$graph, x$package)
  }

  while (!design$is_done()) {
    if (Sys.time() - start_time > options::opt("timeout")) {
      attr(design, "timeout") <- TRUE
      break()
    }
    design$start_next_task()
    v_attributes <-
      igraph::vertex.attributes(design$graph)[c("status", "type", "name")]
    done <- v_attributes$name[v_attributes$status == "done" &
                                v_attributes$type == "check"]
    to_report <- setdiff(done, pkgs_done)
    if (length(to_report) > 0) {
      pkgs_done <- done
      status <- avu_cli_status_update(
        status,
        cli::pluralize(
          "{cli::symbol$arrow_right} Finished {to_report} package{?s}
          {cli::symbol$ellipsis} ({length(pkgs_done)}/{NROW(df)})"
        )
      )
    }
  }

  avu_cli_status_clear(id = status)
  checked::results_to_file(
    checked::results(design),
    file = file.path(raw_output, "results.txt"),
    keep = "potential_issues"
  )

  # Remove ESC ansi signs from the file as they prevent pdf generation and as
  # June 2025 are impossible to be handled by pandoc

  writeLines(
    cli::ansi_strip(readLines(file.path(raw_output, "results.txt")))
  )

  if (isTRUE(attr(design, "timeout"))) {
    write(
      "\n\nReverse dependency check timed out.",
      file.path(raw_output, "results.txt"),
      append = TRUE
    )
  }

  clean_checked_dir(raw_output)
}

warn_checked_problems <- function(file) {
  problems <- readLines(file, warn = FALSE)
  acceptable_problems <- c(
    "No issues identified."
  )

  if (!all(problems %in% acceptable_problems)) {
    warning(paste0(problems, collapse = "\n"))
  }
}

#' Clean rev dep check directory
#'
#' When `checked` runs reverse dependency check, it produces multiple files
#' useful in debugging but not needed for actual report generation.
#' The function cleans the file system up based on the set options.
#'
#' @param output checked output
#'
clean_checked_dir <- function(output) {
  if (options::opt("revdep_clean_sources")) {
    sources_to_remove <- list.files(
      output,
      full.names = TRUE,
      recursive = TRUE,
      include.dirs = TRUE,
      pattern = "(\\.Rcheck$)|(\\.tar\\.gz$)"
    )

    for (s in sources_to_remove) {
      unlink(s, recursive = TRUE, force = TRUE)
    }
  }

  if (options::opt("revdep_clean_library")) {
    unlink(file.path(output, "libs"), recursive = TRUE, force = TRUE)
  }
}

revdep_dir <- function(path) {
  file.path(path, "revdep")
}
