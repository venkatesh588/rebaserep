#' A simple cli print function, handling quiet output suppression
#'
#' @inheritParams base::eval
#' @inheritParams options_params
#'
avu_cli <- function(
    expr, quiet = options::opt("quiet"), envir = parent.frame()) {
  if (!isTRUE(quiet) && packageVersion("cli") >= "2.0.0") {
    eval(expr, envir = envir)
  }
}



#' Custom cli h3 with GitLab log placeholder
#'
#' For whatever reason, empty lines get trimmed from gitlab ci logs. This
#' clutters the cli output. However, using a left margin seems to work just fine
#' to preserve otherwise empty lines.
#'
#' @inheritDotParams cli::cli_h3
#' @importFrom cli cli_div cli_text cli_end cli_h3
#'
avu_cli_h3 <- function(...) {
  avu_cli({
    div <- cli::cli_div(class = "indent-4", theme = avu_cli_theme())
    cli::cli_text()
    cli::cli_end(div)
    div <- cli::cli_div(theme = list(h3 = list("margin-top" = NULL)))
    cli::cli_h3(...)
    cli::cli_end(div)
  })
}


# nolint start: commented_code_linter.
#' Retrieve a cli theme for application output
#'
avu_cli_theme <- function() {
  list(
    ".indent-2" = list(
      "margin-left" = 2L
      # top and bottom margins have weird issues with cli_process, r-lib/cli #29
      # "margin-top" = 1L,
      # "margin-bottom" = 1L
    ),
    ".indent-4" = list(
      "margin-left" = 4L
      # top and bottom margins have weird issues with cli_process, r-lib/cli #29
      # "margin-top" = 1L,
      # "margin-bottom" = 1L
    )
  )
}
# nolint end


#' Helper to manage multiline alerts, which don't get appropriately wrapped
#'
#' @param alert_f a `cli::cli_alert*` function to use
#' @param msg A character vector to use for the alert message
#'
#' @importFrom cli cli_div cli_end cli_verbatim
#'
avu_cli_multiline_alert <- function(alert_f, msg) {
  msg_lines <- unlist(strsplit(msg, "\n"))
  alert_f(head(msg_lines, 1L))
  div <- cli::cli_div(class = "indent-2")
  for (line in tail(msg_lines, -1L)) cli::cli_verbatim(line)
  cli::cli_end(div)
}



#' Custom condition for cli info
#'
#' A subclass under "message" for cli formatting as an info alert
#'
#' @inheritParams base::message
#'
info <- function(...) {
  cond <- simpleCondition(...)
  class(cond) <- c("info", "message", class(cond))
  message(cond)
}



#' Custom condition for cli success
#'
#' A subclass under "message" for cli formatting as a success alert
#'
#' @inheritParams base::message
#'
success <- function(...) {
  cond <- simpleCondition(...)
  class(cond) <- c("success", "message", class(cond))
  message(cond)
}

#' Wrap a task in a cli output, emitting output as cli logs
#'
#' Displays a task heading with an overall status, as well as messages,
#' formatted as `cli` output. When multiple messages are emitted, the task
#' status inherits the most concerning message status.
#'
#' @param msg A message to describe the task section. This will be output as an
#'   alert with a status indicator corresponding to highest level condition
#'   status, indicating whether an error, warning, message or info message was
#'   emitted during execution.
#' @param expr An expression to evaluate for the task.
#' @param quiet Whether condition messages are emitted as a pretty-formatted cli
#'   output. When `FALSE`, the default, tasks are formatted for easier
#'   readability. When `TRUE`, all messages are suppressed, with warnings and
#'   errors behaving as usual.
#' @param envir An environment in which `expr` should be evaluated.
#' @param error_on Which condition messages should raise errors. A vector of
#'   "info", "message", "warning" and/or "error". Defaults to "error".
#' @param warning_on Which condition messages should raise errors. A vector of
#'   "info", "message", "warning" and/or "error". Defaults to `c()` (never).
#' @param callbacks A named `list` of callback functions to issue when
#' conditions are emitted. Callbacks will be emitted for condition classes which
#' match the list name. Callback functions are expected to accept a single
#' argument, the condition that was emitted.
#' @param skip_if logical vector indicating whether current task should be
#' skipped or not. If at least of the values is TRUE, task will be skipped.
#' Supply it as a named vector to achieve custom skip messages.
#'
#' @return The result of evaluating `expr`, invisibly.
#'
#' @importFrom cli cli_div cli_alert cli_text cli_div cli_end col_cyan
#' cli_alert_danger cli_alert_success cli_alert_warning cli_alert_info
#' cli_status symbol cli_status_clear
#'
#' @examples
#' # execute within autovalidateutils namespace for unexported function
#' with(getNamespace("autovalidateutils"), {
#'   dir_create(options::opt("log_output"), recursive = TRUE)
#'   avu_cli_task("Running task ...", 1 + 2)
#'   avu_cli_task(
#'     "Running task ...",
#'     info("emitting info during execution")
#'   )
#'   avu_cli_task(
#'     "Running task ...",
#'     message("emitting a message during execution")
#'   )
#'   avu_cli_task(
#'     "Running task ...",
#'     warning("emitting a warning during execution")
#'   )
#'   avu_cli_task("Running task ...", {
#'     info("when multiple messages are emitted, task takes most concerning status") # nolint
#'     warning("in this case, the warning")
#'   })
#' })
#'
avu_cli_task <- function(
    msg, expr = {}, quiet = options::opt("quiet"),
    envir = parent.frame(), error_on = "error", warning_on = c(),
    callbacks = c(error = avu_log, warning = avu_log), skip_if = FALSE) {
  expr <- substitute(expr)

  # when quiet, suppress stdout, but emit warnings and errors as usual
  if (quiet || packageVersion("cli") < "2.0.0") {
    if (any(skip_if)) {
      return(NULL)
    } else {
      suppressMessages(res <- eval(expr, envir = envir))
      return(res)
    }
  }

  status <- cli::cli_status(
    "{cli::symbol$arrow_right} {msg} {cli::symbol$ellipsis}"
  )
  on_opts <- c("info", "message", "warning", "error")

  if (length(error_on)) {
    error_on <- match.arg(error_on, on_opts, several.ok = TRUE)
  }

  if (length(warning_on)) {
    warning_on <- match.arg(warning_on, on_opts, several.ok = TRUE)
  }

  as_err <- function(cond) {
    class(cond) <- c("escalated_error", "error", "condition")
    cond
  }

  .collector <- new.env(parent = emptyenv())
  handlers <- list(
    message = function(m) {
      if (length(i <- head(which(names(callbacks) %in% class(m)), 1L))) {
        callbacks[[i]](m)
      }
      .collector$output <- append(.collector$output, list(m))
      if (any(class(m) %in% error_on)) {
        stop(as_err(m))
      } else {
        invokeRestart("muffleMessage")
      }
    },
    warning = function(w) {
      if (length(i <- head(which(names(callbacks) %in% class(w)), 1L))) {
        callbacks[[i]](w)
      }
      .collector$output <- append(.collector$output, list(w))
      if (any(class(w) %in% error_on)) {
        stop(as_err(w))
      } else {
        invokeRestart("muffleWarning")
      }
    },
    error = function(e) {
      if (length(i <- head(which(names(callbacks) %in% class(e)), 1L))) {
        callbacks[[i]](e)
      }
      .collector$output <- append(.collector$output, list(e))
    },
    condition = function(cond) {
      .collector$output <- append(.collector$output, list(cond))
    }
  )

  exec_time <- Sys.time()
  res <- if (any(skip_if)) {
    withCallingHandlers(
      {
        skip_messages <- get_skip_messages(skip_if)
        for (m in skip_messages) message(m)
      },
      message = handlers$message,
      warning = handlers$warning,
      condition = handlers$condition
    )
  } else if (length(error_on)) {
    withCallingHandlers(
      eval(expr, envir = envir),
      message = handlers$message,
      warning = handlers$warning,
      condition = handlers$condition
    )
  } else {
    try(silent = TRUE, withCallingHandlers(
      eval(expr, envir = envir),
      message = handlers$message,
      warning = handlers$warning,
      error = handlers$error,
      condition = handlers$condition
    ))
  }

  # calculate exec time
  exec_time <- as.numeric(difftime(Sys.time(), exec_time, units = "sec"))

  # emit warnings if specified in warning_on
  for (cond in .collector$output) {
    if (any(vapply(warning_on, function(i) inherits(cond, i), logical(1L)))) {
      class(cond) <- c("warning", "condition")
      cond$message <- trimws(cond$message)
      warning(cond)
    }
  }

  # discern exit status from emitted conditions
  exit_status <- vapply(.collector$output, integer(1L), FUN = function(cond) {
    if (inherits(cond, "error")) {
      5L
    } else if (inherits(cond, "warning")) {
      4L
    } else if (inherits(cond, "success")) {
      1L
    } else if (inherits(cond, "info")) { # info also inherits "message"
      2L
    } else if (inherits(cond, "message")) { # info also inherits "message"
      3L
    } else {
      2L
    }
  })

  exit_status <- max(1L, exit_status, na.rm = TRUE)
  alert_class <- switch(exit_status,
    "success",
    "info",
    "warning",
    "danger",
    "danger"
  )

  cli::cli_status_clear(status)

  avu_cli(quiet = quiet, {
    # append execution time if long running
    if (exec_time > 2) { # sec
      msg <- list(
        msg,
        " ",
        cli::col_cyan(list("(", pretty_time(exec_time), ")"))
      )
    }

    # Gather file log msg for future use
    file_log_msg <- paste0(unlist(msg), collapse = "")

    div <- cli::cli_div(theme = avu_cli_theme())
    cli::cli_alert(msg, class = paste0("alert-", alert_class))
    div_output <- cli::cli_div(class = "indent-4")
    if (length(.collector$output) > 0L) {
      cli::cli_text()
      for (o in .collector$output) {
        if (inherits(o, "error")) {
          avu_cli_multiline_alert(cli_alert_danger, o$message)
          file_log_msg <- c(file_log_msg, o$message)
        } else if (inherits(o, "warning")) {
          avu_cli_multiline_alert(cli_alert_danger, o$message)
          file_log_msg <- c(file_log_msg, o$message)
        } else if (inherits(o, "success")) {
          avu_cli_multiline_alert(cli_alert_success, o$message)
          file_log_msg <- c(file_log_msg, o$message)
        } else if (inherits(o, "info")) {
          avu_cli_multiline_alert(cli_alert_info, o$message)
          file_log_msg <- c(file_log_msg, o$message)
        } else if (inherits(o, "message")) {
          avu_cli_multiline_alert(cli_alert_warning, o$message)
          file_log_msg <- c(file_log_msg, o$message)
        } else {
          avu_cli_multiline_alert(cli_alert, o$message)
          file_log_msg <- c(file_log_msg, o$message)
        }
        # poor man's top and bottom margins until #279 is resolved
        cli::cli_text()
      }
    }
    cli::cli_end(div_output)
    cli::cli_end(div)
  })

  dir_create(options::opt("log_output"))
  conn <- file(file.path(options::opt("log_output"), "cli.log"), "a")
  writeLines(file_log_msg, con = conn)
  close(conn)

  invisible(res)
}

avu_cli_status <- function(..., quiet = options::opt("quiet")) {
  if (!quiet) cli::cli_status(..., .envir = parent.frame())
}

avu_cli_status_update <- function(..., quiet = options::opt("quiet")) {
  if (!quiet) cli::cli_status_update(..., .envir = parent.frame())
}

avu_cli_status_clear <- function(..., quiet = options::opt("quiet")) {
  if (!quiet) cli::cli_status_clear(..., .envir = parent.frame())
}

get_skip_messages <- function(skip_if) {
  true_skip_if <- skip_if[skip_if]
  if (is.null(names(skip_if))) {
    "Skipped!"
  } else if (all(names(true_skip_if) == "")) {
    # If only some values of the vector were named, all the other get "" name
    "Skipped!"
  } else {
    names(true_skip_if[names(true_skip_if) != ""])
  }
}

pretty_time <- function(time) {
  if (requireNamespace("prettyunits", quietly = TRUE))
    prettyunits::pretty_sec(time)
  else
    time
}
