#' Write vulnerabilities info, producing yaml description
#'
#' Query OSV database \code{https://osv.dev/} looking for potential
#' vulnerabilities associated with the package itself or, for Ubuntu,
#' declared system dependencies. In case vulnerability is found, it will be
#' reported as autovalidateutils error.
#'
#' Generates yaml file with human readable query results.
#'
#' @inheritParams as.package
#' @inheritParams options_params
#' @inheritParams autovalidate
#' @inheritParams yaml::write_yaml
#' @param args list of parameters initially passed to the autovalidate function
#'
#' @importFrom yaml write_yaml
#' @importFrom jsonlite toJSON
#' @export
#'
write_vulnerabilities_info <- function(
    x = ".", output = options::opt("output"),
    file = options::opt("vulnerabilities"), quiet = options::opt("quiet"),
    log_output = options::opt("log_output"), args = list()) {

  withr::local_options(options::opts_list(
    # Setup local options in case the function is used standalone to make sure
    # logging (mostly cli) functions work as expected
    output = output,
    log_output = log_output,
    quiet = quiet
  ))

  file <- avu_path(output, file)
  dir_create(dirname(file))

  yaml::write_yaml(avu_vulnerabilities_info(x = x), file = file)

  invisible(TRUE)
}



#' Calls OSV database to assess package's vulnerabilities
#'
#' @inheritParams as.package
#' @param ... Additional arguments unused
#' @inheritParams options_params
#'
#' @importFrom httr POST content
#'
avu_vulnerabilities_info <- function(
    x = ".", ..., quiet = options::opt("quiet")) {
  x <- as.package(x)

  avu_cli_task("Quering package's vulnerabilities", {
    cran_data <- get_osv_db_data_cran(x$package, x$version)
  })

  deps_data <- if (is_ubuntu()) {
    avu_cli_task("Quering system dependencies vulnerabilities", {
      suppressMessages({
        ubuntu_deps <- pak::pkg_sysreqs(
          x$path,
          dependencies = FALSE,
          sysreqs_platform = "ubuntu"
        )
        syspkgs <- pak::sysreqs_list_system_packages()
      })

      unlist(
        lapply(ubuntu_deps$packages$sysreq, function(req) {
          v <- syspkgs[syspkgs$package == req, "version"]
          if (length(v) > 0) {
            get_osv_db_data_ubuntu(req, v)
          } else {
            list()
          }
        }),
        recursive = FALSE
      )
    })
  } else {
    list()
  }

  vulnerabilities_data <- c(
    cran_data,
    deps_data
  )

  avu_cli_task("Checking vulnerabilities results", {
    if (length(vulnerabilities_data) > 0) {
      readable_data <- do.call(
        rbind,
        mapply(function(data, id) {
          data.frame(
            id = id,
            name = data$name,
            summary = data$summary %||% "summary is missing",
            ecosystem = data$ecosystem
          )
        },
        vulnerabilities_data,
        names(vulnerabilities_data),
        SIMPLIFY = FALSE,
        USE.NAMES = FALSE)
      )

      vulnerabilities_msg <- capture.output(readable_data)
      warning(call. = FALSE, immediate. = TRUE,
        "Following vulnerabilitites associated with the package ",
        "has been identified:\n",
        "    \n",
        paste0("    ", vulnerabilities_msg, "\n", collapse = ""),
        "    \n"
      )
    }
  })

  invisible(vulnerabilities_data)
}

#' Query OSV database
#'
#' Send a http POST request to the \code{https://api.osv.dev/v1/query} database
#' requesting information about specific version of the package kept in a given
#' ecosystem
#'
#' @param package package's name.
#' @param version package's version.
#' @param ecosystem name of the ecosystem (repository) where the package is
#'  registered.
#'
#' @importFrom httr POST content
#' @importFrom jsonlite fromJSON
get_osv_db_data <- function(package, version, ecosystem) {

  if (!is_url_available("https://osv.dev")) {
    stop("Error while trying to query OSV database.")
  }

  r <- httr::POST(
    url = "https://api.osv.dev/v1/query",
    body = list(
      version = version,
      package = list(name = package, ecosystem = ecosystem)
    ),
    encode = "json"
  )

  r_json <- jsonlite::fromJSON(httr::content(r, "text", encoding = "UTF-8"))

  vulnerabilities <- lapply(seq_along(r_json$vulns$id), function(i) {
    list(
      # Get name of the package from affected packages df
      name = r_json$vulns$affected[[i]]$package$name[[1]],
      summary = r_json$vulns$summary[[i]],
      url = if (!is.null(r_json$vulns$id[[i]]))
        paste0("https://osv.dev/vulnerability/", r_json$vulns$id[[i]]),
      ecosystem = ecosystem
    )
  })

  names(vulnerabilities) <- r_json$vulns$id

  vulnerabilities
}

get_osv_db_data_cran <- function(package, version) {
  get_osv_db_data(package, version, "CRAN")
}

get_osv_db_data_ubuntu <- function(package, version) {
  get_osv_db_data(package, version, "Ubuntu")
}

#' @importFrom pak system_r_platform
is_ubuntu <- function() {
  grepl("ubuntu", pak::system_r_platform(), fixed = TRUE)
}
