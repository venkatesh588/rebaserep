# Production

Images created within OCEAN's production environment

## Synchronized images

The complete list of images synchronized in this repository is available in the [`.gitlab-ci.yml`](.gitlab-ci.yml) file.

Images are automatically synchronized automatically on Sundays.

Images can also be manually synchronized using the Gitlab CI web interface.

## Usage

### Local usage

1. Login to the container registry by executing: `docker login registry.code.roche.com`. Use your Gitlab username for the username, and use a [Gitlab Access Token](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html#create-a-personal-access-token) with the `read_registry` scope enabled for the password.
1. Browse the images @ [https://code.roche.com/cicd-utilities/ocean/prod/container_registry](https://code.roche.com/cicd-utilities/ocean/prod/container_registry) and select an image that you want to use.
1. Say you want to use the `cicd-utilities/ocean/prod/rstudio-standard:R4.1.3-08apr2022` image, then simply pull the image by executing the following: `docker pull registry.code.roche.com/cicd-utilities/ocean/prod/rstudio-standard:R4.1.3-08apr2022`
1. Run a container based on the image you just pulled. Different images expose different services, tools, and utilities differently, so the container run instructions will vary based on the image.

### Gitlab CI pipeline

Gitlab should be able to fetch the image directly from the registry as it auto-authenticates with the container registry using the built-in token during a CI pipeline run.

Using the image in a Gitlab CI pipeline is as simple as specifying the image URI wherever you need to.

### Updating images to sync

To get the list of available curated images from the OCEAN Sandbox ECR repository, you can run the following:

```bash
curl -X 'GET' \
  'https://aa-api-v2.us.aa.apollo.roche.com/api/list/repos/image?type=System%20Images&repo=All%20Images&region=eu&start_num=0&page_size=25&order_by=asc' \
  -H 'accept: application/json' \
  -H 'x-platform-guid: ROLE-OCEAN' | jq '.Table'
```
