# Roche GitLab Pipelines for R <img src='https://code.roche.com/uploads/-/system/project/avatar/15585/hex-r-gitlab.png' align="right" height="139" />

###  Status: $`\textsf{\textcolor{green}{Stable}}`$

Pipelines are used in production, but can always use broader adoption to guarantee that they work reliably. 

## Getting Started

Adding pipelines to your R package is simple. Add the following lines to your
`.gitlab-ci.yml` file:

```yml
include:
  - project: 'roche-r/gitlab-ci'
    file: '.gitlab-ci.yml'
```

On your next commit, your repo will execute the `roche-r/gitlab-ci` pipelines.

## What it Does

With each commit, `roche-r/gitlab-ci` pipelines will

| Pipeline | Step | Description |
|---|---|---|
| `gitlab-ci.yml` | Cache Dependencies` | • Downloads and installs dependencies so they can be re-used across the pipeline's jobs |
| `gitlab-ci.yml` | `R CMD check` | • Checks your package using `R CMD check` <br> • Warns on `NOTE`s, `WARNING`s <br> • Ends the pipeline on `ERROR`s |
| `gitlab-ci.yml` | `Test` | • Tests package using `tools::testInstalledPackage` <br> • Displays results in merge request |
| `gitlab-ci.yml` | `Coverage` | • Calculates test coverage using `covr::package_coverage` <br> • Displays results in merge request diffs <br> • Generates a coverage webpage |
| `gitlab-ci.yml` | `pages` | • Generates package documentation webpage using `pkgdown::build_site` <br> • Embeds your coverage report <br> • Uploads documentation to [docs.roche.com](https://docs.roche.com) (under the `dev` tag unless commit is tagged) <br> • Uploads documentation to GitLab pages |
| `gitlab-ci-publish-ppm.yml` | `Publish (packages.roche.com)` | • Optionally publishes package source and binary to `packages.roche.com` (see [publishing instructions](#publishing) below) |

## Variables

The `roche-r` pipelines will interpret a few variables which may be useful for
configuring your setup.

| Name | Description | Default|
| --:  | :--         | :-:    |
| `ROCHE_R` | Whether `roche-r` pipelines should run. Pipelines will run unless `"false"`. | _unset_ (`true`)|
| `ROCHE_R_JOBS` | A comma separated list of job names to include (or exclude, if beginning with a `-`). Jobs that can be toggled currently include: `lint` | _unset_ (all)|
| `ROCHE_R_PUBLISH_PPM` | **Please use a [Project Variable](https://docs.gitlab.com/ee/ci/variables/#define-a-cicd-variable-in-the-ui) to avoid publishing on forks\***. Whether to include a job to publish to RSPM in the respective areas. To enable, provide a list of `dev`, `production` (or `prod`), or `preview` (or `"prev"`) to deploy to the respective non-validated repositories on [packages.roche.com](https://packages.roche.com). For example (`dev,prev,prod`). | _unset_ |
| `ROCHE_R_CACHE_INSTALL_HANDLER` | Which package to use for installing a cached dependency library. Expects `pak`\*\* or `remotes` defaulting to `remotes` when unset. | _unset_ (`remotes`) |
| `ROCHE_R_TESTS_INSTALL_PKG` | Logical value interpretable by R indicating whether the package should be preinstalled before testing. Ignored if the packages does not use testthat  | _unset_ (`TRUE`) |

\*These variables should be set in the Project, not in the `gitlab-ci.yml` file to avoid the same settings being applied to forks.  \
\*\*`pak` required for using the [`onedesign` `pkgdown` template](https://code.roche.com/roche-r/onedesign)

## Publishing to [packages.roche.com](https://packages.roche.com) <a id="publishing" name="publishing"></a>

Publishing is not enabled by default. To enable publishing, you will need to
provide a value for the `ROCHE_R_PUBLISH_PPM` environment variable as described
in [Variables](#variables).

Note that this variable should only be configured as a **Project-level
variable** and should **not** be included in your yaml file to avoid forks of
your project publishing accidentally.

### Deploy Rules

When enabled, your package will deploy to different repositories depending
on your stage of development:

| [packages.roche.com](https://packages.roche.com) Repo | Scenario |
| --- | --- |
| [`dev`](https://packages.roche.com/client/#/repos/16/packages) | On commit to your default branch |
| [`preview`](https://packages.roche.com/client/#/repos/17/packages) | Manually deployed, available on default branch |
| [`production`](https://packages.roche.com/client/#/repos/4/packages) | On release* |

> \*Releases must have a description. If left blank, the pipeline will not be
> triggered.
