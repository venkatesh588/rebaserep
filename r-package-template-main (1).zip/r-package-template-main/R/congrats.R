#' Congratulate developers for kicking off package development from the template
#'
#' @param ... Additional arguments unused
#' @return `NULL`
#'
#' @export
congrats <- function(...) {
  cat("Congratulations! You've created a package from our template.")
  invisible(NULL)
}
