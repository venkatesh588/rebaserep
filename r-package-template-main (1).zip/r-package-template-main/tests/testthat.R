library(testthat)
library(packagename)  # replace this with your package name

test_check("packagename")  # replace this with your package name
