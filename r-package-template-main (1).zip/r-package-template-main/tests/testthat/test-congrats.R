test_that("packagename congrats works", {
  expect_output(congrats())
})
