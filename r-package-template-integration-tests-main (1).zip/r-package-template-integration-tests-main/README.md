# [r-package-template](https://roche-r.pages.roche.com/r-package-template)

A pre-configured package template to kickstart development on
[code.roche.com](https://code.roche.com).

## Naming Your Package

You'll want to give your package a name, and to do so you'll need to edit just a
couple files in this template. Change instances of `packagename` to your desired
package name.

1. In `DESCRIPTION`, change the package name to `Package: <desired name>`.
2. In `tests/testthat.R`, change the library and `test_check` statement to match.

## Adding Remote Dependencies

You may wish to use additional dependencies on in-development packages pulled
from code.roche.com. To do so, specify a `Remotes` section in your `DESCRIPTION`
file for such a dependency.

```
Imports:
  exampleCodeRocheComDep
Remotes:
  git::https://code.roche.com/namespace/exampleCodeRocheComDep.git
```

