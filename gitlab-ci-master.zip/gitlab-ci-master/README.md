# Autovalidate R GitLab CI Configurations

Template pipelines to easily embed Autovalidate R as part of your developer
workflow. Works seamlessly with generic `roche-r/gitlab-ci` pipelines.  

## Validated Use :ballot_box_with_check:	

_Using `autovalidate-r/gitlab-ci` is not sufficient for validation._

Validation requires either:

- Use of the `autovalidate-r` submission portal, which runs 
  `autovalidateutils` in a controlled way to produce useful 
   validation documentation.
- Using `autovalidate-r/gitlab-ci` pipelines 
  (or `autovalidateutils` directly) and accompanying the 
  generated report with additional documentation specific to your
  intended use, managing the storing of your validation documents 
  in an approved document management service.

## Lifecycle :recycle:

Depending on what stability you need from the pipelines, you can choose to
fix yourself to a lifecycle tag.

> **:sparkles: Be the change you want to see!!**
>
> We provide tagged versions for stability when it's critical for business 
> processes, but _someone_ needs to be testing upcoming releases. We greatly 
> appreciate staying on `HEAD` if you can afford it.
>
> The teams that require stability thank you!

| `ref` | Audience | Purpose |
|---|---|---|
| `HEAD`| :metal: Most Projects | Development version | 
| `latest` (floating tag) | :rotating_light: Critial Projects | Critial or exceedingly time-sensitive work that requires extra stability |
| `v#.#.#` (stable tag) | :vhs: | Historical releases for reproducibility if needed |


## Quick Start

For most cases, you'll want to use the pipelines as they are. For this, simply
include them in a `.gitlab-ci.yml` file alongside your project. We also
recommend including `roche-r/gitlab-ci`, although it isn't required.  This will
incorporate preliminary validation runs into your development workflow.

> **Preliminary Validation**  
> 
> In this context, preliminary validation means that your package is passing our
> validation requirements, but has been allowed lenience to install development
> versions of packages, and forego intensive checks for breaking reverse
> dependencies. Passing preliminary validation is a good heuristic, but is not
> to be used as an official validation process without further consideration.

```yaml
# .gitlab-ci.yml
include:
  - project: 'roche-r/gitlab-ci'
    file: '.gitlab-ci.yml'
  - project: 'autovalidate-r/gitlab-ci'
    file: '.gitlab-ci.yml'
```

## Submitting your Package

Once your package is ready to be published, you may submit your package to our
validated package repository. During this submission, your package's validation
will be run with more strict control over the R environment and package
ecosystem.

```yaml
# .gitlab-ci.yml
include:
  - project: 'roche-r/gitlab-ci'
    file: '.gitlab-ci.yml'
  - project: 'autovalidate-r/gitlab-ci'
    file: '.gitlab-ci.yml'

variables:
  AUTOVALIDATE_R_SUBMIT: 'true'
```

By default, packages are submitted when a commit is tagged as a release
candidate (using a tag containing in "rc" such as `v1.2.3rc1`). We ask that
developers increment these release candidates if they need to address issues
that arise during submission, and then tag the accepted version of their package
with the version number (`v1.2.3`) to make it clear which commits were finally
published.

## Specifying Environments

### Choosing a Validated Environment Preset

In most cases, the preferred way to customize your environment is to select a 
preset environment that satisfies your desired platform and R version.

```yaml
# .gitlab-ci.yml
include:
  - project: 'autovalidate-r/gitlab-ci'
    file: 'presets/r-plus.4.2.gitlab-ci.yml'  # r-plus is equivalent to "ocean"
```

When triggering a pipeline or running a pipeline through the web interface, specified environment variables can also be used to configure R envrionment. This is how the environment is configured when triggered in [our submission portal](https://code.roche.com/autovalidate-r/package-submission/portal)

> To use these variables in a repository, they must be set as either [Project or Group variables](https://docs.gitlab.com/ee/ci/yaml/includes.html#use-variables-with-include). 
> Using the `.gitlab-ci.yml` `variables` section **will not** allow them to impact included 
> pipelines. For transparency, we encourage the use of the presets as described above.

|Variable|Purpose|Default|
|---|---|---|
|`AUTOVALIDATE_R_IMAGE_PRODUCT_NAME`|The product name that you want to validate against. Accepted values: `"ocean"`|_uninitialized_|
|`AUTOVALIDATE_R_IMAGE_R_VERSION`|The R version that you want to validate against in the form `"1.2.3"`|_uninitialized_|

Our intention is that the preconfigured pipelines cover all use cases. If 
you have need of a new environment, please reach out so we can add it.

### Fine-Grained Control

All presets make use of the `.r-environment` default job, which can be masked to 
configure an R environment that is re-used for all R-based jobs. For exmaple, 
you could use this environment variable to provide a specific image or repository.

```yaml
.r-environment:
  image:
    name: registry.code.roche.com/autovalidate-r/autovalidate-r_images:R4.1.3
  variables:
    R_REPOS: 'c(MRAN = "https://mran.microsoft.com/snapshot/2020-04-24")'
```

This image is also exposed through an environment variable for situations when
directly changing a pipeline configuration is not suitable.

|Variable|Purpose|Default|
|---|---|---|
|`AUTOVALIDATE_R_IMAGE`|An image uri to use for R jobs during the pipeline|_uninitialized_|

## Templates & Environment Variables

### Overwritable Templates

|Template|Purpose|Default|
|-------|---|---|
|<code>.r&#x2011;environment</code>|Job specification to be reused for any R-based jobs. Can be masked globally to define an image that gets distributed specifically to R-based jobs.|`{ image: rocker/verse }`|

### Environment Variables

|Variable|Purpose|Default|
|---|---|---|
|`R_REPOS`|A string of interprettable R code that results in a named character vector. `options(repos = eval(parse(text = Sys.getenv("R_REPOS")))`. Unused if unset, using default repos.|_uninitialized_|
|`AUTOVALIDATE_VARS_TO_UNSET`|Space separated list of environment variables names to be unset before running autovalidateutils|_uninitialized_|
|`AUTOVALIDATE_R`| When `"false"`, no Autovalidate R steps are run.|_uninitialized_|
|`AUTOVALIDATE_R_SOURCE`| The source from which to extract the package source code. For details, see `R> ?autovalidateutils::autovalidate`. If unset, will default to using the path to the current directory, `"."`. | _uninitialized_ |
|`AUTOVALIDATEUTILS_LIB_LOC`|A string of interprettable R code that results in a character vector. Passed to `autovalidateutils::autovalidate` as `lib.loc` parameter. If unsed default `c(.Library, .Library.site)` value is used. |_uninitialized_|
|`AUTOVALIDATE_R_SUBMIT`|Choose when submission jobs should be added to your repository. By default, this parameter is only considered when a branch name follows the release candidate convention (above). When `"manual"` (recommended, especially when multiple environments are used), a submission job will be added, but the pipeline will require you to press _play_ before the job will execute and submit the package. When `"true"` your package will be automatically submitted assuming prior checks are passed.|_uninitialized_|
|`AUTOVALIDATE_R_UTILS_BRANCH`|The branch (or commit, or tag) to use when cloning autovalidateutils, passed to `git clone --branch` if non-empty string.|_Latest release tag_|
|`AUTOVALIDATE_R_REPORT_BRANCH`|The branch (or commit, or tag) to use when cloning the autovalidate-r/package-report-template, passed to `git clone --branch` if a non-empty string.|_Latest release tag_|
|`AUTOVALDIATE_R_RENDER_PDF`|When `"true"`, Autovalidate R includes rendering and storage of a pdf artifact.|_uninitialized_|

### Running Multiple Environments

For most use cases, running and submitting only to the latest repository is recommended. 
This is to limit the scope of validation and encourage teams to stay up-to-date with
R releases. However, some projects (such as central system infrastructure tools) may
need to ship to all currently in-use R environments. To do this, you can trigger 
a matrix of pipelines to run on each target R environment.

The deployment process for this can vary, and will depend on your needs. You may want 
to consider: 

> **Deciding on a Deploy Strategy**
>
> When do you want to deploy to an R environment? As soon as your package passes
> checks for only that platform, or would you prefer to wait until you can pass on 
> all platforms before submitting to keep the code absolutely in-sync?

There are two strategies we recommend. Which you choose will depend on your release
needs. 

These can both be configured by composing Autovalidate R as part of your pipeline.

#### Manually Deploy Per Platform

Here we configure _Autovalidate R_ to run as a child pipeline for each of the 
R versions that we want to test against. The default pipeline includes a submit step, 
which we can enable and configure to run only when given permission manually.

```mermaid
flowchart LR
  latest["Autovalidate R: [latest]"]
  old["Autovalidate R: [oldrel-1]"]
  submitlatest["Submit: [latest]"]
  submitold["Submit: [oldrel-1]"]

  latest --> success1["success"] --manual trigger--> submitlatest
  old --> success2["success"] --manual trigger--> submitold
```

Remember that submissions will only be attempted when the branch name is recognized
as a release candidate.

```yaml
Autovalidate R:
  variables:
    AUTOVALIDATE_R_SUBMIT: manual
  parallel:
    matrix:
     - AUTOVALIDATE_R_IMAGE_R_VERSION: [ 'latest', 'oldrel-1' ]
  needs: 
    # limit jobs to only run after roche-r/gitlab-ci's R CMD check passes
    - 'R CMD check'
  trigger: 
    strategy: depend
    include:
      - project: 'autovalidate-r/gitlab-ci'
        file: '.gitlab-ci.yml'
```

#### Automatic Submission once All Platforms Pass

We can also configure _Autovalidate R_ to submit packges **only** when all
platforms are passing checks. Once all checks are passing, only then will new jobs
be kicked off to submit to each of the target platforms.

```mermaid
flowchart LR
  latest["Autovalidate R: [latest]"]
  old["Autovalidate R: [oldrel-1]"]
  submitlatest["Submit: [latest]"]
  submitold["Submit: [oldrel-1]"]

  latest --> success --> submitlatest
  old --> success --> submitold
```

```yaml
Autovalidate R:
  parallel:
    matrix:
     - AUTOVALIDATE_R_IMAGE_R_VERSION: [ 'latest', 'oldrel-1' ]
  needs: 
    # limit jobs to only run after roche-r/gitlab-ci's R CMD check passes
    - R CMD check
  trigger: 
    strategy: depend
    include:
      - project: 'autovalidate-r/gitlab-ci'
        file: '.gitlab-ci.yml'

Autovalidate R (Submit):
  variables:
    AUTOVALIDATE_R_SUBMIT: manual
  parallel:
    matrix:
     - AUTOVALIDATE_R_IMAGE_R_VERSION: [ 'latest', 'oldrel-1' ]
  needs: 
    - Autovalidate R
  trigger: 
    strategy: depend
    include:
      - project: autovalidate-r/gitlab-ci
        file: envs/from-envvar.gitlab.yml
      - project: autovalidate-r/gitlab-ci
        file: templates/submit.gitlab-ci.yml
```

